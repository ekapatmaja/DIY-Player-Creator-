"""Build the standalone player-maker catalogue from the local studio sources.

The new editor does not read APKs at runtime. This development script extracts
the static reference data that is already present in the local source package:
ability/skill/booster tables, position regression weights, and the nation/team
name lists from the offline player library.

Usage:
    python tools/build_catalog.py --source "<...>/player-studio-efootxi" --output resources/catalog.json
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sqlite3
from collections import defaultdict

POSITION_ZH = {
    "GK": "门将", "CB": "中后卫", "LB": "左后卫", "RB": "右后卫", "DMF": "后腰",
    "CMF": "中前卫", "LMF": "左前卫", "RMF": "右前卫", "AMF": "前腰",
    "LWF": "左边锋", "RWF": "右边锋", "SS": "影锋", "CF": "中锋",
}

ABILITY_EN = {
    "attacking_prowess": "Attacking Prowess",
    "defensive_prowess": "Defensive Prowess",
    "goalkeeping": "Goalkeeping",
    "dribbling": "Dribbling",
    "ball_control": "Ball Control",
    "tight_possession": "Tight Possession",
    "finishing": "Finishing",
    "low_pass": "Low Pass",
    "lofted_pass": "Lofted Pass",
    "header": "Header",
    "ball_winning": "Ball Winning",
    "aggression": "Aggression",
    "defensive_engagement": "Defensive Engagement",
    "place_kicking": "Place Kicking",
    "swerve": "Curl",
    "catching": "Catching",
    "diving": "Clearing",
    "reflexes": "Reflexes",
    "coverage": "Coverage",
    "speed": "Speed",
    "physical_contact": "Physical Contact",
    "body_control": "Body Control",
    "kicking_power": "Kicking Power",
    "explosive_power": "Explosive Power",
    "jump": "Jump",
    "stamina": "Stamina",
}

ABILITY_GROUPS = [
    ("进攻与技术", [14, 18, 17, 19, 20, 21, 22, 23, 27, 28]),
    ("速度与身体", [34, 38, 37, 35, 36, 39, 40]),
    ("防守", [15, 24, 25, 26]),
    ("守门", [16, 29, 30, 31, 32]),
]

SIX_STATS = [
    {"key": "speed", "zh": "速度", "en": "PAC", "indices": [34, 38]},
    {"key": "shooting", "zh": "射门", "en": "SHO", "indices": [20, 37, 27]},
    {"key": "passing", "zh": "传球", "en": "PAS", "indices": [21, 22]},
    {"key": "dribbling", "zh": "盘带", "en": "DRI", "indices": [17, 18, 19]},
    {"key": "defending", "zh": "防守", "en": "DEF", "indices": [15, 24, 26]},
    {"key": "physical", "zh": "身体", "en": "PHY", "indices": [35, 39, 40]},
]

CARD_TYPES = [
    {"id": "BigTime", "code": "BT", "zh": "Big Time", "en": "Big Time", "theme": "bigtime", "accent": "#5fe1ff"},
    {"id": "ShowTime", "code": "ST", "zh": "Show Time", "en": "Show Time", "theme": "showtime", "accent": "#ff7ac8"},
    {"id": "Epic", "code": "EP", "zh": "史诗", "en": "Epic", "theme": "epic", "accent": "#b9a4ff"},
    {"id": "Legendary", "code": "LG", "zh": "传奇", "en": "Legendary", "theme": "legend", "accent": "#f2cf7e"},
    {"id": "Highlight", "code": "HL", "zh": "高光", "en": "Highlight", "theme": "highlight", "accent": "#ffb27a"},
    {"id": "Featured", "code": "FT", "zh": "精选", "en": "Featured", "theme": "featured", "accent": "#8fe8d1"},
    {"id": "Trending", "code": "POTW", "zh": "趋势 / POTW", "en": "Trending", "theme": "potw", "accent": "#ffd76a"},
    {"id": "Standard", "code": "STD", "zh": "标准", "en": "Standard", "theme": "standard", "accent": "#a9bfd6"},
]

AI_STYLES = [
    {"key": "trickster", "zh": "魔术师", "en": "Trickster"},
    {"key": "mazing_run", "zh": "惊人突破", "en": "Mazing Run"},
    {"key": "speeding_bullet", "zh": "疾速子弹", "en": "Speeding Bullet"},
    {"key": "incisive_run", "zh": "内切突破", "en": "Incisive Run"},
    {"key": "long_ball_expert", "zh": "长球专家", "en": "Long Ball Expert"},
    {"key": "early_cross", "zh": "提前传中手", "en": "Early Crosser"},
    {"key": "long_ranger", "zh": "重炮手", "en": "Long Ranger"},
]

TRAITS = {
    "weak_foot_usage": ["低", "普通", "高", "极高"],
    "weak_foot_accuracy": ["低", "普通", "高", "极高"],
    "form": ["稳定", "普通", "不稳定"],
    "injury": ["低", "普通", "高"],
    "condition": ["auto", "A", "B", "C", "D", "E"],
}


def load_catalog(source: pathlib.Path) -> dict:
    return json.loads((source / "resources" / "catalog.json").read_text(encoding="utf-8"))


def ability_table(cat: dict) -> list[dict]:
    keys = list(cat["ABILITIES"])
    stats = cat["stat_keys"]
    groups = {index: name for name, indices in ABILITY_GROUPS for index in indices}
    rows = []
    for position, (index, stat) in enumerate(zip(keys, stats)):
        rows.append({
            "index": int(index),
            "key": stat,
            "zh": cat["ABILITIES"][index],
            "en": ABILITY_EN.get(stat, stat),
            "group": groups.get(int(index), "其他"),
            "order": position,
        })
    return rows


def skill_table(cat: dict) -> list[dict]:
    out = []
    labels = cat["SKILL_LABELS"]
    names = cat["SKILL_NAMES"]
    for sid, code in zip(labels.keys(), names):
        label = labels[sid]
        if "预留" in label:
            continue
        out.append({
            "id": int(sid),
            "code": code,
            "zh": label,
            "param": cat["PARAMETER_BY_SKILL"].get(sid),
            "desc": cat["SKILL_DESCRIPTIONS"].get(sid, ""),
            "aliases": cat.get("SKILL_ALIASES", {}).get(sid, []),
            "custom": int(sid) in cat.get("CUSTOM_SKILL_IDS", []),
        })
    return out


def regression(cat: dict, abilities: list[dict]) -> dict:
    keys = [row["key"] for row in abilities]
    out = {}
    for position, model in cat["ovr_weights"].items():
        out[position] = {
            "intercept": model["intercept"],
            "weights": [float(model["abilities"].get(key, 0.0)) for key in keys],
        }
    return out


def identities(source: pathlib.Path) -> tuple[list, list]:
    path = source / "resources" / "library.sqlite3"
    if not path.is_file():
        return [], []
    con = sqlite3.connect(str(path))
    try:
        rows = list(con.execute("SELECT kind,id,name,name_en FROM identities ORDER BY kind,id"))
    finally:
        con.close()
    nations = [{"id": i, "zh": zh, "en": en} for kind, i, zh, en in rows if kind == "nation"]
    teams = [{"id": i, "zh": zh, "en": en} for kind, i, zh, en in rows if kind == "team"]
    return nations, teams


def archetypes(source: pathlib.Path, cat: dict, abilities: list[dict], weights: dict) -> list[dict]:
    """Average the strongest real cards per position into ready-made builds."""
    path = source / "resources" / "library.sqlite3"
    if not path.is_file():
        return []
    con = sqlite3.connect(str(path))
    con.row_factory = sqlite3.Row
    try:
        rows = list(con.execute(
            "SELECT position,card_type,payload FROM players "
            "WHERE card_type IN ('Epic','Legendary','Featured','BigTime','Highlight')"
        ))
    finally:
        con.close()
    indices = [row["index"] for row in abilities]
    by_position: dict[str, list[tuple[float, dict]]] = defaultdict(list)
    for row in rows:
        try:
            payload = json.loads(row["payload"])
            params = payload.get("parameters") or []
            if len(params) < 41:
                continue
            stats = {index: int(params[index]) for index in indices}
            if any(value < 40 or value > 110 for value in stats.values()):
                continue
            model = weights.get(row["position"])
            if not model:
                continue
            score = model["intercept"] + sum(w * stats[index] for index, w in zip(indices, model["weights"]))
        except (ValueError, TypeError, KeyError):
            continue
        by_position[row["position"]].append((score, stats))
    out = []
    for position, rows in by_position.items():
        rows.sort(key=lambda item: item[0], reverse=True)
        top = rows[:24]
        if not top:
            continue
        averaged = {}
        for index in indices:
            averaged[index] = int(round(sum(stats[index] for _, stats in top) / len(top)))
        out.append({
            "id": position,
            "zh": POSITION_ZH.get(position, position),
            "sample": len(top),
            "abilities": averaged,
        })
    out.sort(key=lambda row: list(POSITION_ZH).index(row["id"]) if row["id"] in POSITION_ZH else 99)
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default=r"D:\编辑器\_src_xi\player-studio-efootxi")
    parser.add_argument("--output", default="resources/catalog.json")
    args = parser.parse_args()
    source = pathlib.Path(args.source)
    cat = load_catalog(source)
    abilities = ability_table(cat)
    skills = skill_table(cat)
    weights = regression(cat, abilities)
    nations, teams = identities(source)

    training = []
    for group in cat["training_groups"]:
        training.append({
            "id": group["id"],
            "zh": group["label"],
            "indices": [int(i) for i in group["indices"]],
        })

    data = {
        "format": "player-maker/catalog",
        "version": 1,
        "release_id": cat["release_id"],
        "generated_from": "本地球员工坊源码资料（离线）",
        "abilities": abilities,
        "ability_groups": [{"name": name, "indices": indices} for name, indices in ABILITY_GROUPS],
        "six_stats": SIX_STATS,
        "positions": [
            {"code": code, "zh": POSITION_ZH.get(code, code),
             "group": "门将" if code == "GK" else "后卫" if code in ("CB", "LB", "RB") else "中场" if code in ("DMF", "CMF", "LMF", "RMF", "AMF") else "前锋"}
            for code in cat["POSITIONS"]
        ],
        "aptitude_levels": [
            {"value": 0, "zh": "不适应"}, {"value": 1, "zh": "部分适应"}, {"value": 2, "zh": "完全适应"},
        ],
        "play_styles": {
            side: [{"id": int(k), "zh": v} for k, v in sorted(cat["PLAY_STYLES"][side].items(), key=lambda kv: int(kv[0]))]
            for side in ("attack", "defense")
        },
        "ai_styles": AI_STYLES,
        "skills": skills,
        "training_groups": training,
        "auto_position_weights": cat["auto_position_weights"],
        "ovr_weights": weights,
        "boosters": [
            {"id": b["id"], "zh": b["label"], "effects": {str(k): int(v) for k, v in b["effects"].items()},
             "conditional": bool(b.get("conditional")), "category": b.get("category", 0)}
            for b in cat["boosters"]
        ],
        "card_types": CARD_TYPES,
        "traits": TRAITS,
        "nations": nations,
        "teams": teams,
        "archetypes": archetypes(source, cat, abilities, weights),
    }
    output = pathlib.Path(args.output)
    if not output.is_absolute():
        output = pathlib.Path(__file__).absolute().parent.parent / output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(json.dumps({
        "output": str(output),
        "abilities": len(abilities), "skills": len(skills), "boosters": len(data["boosters"]),
        "nations": len(nations), "teams": len(teams), "archetypes": len(data["archetypes"]),
        "bytes": output.stat().st_size,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
