"""球员工坊 · 制作器 — 本地球员创作工作台。

不读取 APK：只使用内置静态资料与本机文件。所有内容保存在程序旁边的 data 目录，
所有请求只走 127.0.0.1。这个文件只负责本地文件读写和静态页面，卡面渲染、
模型取景与数据打包都在浏览器里完成。
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import logging
import mimetypes
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import urllib.request
from urllib.parse import parse_qs, quote, unquote, urlsplit
import uuid
import webbrowser
import zipfile

APP_NAME = "球员工坊 · 制作器"
APP_VERSION = "1.0.0"
BUNDLE = Path(getattr(sys, "_MEIPASS", Path(__file__).absolute().parent))
WEB = BUNDLE / "web"
RESOURCES = BUNDLE / "resources"
HOME = Path(sys.executable).absolute().parent if getattr(sys, "frozen", False) else Path(__file__).absolute().parent

ASSET_NAME = re.compile(r"^[a-f0-9]{64}\.(png|jpg|jpeg|webp|gif|glb|gltf|obj|bin|ktx2)$", re.I)
SAFE_FILE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
MAX_ASSET = 256 * 1024 * 1024
STAMP = re.compile(r"^\d{8}-\d{6}$")


def clean_name(value: str, fallback: str = "文件", limit: int = 80) -> str:
    name = SAFE_FILE.sub("_", str(value or "")).strip().strip(".")
    return (name[:limit] or fallback)


def slug(value: str) -> str:
    text = re.sub(r"[^\w\u4e00-\u9fff-]+", "-", str(value or "")).strip("-")
    return text[:40] or "player"


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + secrets.token_hex(4))
    temp.write_bytes(data)
    os.replace(temp, path)


class Store:
    def __init__(self, root: Path):
        self.root = root
        self.players = root / "players"
        self.assets = root / "assets"
        self.exports = root / "exports"
        self.backups = root / "backups"
        self.tmp = root / "tmp"
        for folder in (self.root, self.players, self.assets, self.exports, self.backups, self.tmp):
            folder.mkdir(parents=True, exist_ok=True)
        self.settings_path = root / "settings.json"
        self.settings = self._load_settings()
        self.catalog = json.loads((RESOURCES / "catalog.json").read_text(encoding="utf-8"))
        self.ability_indices = [row["index"] for row in self.catalog["abilities"]]
        tempfile.tempdir = str(self.tmp)

    def _load_settings(self) -> dict:
        try:
            return {**{"autosave": True, "sidebar": True}, **json.loads(self.settings_path.read_text(encoding="utf-8"))}
        except (OSError, ValueError):
            return {"autosave": True, "sidebar": True}

    def save_settings(self, values: dict) -> dict:
        self.settings = {**self.settings, **{k: v for k, v in values.items() if k in ("autosave", "sidebar")}}
        atomic_write(self.settings_path, json.dumps(self.settings, ensure_ascii=False, indent=2).encode("utf-8"))
        return self.settings

    # ---- projects -------------------------------------------------------
    def project_path(self, pid: str) -> Path:
        try:
            return self.players / (str(uuid.UUID(str(pid))) + ".json")
        except ValueError:
            raise ValueError("工程编号无效") from None

    def default_project(self, name: str = "我的球员", card_type: str = "Epic") -> dict:
        six = self.catalog["six_stats"]
        abilities = {str(index): 65 for index in self.ability_indices}
        card = next((row for row in self.catalog["card_types"] if row["id"] == card_type), self.catalog["card_types"][0])
        training = {row["id"]: 0 for row in self.catalog["training_groups"]}
        return {
            "format": "player-maker/player",
            "version": 1,
            "id": str(uuid.uuid4()),
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "identity": {
                "name": name, "shirt_name": "", "age": 22, "height_cm": 180, "weight_kg": 75,
                "foot": "右脚", "number": 10, "position": "CF",
                "nation_id": 7, "nation": "中国", "team_id": None, "team": "MY CLUB",
            },
            "card": {
                "type": card["id"], "series": card["id"].upper(), "title": "PERSONAL EDITION",
                "serial": 1, "rarity": 5, "date": "", "template": card["theme"],
                "accent": card["accent"], "secondary": "#f3e6c4",
                "background_style": "theme", "background_image": None,
                "portrait": None, "use_cutout": True, "photo": {"zoom": 1, "x": 0, "y": 0, "rotate": 0},
                "show": {"stats": True, "skills": True, "serial": True, "badges": True, "stars": True, "number": True},
                "display_name": "",
            },
            "abilities": abilities,
            "position_aptitudes": {row["code"]: (2 if row["code"] == "CF" else 0) for row in self.catalog["positions"]},
            "play_style": {"attack": 1, "defense": 0},
            "traits": {"weak_foot_usage": "普通", "weak_foot_accuracy": "普通", "form": "稳定", "injury": "普通"},
            "condition": "auto",
            "level": {"initial": 1, "max": 35},
            "training": training,
            "boosters": [0, 0],
            "skills": {"innate": [], "additional": []},
            "ai_styles": [],
            "model": {"asset": None, "name": "", "format": "", "transform": {"scale": 1, "rotate": 0, "lift": 0},
                      "capture": None, "stats": None},
            "notes": "",
            "six_stats": [row["key"] for row in six],
        }

    def normalize_project(self, project: dict) -> dict:
        if not isinstance(project, dict):
            raise ValueError("球员资料需要是 JSON 对象")
        if project.get("format") != "player-maker/player":
            raise ValueError("不是制作器的球员资料")
        try:
            project["id"] = str(uuid.UUID(str(project.get("id") or uuid.uuid4())))
        except ValueError:
            raise ValueError("球员编号无效") from None
        if not isinstance(project.get("identity"), dict):
            raise ValueError("球员资料格式不正确")
        for key in ("abilities", "training"):
            if not isinstance(project.get(key), dict):
                raise ValueError("球员数据格式不正确")
        project["updated_at"] = now_iso()
        project.setdefault("created_at", project["updated_at"])
        return project

    def save_project(self, project: dict) -> dict:
        project = self.normalize_project(project)
        path = self.project_path(project["id"])
        if path.is_file():
            self._backup(path)
        atomic_write(path, json.dumps(project, ensure_ascii=False, indent=1).encode("utf-8"))
        return project

    def _backup(self, path: Path) -> None:
        try:
            stamp = time.strftime("%Y%m%d-%H%M%S")
            target = self.backups / f"{path.stem}-{stamp}-{secrets.token_hex(2)}.json"
            shutil.copy2(path, target)
            old = sorted(self.backups.glob(path.stem + "-*.json"))
            for item in old[:-30]:
                item.unlink(missing_ok=True)
        except OSError:
            logging.warning("backup failed for %s", path, exc_info=True)

    def load_project(self, pid: str) -> dict:
        path = self.project_path(pid)
        if not path.is_file():
            raise ValueError("找不到这名球员")
        return json.loads(path.read_text(encoding="utf-8"))

    def list_projects(self) -> list[dict]:
        rows = []
        for path in self.players.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            identity = data.get("identity") or {}
            card = data.get("card") or {}
            rows.append({
                "id": data.get("id"), "name": identity.get("name") or "未命名球员",
                "position": identity.get("position") or "CF", "card_type": card.get("type") or "Epic",
                "updated_at": data.get("updated_at"), "card": card,
                "level": (data.get("level") or {}).get("initial", 1),
                "portrait": card.get("portrait"), "model": (data.get("model") or {}).get("asset"),
                "project": data,
            })
        rows.sort(key=lambda row: row.get("updated_at") or "", reverse=True)
        return rows

    def delete_project(self, pid: str) -> None:
        path = self.project_path(pid)
        if path.is_file():
            path.unlink()
        for item in self.backups.glob(path.stem + "-*.json"):
            item.unlink(missing_ok=True)

    # ---- assets ---------------------------------------------------------
    def save_asset(self, data: bytes, filename: str, kind: str = "") -> dict:
        if not data:
            raise ValueError("文件是空的")
        if len(data) > MAX_ASSET:
            raise ValueError("文件超过 256 MB，请先压缩")
        ext = Path(filename).suffix.lower().lstrip(".")
        if ext not in ("png", "jpg", "jpeg", "webp", "gif", "glb", "gltf", "obj", "bin", "ktx2"):
            raise ValueError("不支持的文件类型：" + ext)
        digest = hashlib.sha256(data).hexdigest()
        stored = f"{digest}.{ext}"
        target = self.assets / stored
        if not target.is_file():
            atomic_write(target, data)
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        return {"id": stored, "name": clean_name(Path(filename).name, "素材"), "size": len(data), "mime": mime, "kind": kind}

    def asset_file(self, name: str) -> Path:
        if not ASSET_NAME.fullmatch(name):
            raise FileNotFoundError(name)
        path = self.assets / name
        if not path.is_file():
            raise FileNotFoundError(name)
        return path

    # ---- exports --------------------------------------------------------
    def export_folder(self, batch: str = "") -> Path:
        batch = clean_name(batch, "导出", 48)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        folder = self.exports / f"{stamp}-{batch}"
        index = 2
        while folder.exists():
            folder = self.exports / f"{stamp}-{batch}-{index}"
            index += 1
        folder.mkdir(parents=True)
        return folder

    def export_dir(self, folder_name: str) -> Path:
        name = clean_name(folder_name, "", 120)
        if not name or name != folder_name:
            raise ValueError("导出目录无效")
        folder = (self.exports / name).resolve()
        if folder.parent != self.exports.resolve() or not folder.is_dir():
            raise ValueError("导出目录不存在")
        return folder

    def zip_folder(self, folder: Path, zip_name: str) -> Path:
        target = self.exports / clean_name(zip_name, "导出", 120)
        counter = 2
        while target.exists():
            target = self.exports / f"{target.stem}-{counter}{target.suffix}"
            counter += 1
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in folder.rglob("*"):
                if path.is_file():
                    archive.write(path, path.relative_to(folder).as_posix())
        return target

    def project_package(self, pid: str, lang: str = "zh") -> dict:
        project = self.load_project(pid)
        name = (project.get("identity") or {}).get("name") or "球员"
        folder = self.export_folder(("project-" if lang == "en" else "工程-") + slug(name))
        atomic_write(folder / "player.json", json.dumps(project, ensure_ascii=False, indent=1).encode("utf-8"))
        assets_dir = folder / "assets"
        assets_dir.mkdir(exist_ok=True)
        for asset_name in collect_assets(project):
            try:
                source = self.asset_file(asset_name)
            except FileNotFoundError:
                continue
            shutil.copy2(source, assets_dir / asset_name)
        if lang == "en":
            readme = (
                "Player Studio · Maker\n\n"
                f"Player: {(project.get('identity') or {}).get('name') or 'Unnamed'}\n"
                f"ID: {project.get('id')}\n"
                f"Exported: {now_iso()}\n\n"
                "Import this .psplayer back into the studio (Export page → Import project) to keep editing.\n"
                "player.json is readable data; assets holds the card photo and model.\n"
            )
        else:
            readme = (
                f"{APP_NAME} 球员工程\n\n"
                f"球员：{(project.get('identity') or {}).get('name') or '未命名'}\n"
                f"编号：{project.get('id')}\n"
                f"导出时间：{now_iso()}\n\n"
                "把这个 .psplayer 文件拖回制作器，或在“导出”页面点击“导入工程”即可继续编辑。\n"
                "player.json 是可读的数据文件；assets 内是卡面照片和模型。\n"
            )
        atomic_write(folder / "README.txt", readme.encode("utf-8"))
        archive = self.zip_folder(folder, slug(name) + "-" + time.strftime("%Y%m%d") + ".psplayer")
        shutil.rmtree(folder, ignore_errors=True)
        return {"path": str(archive), "name": archive.name, "url": "/exports/" + quote(archive.name), "size": archive.stat().st_size}

    def import_package(self, data: bytes) -> dict:
        if not zipfile.is_zipfile(io.BytesIO(data)):
            raise ValueError("请选择 .psplayer 工程文件")
        work = self.tmp / ("import-" + secrets.token_hex(6))
        work.mkdir(parents=True)
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                for member in archive.infolist():
                    if member.is_dir():
                        continue
                    name = member.filename.replace("\\", "/")
                    if name.startswith("/") or ".." in name.split("/"):
                        continue
                    target = (work / name).resolve()
                    if work.resolve() not in target.parents:
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(archive.read(member))
            project_file = next((path for path in work.rglob("*.json") if path.name.lower() in ("player.json", "project.json")), None)
            if project_file is None:
                raise ValueError("工程包里没有 player.json")
            project = json.loads(project_file.read_text(encoding="utf-8"))
            project = self.normalize_project(project)
            if (self.players / (project["id"] + ".json")).is_file():
                project["id"] = str(uuid.uuid4())
            copied = 0
            asset_dir = project_file.parent / "assets"
            if asset_dir.is_dir():
                for path in asset_dir.iterdir():
                    if path.is_file() and ASSET_NAME.fullmatch(path.name):
                        target = self.assets / path.name
                        if not target.is_file():
                            shutil.copy2(path, target)
                            copied += 1
            project["updated_at"] = now_iso()
            self.save_project(project)
            return {"project": project, "assets": copied}
        finally:
            shutil.rmtree(work, ignore_errors=True)

    def export_zip(self, folder_name: str, zip_name: str) -> dict:
        folder = self.export_dir(folder_name)
        archive = self.zip_folder(folder, zip_name or folder.name)
        shutil.rmtree(folder, ignore_errors=True)
        return {"path": str(archive), "name": archive.name, "url": "/exports/" + quote(archive.name), "size": archive.stat().st_size}


def collect_assets(value) -> set[str]:
    found: set[str] = set()
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, str) and ASSET_NAME.fullmatch(item):
                found.add(item)
            elif isinstance(item, (dict, list)):
                found.update(collect_assets(item))
    elif isinstance(value, list):
        for item in value:
            found.update(collect_assets(item))
    return found


def now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


class StudioServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, store: Store):
        super().__init__(address, Handler)
        self.store = store
        self.token = secrets.token_urlsafe(18)
        self.last_seen = time.monotonic()


class Handler(BaseHTTPRequestHandler):
    server: StudioServer
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        logging.info("%s - %s", self.address_string(), fmt % args)

    # ---- helpers --------------------------------------------------------
    def token_ok(self) -> bool:
        supplied = self.headers.get("X-Studio-Token", "")
        query = parse_qs(urlsplit(self.path).query).get("token", [""])[0]
        return secrets.compare_digest(supplied, self.server.token) or secrets.compare_digest(query, self.server.token)

    def send_json(self, value, status: int = 200) -> None:
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if status >= 400:
            self.send_header("Connection", "close")
            self.close_connection = True
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, body: bytes, mime: str, status: int = 200, extra: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path: Path, mime: str | None = None, download: bool = False) -> None:
        body = path.read_bytes()
        mime = mime or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        extra = {"Content-Disposition": "attachment; filename*=UTF-8''" + quote(path.name)} if download else None
        self.send_bytes(body, mime, extra=extra)

    def read_body(self, limit: int = MAX_ASSET) -> bytes:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            raise ValueError("请求内容为空")
        if length > limit:
            raise ValueError("上传内容过大")
        chunks = []
        remaining = length
        while remaining > 0:
            chunk = self.rfile.read(min(remaining, 1 << 20))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def json_body(self, limit: int = 16 * 1024 * 1024) -> dict:
        body = self.read_body(limit)
        try:
            return json.loads(body.decode("utf-8"))
        except ValueError:
            raise ValueError("请求格式不正确") from None

    # ---- GET ------------------------------------------------------------
    def do_GET(self):
        self.server.last_seen = time.monotonic()
        path = unquote(urlsplit(self.path).path)
        try:
            if path.startswith("/api/"):
                if not self.token_ok():
                    return self.send_json({"error": "本地会话已失效，请重新启动制作器"}, 403)
                return self.get_api(path[5:])
            if path == "/" or path == "/index.html":
                return self.send_file(WEB / "index.html", "text/html; charset=utf-8")
            if path.startswith("/assets/"):
                return self.send_file(self.server.store.asset_file(path.split("/", 2)[2]))
            if path.startswith("/exports/"):
                relative = path[len("/exports/"):]
                parts = [part for part in relative.replace("\\", "/").split("/") if part]
                if not parts or any(part in (".", "..") for part in parts):
                    raise FileNotFoundError(relative)
                target = self.server.store.exports.joinpath(*parts).resolve()
                root = self.server.store.exports.resolve()
                if root not in target.parents or not target.is_file():
                    raise FileNotFoundError(relative)
                return self.send_file(target, download=parse_qs(urlsplit(self.path).query).get("download", [""])[0] == "1")
            if path.startswith("/vendor/") or path.startswith("/pages/") or path.endswith((".js", ".css", ".svg", ".png", ".webp")):
                relative = path.lstrip("/")
                target = (WEB / relative).resolve()
                if WEB.resolve() in target.parents and target.is_file():
                    mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
                    if target.suffix == ".js":
                        mime = "text/javascript; charset=utf-8"
                    return self.send_file(target, mime)
            return self.send_json({"error": "页面不存在"}, 404)
        except FileNotFoundError:
            return self.send_json({"error": "文件不存在"}, 404)
        except Exception as exc:  # noqa: BLE001
            logging.exception("GET failed")
            return self.send_json({"error": str(exc)}, 400)

    def get_api(self, route: str):
        store = self.server.store
        if route == "ping":
            return self.send_json({"ok": True, "version": APP_VERSION, "time": time.time()})
        if route == "bootstrap":
            projects = store.list_projects()
            return self.send_json({
                "app": {"name": APP_NAME, "version": APP_VERSION, "data_dir": str(store.root), "platform": sys.platform},
                "catalog": store.catalog,
                "projects": projects,
                "settings": store.settings,
            })
        if route == "project":
            query = parse_qs(urlsplit(self.path).query)
            pid = query.get("id", [""])[0]
            if not pid:
                raise ValueError("缺少球员编号")
            return self.send_json({"project": store.load_project(pid)})
        if route == "exports":
            rows = []
            for path in sorted(store.exports.iterdir(), reverse=True):
                row = {"name": path.name, "dir": path.is_dir(),
                       "size": path.stat().st_size if path.is_file() else 0,
                       "mtime": path.stat().st_mtime}
                if path.is_dir():
                    row["count"] = sum(1 for item in path.rglob("*") if item.is_file())
                rows.append(row)
            return self.send_json({"rows": rows[:80], "data_dir": str(store.root)})
        return self.send_json({"error": "未知操作"}, 404)

    # ---- POST -----------------------------------------------------------
    def do_POST(self):
        self.server.last_seen = time.monotonic()
        path = unquote(urlsplit(self.path).path)
        if not path.startswith("/api/"):
            return self.send_json({"error": "接口不存在"}, 404)
        if not self.token_ok():
            return self.send_json({"error": "本地会话已失效，请重新启动制作器"}, 403)
        try:
            return self.post_api(path[5:])
        except ValueError as exc:
            return self.send_json({"error": str(exc)}, 400)
        except Exception as exc:  # noqa: BLE001
            logging.exception("POST failed")
            return self.send_json({"error": "操作失败：" + str(exc)}, 500)

    def post_api(self, route: str):
        store = self.server.store
        if route == "project/save":
            body = self.json_body()
            project = store.save_project(body.get("project") or {})
            return self.send_json({"project": project, "id": project["id"], "updated_at": project["updated_at"]})
        if route == "project/delete":
            body = self.json_body()
            store.delete_project(body.get("id"))
            return self.send_json({"deleted": True})
        if route == "project/export":
            body = self.json_body()
            return self.send_json(store.project_package(body.get("id"), self.headers.get("X-Lang", "zh")))
        if route == "project/import":
            data = self.read_body(512 * 1024 * 1024)
            return self.send_json(store.import_package(data))
        if route == "assets":
            filename = unquote(self.headers.get("X-Filename", "image.png"))
            kind = unquote(self.headers.get("X-Kind", "image"))
            data = self.read_body()
            return self.send_json(store.save_asset(data, filename, kind))
        if route == "export/start":
            body = self.json_body()
            folder = store.export_folder(body.get("name") or "导出")
            return self.send_json({"folder": folder.name, "path": str(folder)})
        if route == "export/file":
            filename = clean_name(unquote(self.headers.get("X-Filename", "export.bin")), "export.bin")
            folder_name = unquote(self.headers.get("X-Folder", ""))
            data = self.read_body()
            folder = store.export_dir(folder_name)
            target = folder / filename
            atomic_write(target, data)
            return self.send_json({"path": str(target), "name": target.name, "folder": folder.name, "size": len(data)})
        if route == "export/zip":
            body = self.json_body()
            return self.send_json(store.export_zip(body.get("folder") or "", body.get("name") or ""))
        if route == "reveal":
            body = self.json_body()
            target = Path(body.get("path") or store.exports)
            if not target.exists():
                candidate = store.exports / str(body.get("path") or "")
                target = candidate if candidate.exists() else store.exports
            subprocess.Popen(["explorer", str(target)])
            return self.send_json({"opened": str(target)})
        if route == "settings":
            body = self.json_body()
            return self.send_json({"settings": store.save_settings(body.get("settings") or {})})
        if route == "exit":
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return self.send_json({"closed": True})
        return self.send_json({"error": "未知操作"}, 404)


def open_window(url: str, data: Path) -> None:
    candidates = [
        Path(os.environ.get("PROGRAMFILES(X86)", "C:/Program Files (x86)")) / "Microsoft/Edge/Application/msedge.exe",
        Path(os.environ.get("PROGRAMFILES", "C:/Program Files")) / "Microsoft/Edge/Application/msedge.exe",
        Path(os.environ.get("PROGRAMFILES", "C:/Program Files")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "C:/Program Files (x86)")) / "Google/Chrome/Application/chrome.exe",
    ]
    for exe in candidates:
        if exe.is_file():
            subprocess.Popen([
                str(exe), "--app=" + url, "--window-size=1560,1020", "--no-first-run",
                "--disable-background-mode", "--user-data-dir=" + str(data / "browser"),
            ], close_fds=True)
            return
    webbrowser.open(url)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--data-dir")
    args = parser.parse_args(argv)
    data = Path(args.data_dir).absolute() if args.data_dir else HOME / "data"
    store = Store(data)
    logging.basicConfig(filename=str(store.root / "studio.log"), level=logging.INFO, encoding="utf-8",
                        format="%(asctime)s %(levelname)s %(message)s")
    runtime_path = store.root / "runtime.json"
    if runtime_path.is_file() and not args.no_browser:
        try:
            existing = json.loads(runtime_path.read_text(encoding="utf-8"))
            existing_url = urlsplit(existing["url"])
            if existing_url.hostname != "127.0.0.1":
                raise ValueError("invalid local session")
            existing_token = parse_qs(existing_url.query)["token"][0]
            request = urllib.request.Request(
                f"http://127.0.0.1:{existing['port']}/api/ping",
                headers={"X-Studio-Token": existing_token},
            )
            with urllib.request.urlopen(request, timeout=1.5) as response:
                if json.load(response).get("ok"):
                    open_window(existing["url"], store.root)
                    if sys.stdout:
                        print(json.dumps(existing, ensure_ascii=False), flush=True)
                    return
        except Exception:
            pass
    server = StudioServer(("127.0.0.1", args.port), store)
    url = f"http://127.0.0.1:{server.server_port}/?token={server.token}"
    runtime = {"pid": os.getpid(), "port": server.server_port, "url": url, "version": APP_VERSION}
    atomic_write(store.root / "runtime.json", json.dumps(runtime, ensure_ascii=False, indent=2).encode("utf-8"))
    if sys.stdout:
        print(json.dumps(runtime, ensure_ascii=False), flush=True)
    if not args.no_browser:
        open_window(url, store.root)

    def idle_monitor():
        while True:
            time.sleep(10)
            if time.monotonic() - server.last_seen > 300:
                server.shutdown()
                return

    threading.Thread(target=idle_monitor, daemon=True).start()
    try:
        server.serve_forever(poll_interval=0.3)
    finally:
        server.server_close()
        (store.root / "runtime.json").unlink(missing_ok=True)


if __name__ == "__main__":
    main()
