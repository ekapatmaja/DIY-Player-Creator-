@echo off
chcp 65001 >nul
cd /d "%~dp0"

if exist "球员工坊-制作器.exe" (
  start "" "球员工坊-制作器.exe"
  exit /b 0
)

where pythonw >nul 2>nul
if not errorlevel 1 (
  start "" pythonw "app.py"
  exit /b 0
)

where python >nul 2>nul
if not errorlevel 1 (
  start /min "" python "app.py"
  exit /b 0
)

echo.
echo 没有找到 Python 3，也没有找到 球员工坊-制作器.exe。
echo 请安装 Python 3.10 或更高版本，或使用打包好的 exe 版本。
echo.
pause
