/* 与本地服务通信：只走 127.0.0.1，所有写操作都带本地会话令牌。 */

import { getLang, localizeError, tr, tf } from './i18n.js';

const TOKEN = window.__MAKER_TOKEN__ || new URLSearchParams(location.search).get('token') || '';

async function readJson(response) {
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { error: tr('服务器返回了无法识别的内容') }; }
  if (!response.ok) throw new Error(localizeError(data.error || tf('操作失败（{status}）', { status: response.status })));
  return data;
}

export async function api(path, body) {
  const response = await fetch('/api/' + path, {
    method: body === undefined ? 'GET' : 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Studio-Token': TOKEN, 'X-Lang': getLang() },
    body: body === undefined ? undefined : JSON.stringify(body),
    cache: 'no-store',
  });
  return readJson(response);
}

export async function upload(path, blob, headers = {}) {
  const response = await fetch('/api/' + path, {
    method: 'POST',
    headers: { 'X-Studio-Token': TOKEN, 'X-Lang': getLang(), ...headers },
    body: blob,
    cache: 'no-store',
  });
  return readJson(response);
}

export function assetUrl(id) {
  return id ? '/assets/' + encodeURIComponent(id) : '';
}

export async function uploadAsset(file, kind = 'image') {
  const name = encodeURIComponent(file.name || (kind === 'model' ? 'model.glb' : 'image.png'));
  return upload('assets', file, { 'X-Filename': name, 'X-Kind': kind, 'Content-Type': file.type || 'application/octet-stream' });
}

export async function blobToFile(blob, name) {
  return new File([blob], name, { type: blob.type || 'application/octet-stream' });
}

export async function uploadAssetBlob(blob, name, kind = 'image') {
  return uploadAsset(await blobToFile(blob, name), kind);
}

export async function startExport(name) {
  return api('export/start', { name });
}

export async function saveExportFile(folder, name, blob) {
  return upload('export/file', blob, {
    'X-Filename': encodeURIComponent(name),
    'X-Folder': encodeURIComponent(folder),
    'Content-Type': blob.type || 'application/octet-stream',
  });
}

export async function finishExport(folder, name) {
  return api('export/zip', { folder, name });
}

export async function exportProject(id) {
  return api('project/export', { id });
}

export async function importProject(file) {
  return upload('project/import', file, { 'Content-Type': 'application/zip' });
}

export async function reveal(path) {
  return api('reveal', path ? { path } : {});
}
