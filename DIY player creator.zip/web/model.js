/* three.js 模型工作区：导入 GLB / GLTF / OBJ，预览、统计、取景和导出。 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { OBJExporter } from 'three/addons/exporters/OBJExporter.js';
import { assetUrl } from './api.js';
import { tr, tf, isEn } from './i18n.js';

function disposeObject(root) {
  if (!root) return;
  const geometries = new Set();
  const materials = new Set();
  const textures = new Set();
  root.traverse(node => {
    if (node.geometry) geometries.add(node.geometry);
    for (const material of (Array.isArray(node.material) ? node.material : [node.material])) {
      if (!material) continue;
      materials.add(material);
      for (const value of Object.values(material)) if (value?.isTexture) textures.add(value);
    }
  });
  geometries.forEach(item => item.dispose());
  materials.forEach(item => item.dispose());
  textures.forEach(item => item.dispose());
}

function setShadows(root) {
  root.traverse(node => {
    if (node.isMesh) {
      node.castShadow = true;
      node.receiveShadow = true;
      const materials = Array.isArray(node.material) ? node.material : [node.material];
      for (const material of materials) {
        if (!material) continue;
        material.side = THREE.FrontSide;
        if (material.map) material.map.colorSpace = THREE.SRGBColorSpace;
      }
    }
  });
}

/** 取景后裁掉透明边，卡面里的人物才不会缩在一大块空白中间。 */
function cropTransparent(source, padding = 16) {
  const width = source.width;
  const height = source.height;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d', { willReadFrequently: true });
  context.drawImage(source, 0, 0);
  const data = context.getImageData(0, 0, width, height).data;
  let minX = width, minY = height, maxX = -1, maxY = -1;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      if (data[(y * width + x) * 4 + 3] > 8) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (maxX < 0) return new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
  const x0 = Math.max(0, minX - padding);
  const y0 = Math.max(0, minY - padding);
  const w = Math.min(width - 1, maxX + padding) - x0 + 1;
  const h = Math.min(height - 1, maxY + padding) - y0 + 1;
  const out = document.createElement('canvas');
  out.width = w;
  out.height = h;
  out.getContext('2d').drawImage(canvas, x0, y0, w, h, 0, 0, w, h);
  return new Promise(resolve => out.toBlob(resolve, 'image/png'));
}

export class ModelViewer {
  constructor(onStatus) {
    this.onStatus = onStatus;
    this.options = { wireframe: false, skeleton: false, rotate: false };
    this.animations = [];
    this.mixer = null;
    this.metadata = null;
    this.wrapper = document.createElement('div');
    this.wrapper.style.cssText = 'width:100%;height:100%;position:relative';
    this.scene = new THREE.Scene();
    this.lastFrame = performance.now();
    try {
      this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    } catch (error) {
      this.failed = true;
      this.wrapper.innerHTML = `<div class="model-empty">${tr('当前浏览器无法创建 3D 画面。请使用 Edge 或 Chrome，并在设置里开启图形加速。')}</div>`;
      return;
    }
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.domElement.style.display = 'block';
    this.wrapper.append(this.renderer.domElement);

    this.camera = new THREE.PerspectiveCamera(32, 1, 0.01, 120);
    this.camera.position.set(1.5, 1.2, 3.1);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.set(0, 0.95, 0);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.minDistance = 0.3;
    this.controls.maxDistance = 12;
    this.controls.maxPolarAngle = Math.PI * 0.56;

    this.scene.add(new THREE.HemisphereLight(0xd8ecff, 0x2b3642, 2.4));
    const key = new THREE.DirectionalLight(0xfff0dc, 3.0);
    key.position.set(2.2, 4.5, 3.4);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.camera.left = -2;
    key.shadow.camera.right = 2;
    key.shadow.camera.top = 3;
    key.shadow.camera.bottom = -2;
    this.scene.add(key);
    const fill = new THREE.DirectionalLight(0x9ccaff, 2.1);
    fill.position.set(-3, 2, -1.5);
    this.scene.add(fill);
    const rim = new THREE.DirectionalLight(0x9dffd9, 1.6);
    rim.position.set(0, 2.6, -3);
    this.scene.add(rim);

    this.floor = new THREE.Mesh(
      new THREE.CylinderGeometry(0.86, 0.94, 0.05, 72),
      new THREE.MeshStandardMaterial({ color: 0x1b2833, roughness: 0.62, metalness: 0.35 })
    );
    this.floor.position.y = -0.055;
    this.floor.receiveShadow = true;
    this.scene.add(this.floor);
    this.grid = new THREE.GridHelper(12, 48, 0x2a4050, 0x1b2c37);
    this.grid.position.y = -0.085;
    this.grid.material.transparent = true;
    this.grid.material.opacity = 0.3;
    this.scene.add(this.grid);

    this.readout = document.createElement('div');
    this.readout.className = 'model-readout';
    this.readout.textContent = tr('正在准备 3D 工作区…');
    this.wrapper.append(this.readout);

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.wrapper);
    this.animate();
  }

  attach(container) {
    if (!container || this.failed) return;
    if (this.wrapper.parentElement !== container) container.append(this.wrapper);
    requestAnimationFrame(() => this.resize());
  }

  resize() {
    if (this.failed) return;
    const width = this.wrapper.clientWidth;
    const height = this.wrapper.clientHeight;
    if (width < 2 || height < 2) return;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.render();
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    if (this.failed) return;
    const now = performance.now();
    const delta = Math.min((now - this.lastFrame) / 1000, 0.1);
    this.lastFrame = now;
    if (!this.wrapper.isConnected || !this.wrapper.offsetWidth) return;
    this.controls.autoRotate = this.options.rotate;
    this.controls.autoRotateSpeed = 0.9;
    this.controls.update();
    this.mixer?.update(delta);
    this.render();
  }

  render() {
    if (this.failed || !this.renderer) return;
    this.renderer.render(this.scene, this.camera);
  }

  setOptions(values) {
    this.options = { ...this.options, ...values };
    if (this.skeletonHelper) this.skeletonHelper.visible = Boolean(this.options.skeleton);
    if (this.subject) {
      this.subject.traverse(node => {
        if (!node.isMesh) return;
        for (const material of (Array.isArray(node.material) ? node.material : [node.material])) {
          if (material) material.wireframe = Boolean(this.options.wireframe);
        }
      });
    }
    if (this.options.skeleton && !this.skeletonHelper && this.subject && this.metadata?.bones) {
      this.skeletonHelper = new THREE.SkeletonHelper(this.subject);
      this.skeletonHelper.material.depthTest = false;
      this.scene.add(this.skeletonHelper);
    }
    this.render();
  }

  async load(id, name = '') {
    if (this.failed) throw new Error(tr('当前环境不支持 3D 预览'));
    this.clear();
    this.assetId = id;
    this.sourceName = name;
    this.readout.textContent = tr('正在读取模型…');
    const url = assetUrl(id);
    const extension = (name || id).split('.').pop().toLowerCase();
    let object;
    let animations = [];
    try {
      if (extension === 'glb' || extension === 'gltf') {
        const gltf = await new GLTFLoader().loadAsync(url);
        object = gltf.scene || gltf.scenes?.[0];
        animations = gltf.animations || [];
      } else if (extension === 'obj') {
        const text = await (await fetch(url)).text();
        object = new OBJLoader().parse(text);
      } else {
        throw new Error(tr('只支持 GLB、GLTF 和 OBJ 模型'));
      }
    } catch (error) {
      this.readout.textContent = tr('模型读取失败');
      throw new Error(tf('模型无法解析：{msg}。Draco / Meshopt 压缩的模型需要先解压。', { msg: error.message || error }));
    }
    if (!object) throw new Error(tr('模型里没有可显示的网格'));
    object.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(object);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const largest = Math.max(size.y, size.x, size.z, 0.001);
    const factor = 1.75 / largest;
    const wrapper = new THREE.Group();
    wrapper.name = 'PlayerModelPreview';
    wrapper.add(object);
    object.position.set(-center.x * factor, -box.min.y * factor, -center.z * factor);
    object.scale.setScalar(factor);
    wrapper.userData.baseScale = factor;
    setShadows(object);
    this.subject = wrapper;
    this.original = object;
    this.animations = animations;
    this.mixer = animations.length ? new THREE.AnimationMixer(object) : null;
    this.scene.add(wrapper);

    let meshes = 0, triangles = 0, vertices = 0, bones = 0, materials = 0;
    const textureSet = new Set();
    object.traverse(node => {
      if (node.isMesh) {
        meshes += 1;
        const geometry = node.geometry;
        const count = geometry.index ? geometry.index.count : geometry.attributes.position?.count || 0;
        triangles += Math.round(count / 3);
        vertices += geometry.attributes.position?.count || 0;
        for (const material of (Array.isArray(node.material) ? node.material : [node.material])) {
          if (!material) continue;
          materials += 1;
          for (const value of Object.values(material)) if (value?.isTexture) textureSet.add(value.uuid);
        }
      }
      if (node.isBone) bones += 1;
    });
    this.metadata = {
      meshes, triangles, vertices, bones, materials, textures: textureSet.size,
      animations: animations.map(clip => clip.name || tr('未命名动画')),
      dimensions: { x: size.x * factor, y: size.y * factor, z: size.z * factor },
      original: { x: size.x, y: size.y, z: size.z },
    };
    this.updateReadout();
    this.view('fit');
    this.applyTransform();
    this.setOptions({});
    this.onStatus?.(this.metadata);
    return this.metadata;
  }

  updateReadout() {
    if (!this.readout) return;
    if (!this.subject || !this.metadata) {
      this.readout.textContent = tr('还没有导入模型');
      return;
    }
    const meta = this.metadata;
    const parts = [
      `${tr('网格')} ${meta.meshes}`,
      `${tr('三角面')} ${meta.triangles.toLocaleString(isEn() ? 'en-US' : 'zh-CN')}`,
    ];
    if (meta.bones) parts.push(`${tr('骨骼')} ${meta.bones}`);
    this.readout.innerHTML = `<strong>${this.sourceName || tr('已导入模型')}</strong> · ${parts.join(' · ')}`;
  }

  refreshLanguage() {
    if (this.failed) return;
    this.updateReadout();
  }

  applyTransform(transform = {}) {
    if (!this.subject) return;
    const scale = Number(transform.scale) || 1;
    this.subject.scale.setScalar(scale);
    this.subject.rotation.y = THREE.MathUtils.degToRad(Number(transform.rotate) || 0);
    this.subject.position.y = Number(transform.lift) || 0;
    this.render();
  }

  view(mode) {
    if (!this.subject) return;
    const box = new THREE.Box3().setFromObject(this.subject);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    if (mode === 'head') {
      const y = box.max.y - size.y * 0.1;
      this.camera.position.set(center.x + 0.18, y + 0.06, center.z + Math.max(0.75, size.y * 0.55));
      this.controls.target.set(center.x, y, center.z);
    } else if (mode === 'front') {
      this.camera.position.set(center.x, center.y + size.y * 0.05, center.z + Math.max(1.6, size.y * 1.35));
      this.controls.target.set(center.x, center.y, center.z);
    } else if (mode === 'side') {
      this.camera.position.set(center.x + Math.max(1.8, size.y * 1.5), center.y + size.y * 0.05, center.z + 0.2);
      this.controls.target.set(center.x, center.y, center.z);
    } else if (mode === 'three-quarter') {
      this.camera.position.set(center.x + size.y * 1.05, center.y + size.y * 0.16, center.z + size.y * 1.15);
      this.controls.target.set(center.x, center.y, center.z);
    } else {
      const distance = Math.max(3.1, size.y * 2.35);
      this.camera.position.set(center.x + distance * 0.45, center.y + size.y * 0.28, center.z + distance * 0.9);
      this.controls.target.set(center.x, center.y * 0.94, center.z);
    }
    this.controls.update();
    this.render();
  }

  async capture(mode = 'portrait') {
    if (!this.subject) throw new Error(tr('请先导入模型'));
    const portrait = mode !== 'avatar';
    const width = portrait ? 1024 : 640;
    const height = portrait ? 1536 : 640;
    const previous = {
      size: this.renderer.getSize(new THREE.Vector2()),
      ratio: this.renderer.getPixelRatio(),
      position: this.camera.position.clone(),
      target: this.controls.target.clone(),
      aspect: this.camera.aspect,
      floor: this.floor.visible,
      grid: this.grid.visible,
      helper: this.skeletonHelper?.visible,
      rotate: this.options.rotate,
    };
    this.options.rotate = false;
    this.floor.visible = false;
    this.grid.visible = false;
    if (this.skeletonHelper) this.skeletonHelper.visible = false;
    this.renderer.setPixelRatio(1);
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    const box = new THREE.Box3().setFromObject(this.subject);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const vTan = Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2);
    const hTan = vTan * this.camera.aspect;
    const fitDistance = (halfWidth, halfHeight) => Math.max(halfHeight / vTan, halfWidth / hTan) + size.z * 0.35 + 0.12;
    if (portrait) {
      const distance = fitDistance(size.x * 0.56, size.y * 0.56);
      this.camera.position.set(center.x, center.y + size.y * 0.01, center.z + distance);
      this.controls.target.set(center.x, center.y, center.z);
    } else {
      const y = box.max.y - size.y * 0.15;
      const distance = fitDistance(size.x * 0.42, size.y * 0.3);
      this.camera.position.set(center.x, y, center.z + distance);
      this.controls.target.set(center.x, y, center.z);
    }
    this.controls.update();
    this.camera.updateMatrixWorld();
    this.renderer.render(this.scene, this.camera);
    const blob = await cropTransparent(this.renderer.domElement);
    this.renderer.setPixelRatio(previous.ratio);
    this.renderer.setSize(previous.size.x, previous.size.y, false);
    this.camera.aspect = previous.aspect;
    this.camera.position.copy(previous.position);
    this.controls.target.copy(previous.target);
    this.camera.updateProjectionMatrix();
    this.floor.visible = previous.floor;
    this.grid.visible = previous.grid;
    if (this.skeletonHelper) this.skeletonHelper.visible = previous.helper;
    this.options.rotate = previous.rotate;
    this.controls.update();
    this.render();
    if (!blob) throw new Error(tr('取景失败，请重试'));
    return blob;
  }

  async exportGLB() {
    if (!this.subject || !this.original) throw new Error(tr('请先导入模型'));
    const array = await new GLTFExporter().parseAsync(this.original, { binary: true, animations: this.animations });
    return new Blob([array], { type: 'model/gltf-binary' });
  }

  async originalBlob() {
    if (!this.assetId) throw new Error(tr('请先导入模型'));
    const response = await fetch(assetUrl(this.assetId));
    if (!response.ok) throw new Error(tr('原始模型读取失败'));
    return response.blob();
  }

  exportOBJ() {
    if (!this.original) throw new Error(tr('请先导入模型'));
    const text = new OBJExporter().parse(this.original);
    return new Blob([text], { type: 'text/plain' });
  }

  clear() {
    this.mixer?.stopAllAction();
    this.mixer = null;
    this.animations = [];
    if (this.skeletonHelper) {
      this.scene.remove(this.skeletonHelper);
      this.skeletonHelper.dispose();
      this.skeletonHelper = null;
    }
    if (this.subject) {
      this.scene.remove(this.subject);
      disposeObject(this.subject);
      this.subject = null;
      this.original = null;
    }
    this.metadata = null;
    this.readout.textContent = tr('还没有导入模型');
    this.render();
  }
}
