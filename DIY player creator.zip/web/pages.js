/* 页面模板：只负责生成 HTML，交互与数据更新在 app.js。 */

import { esc, positionName, cardType, abilityRows, byIndex, ratingColor } from './core.js';
import { panel, field, rangeField, toggle, icon, formatTime, emptyState } from './ui.js';
import { CARD_TEMPLATES, templateById } from './card.js';
import { assetUrl } from './api.js';
import {
  tr, tf, isEn, positionLabel, cardTypeLabel, templateLabel, abilityLabel, skillLabel,
  boosterLabel, traitLabel, footLabel, groupLabel, trainingLabel, nationDisplay, teamDisplay,
  aiStyleLabel,
} from './i18n.js';

export const PAGES = {
  players: { title: '我的球员', short: '我的球员', icon: 'players', eyebrow: 'CREATE YOUR OWN LEGACY', description: '管理本机的球员工程，随时打开、复制或导出。' },
  profile: { title: '球员资料', short: '资料', icon: 'user', eyebrow: 'IDENTITY', description: '名字、位置、身材与卡种，先确定这名球员是谁。' },
  abilities: { title: '基础能力', short: '能力', icon: 'chart', eyebrow: 'BUILD THE PLAYER', description: '设定 1 级基础值；右侧总评会随培养与增能实时变化。' },
  training: { title: '培养模拟', short: '培养', icon: 'grow', eyebrow: 'LEVEL UP', description: '按等级预算分配培养点，比较不同方案的最终能力与总评。' },
  skills: { title: '技能与风格', short: '技能', icon: 'spark', eyebrow: 'SIGNATURE STYLE', description: '搭配天生与额外习得技能，再选比赛风格。' },
  card: { title: '卡面设计', short: '卡面', icon: 'image', eyebrow: 'DESIGN THE CARD', description: '导入照片、选模板、调构图，导出一张 1200 × 1720 的卡面。' },
  model: { title: '模型工作区', short: '模型', icon: 'cube', eyebrow: 'SHAPE YOUR PLAYER', description: '导入 GLB / OBJ，预览、取景成卡面照片，或重新导出模型。' },
  export: { title: '导出与工程', short: '导出', icon: 'export', eyebrow: 'TAKE IT WITH YOU', description: '把卡面、数据和模型打包；也可以备份或导入工程。' },
  help: { title: '使用说明', short: '说明', icon: 'help', eyebrow: 'HOW IT WORKS', description: '三分钟了解制作器的工作方式。' },
};

export function pageMeta(id) {
  const page = PAGES[id] || PAGES.players;
  return { ...page, title: tr(page.title), short: tr(page.short), description: tr(page.description) };
}

const numLocale = () => isEn() ? 'en-US' : 'zh-CN';

export function renderPlayers(app) {
  const projects = app.projects || [];
  const cards = projects.map(row => {
    const type = cardType(app.catalog, row.card_type);
    return `<article class="player-card ${row.id === app.player?.id ? 'current' : ''}">
      <div class="player-thumb-wrap">
        <canvas class="player-thumb" data-player-thumb="${esc(row.id)}" width="300" height="430"></canvas>
        <span class="player-badge" style="color:${esc(type.accent)}">${esc(cardTypeLabel(type))}</span>
      </div>
      <div class="player-info">
        <strong>${esc(row.name)}</strong>
        <small>${esc(row.position)} · ${esc(positionLabel(row.position))} · Lv.${esc(row.level || 1)}</small>
        <small>${esc(formatTime(row.updated_at))}</small>
      </div>
      <div class="player-actions">
        <button class="button secondary" data-open-player="${esc(row.id)}">${tr('打开')}</button>
        <button class="button subtle" data-export-player="${esc(row.id)}">${tr('导出')}</button>
        <button class="button subtle" data-duplicate-player="${esc(row.id)}" title="${tr('复制这名球员')}">${tr('复制')}</button>
        <button class="button subtle" data-delete-player="${esc(row.id)}" title="${tr('删除')}">${tr('删除')}</button>
      </div>
    </article>`;
  }).join('');
  return `<div class="row-between" style="margin-bottom:14px">
      <span class="inline-tip">${projects.length ? esc(tf('共 {n} 名球员 · 当前编辑：{name}', { n: projects.length, name: app.player?.identity.name || '' })) : tr('还没有保存的球员')}</span>
      <div class="row"><button class="button secondary" data-action="import-project">${icon('upload')}${tr('导入工程')}</button><button class="button primary" data-action="new-player">${icon('plus')}${tr('新建球员')}</button></div>
    </div>
    ${projects.length ? `<div class="player-grid">${cards}</div>` : emptyState(tr('从第一名球员开始'), tr('填写资料、调整能力、设计卡面，所有内容都会自动保存在本机。<br>不需要 APK，也不会改动游戏文件。'), `<button class="button primary" data-action="new-player">${icon('plus')}${tr('新建球员')}</button>`)}
    <p class="note">${tr('提示：双击球员卡也可以打开。右键浏览器窗口可刷新；数据保存在程序目录的 <code>data/players</code>。')}</p>`;
}

export function renderProfile(app) {
  const { player, catalog } = app;
  const identity = player.identity;
  const card = player.card;
  const nationValue = nationDisplay(catalog, identity);
  const teamValue = teamDisplay(catalog, identity);
  const nationList = `<datalist id="nation-list">${catalog.nations.map(row => `<option value="${esc(isEn() ? row.en : row.zh)}">${esc(isEn() ? row.zh : row.en)}</option>`).join('')}</datalist>`;
  const teamList = `<datalist id="team-list">${catalog.teams.map(row => `<option value="${esc(isEn() ? row.en : row.zh)}">#${row.id}</option>`).join('')}</datalist>`;
  const positions = catalog.positions.map(row => [row.code, `${row.code} · ${positionLabel(row.code)}`]);
  const typeOptions = catalog.card_types.map(row => `<button class="type-option ${card.type === row.id ? 'active' : ''}" data-card-type="${esc(row.id)}"><strong>${esc(cardTypeLabel(row))}</strong><small>${esc(row.code || row.id)}</small></button>`).join('');
  const traitChoices = values => values.map(value => [value, traitLabel(value)]);
  return `${nationList}${teamList}
    ${panel(tr('基本信息'), `<div class="field-grid three">
      ${field(tr('球员姓名'), 'identity.name', identity.name, { placeholder: tr('例如：凌 风'), hint: tr('卡面显示名可以单独设置') })}
      ${field(tr('球衣背后名字'), 'identity.shirt_name', identity.shirt_name, { placeholder: tr('留空则使用姓名') })}
      ${field(tr('卡面显示名'), 'card.display_name', card.display_name, { placeholder: tr('留空则使用姓名') })}
      ${field(tr('国籍 / 地区'), 'identity.nation', nationValue, { list: 'nation-list', hint: tr('输入中文或英文名称搜索') })}
      ${field(tr('俱乐部 / 球队'), 'identity.team', teamValue, { list: 'team-list', hint: tr('可以填写任意名称') })}
      ${field(tr('主要位置'), 'identity.position', identity.position, { choices: positions })}
      ${field(tr('惯用脚'), 'identity.foot', identity.foot, { choices: [['右脚', footLabel('右脚')], ['左脚', footLabel('左脚')]] })}
      ${field(tr('身高'), 'identity.height_cm', identity.height_cm, { type: 'number', min: 140, max: 220, unit: 'cm' })}
      ${field(tr('体重'), 'identity.weight_kg', identity.weight_kg, { type: 'number', min: 40, max: 140, unit: 'kg' })}
      ${field(tr('年龄'), 'identity.age', identity.age, { type: 'number', min: 15, max: 60, unit: tr('岁') })}
      ${field(tr('球衣号码'), 'identity.number', identity.number, { type: 'number', min: 1, max: 99 })}
    </div>`, 'PROFILE')}
    ${panel(tr('卡种与卡面资料'), `<div class="type-grid">${typeOptions}</div>
      <div class="field-grid three" style="margin-top:16px">
        ${field(tr('卡面系列'), 'card.series', card.series, { placeholder: tr('例如：EPIC / BIG TIME') })}
        ${field(tr('卡面标题'), 'card.title', card.title, { placeholder: 'PERSONAL EDITION', hint: tr('显示在卡面顶部的小字') })}
        ${field(tr('卡面编号'), 'card.serial', card.serial, { type: 'number', min: 1, max: 9999, hint: tr('显示为 NO.0001') })}
        ${field(tr('卡面星级'), 'card.rarity', card.rarity, { choices: [1, 2, 3, 4, 5].map(n => [n, isEn() ? (n === 1 ? '1 star' : `${n} stars`) : `${n} 星`]) })}
        ${field(tr('纪念日期'), 'card.date', card.date, { placeholder: 'YYYY-MM-DD', hint: tr('留空则不显示') })}
        ${field(tr('实时状态'), 'condition', player.condition, { choices: [['auto', tr('跟随默认规则')], ['A', 'A'], ['B', 'B'], ['C', 'C'], ['D', 'D'], ['E', 'E']] })}
      </div>
      <p class="note">${tr('卡种决定右侧预览的默认配色；卡面模板可以在“卡面设计”里单独更换。')}</p>`, 'CARD')}
    ${panel(tr('其他特征'), `<div class="field-grid three">
      ${field(tr('逆足使用频率'), 'traits.weak_foot_usage', player.traits.weak_foot_usage, { choices: traitChoices(['低', '普通', '高', '极高']) })}
      ${field(tr('逆足精准度'), 'traits.weak_foot_accuracy', player.traits.weak_foot_accuracy, { choices: traitChoices(['低', '普通', '高', '极高']) })}
      ${field(tr('状态持续性'), 'traits.form', player.traits.form, { choices: traitChoices(['稳定', '普通', '不稳定']) })}
      ${field(tr('受伤耐性'), 'traits.injury', player.traits.injury, { choices: traitChoices(['低', '普通', '高']) })}
    </div>`, 'TRAITS')}
    ${panel(tr('备注'), `${field(tr('只保存在本机的备注'), 'notes', player.notes, { type: 'textarea', rows: 4, placeholder: tr('例如：灵感来源、卡面构图想法、下一个能力调整方案…') })}
      <p class="note">${tr('备注不会出现在导出的卡面里，但会写进资料 JSON 与工程文件。')}</p>`, 'NOTES')}`;
}

export function renderAbilities(app) {
  const { player, catalog, sim } = app;
  const groups = catalog.ability_groups;
  const filter = app.abilityFilter || 'all';
  const rows = abilityRows(catalog);
  const shown = groups.filter(group => filter === 'all' || filter === group.name);
  const statRows = shown.map(group => `<div class="stat-section-label">${esc(groupLabel(group.name))}</div>${group.indices.map(index => {
    const row = rows.find(item => item.index === Number(index));
    if (!row) return '';
    const value = player.abilities[String(row.index)] ?? 65;
    const final = sim.final[String(row.index)];
    const delta = final - value;
    const label = abilityLabel(row);
    return `<div class="stat-row">
      <label>${esc(label)}<small>${esc(isEn() ? `#${row.index}` : row.en.toUpperCase())}</small></label>
      <input type="range" data-bind="abilities.${row.index}" min="40" max="105" value="${esc(value)}" aria-label="${esc(label)}">
      <input class="input" type="number" data-bind="abilities.${row.index}" min="40" max="105" value="${esc(value)}" aria-label="${esc(label)}">
      <div class="stat-final" data-stat-final="${row.index}" style="color:${ratingColor(final)}">${final}${delta ? `<small>${delta > 0 ? '+' : ''}${delta}</small>` : ''}</div>
    </div>`;
  }).join('')}`).join('');
  const archetypes = catalog.archetypes.map(row => `<option value="${esc(row.id)}" ${row.id === player.identity.position ? 'selected' : ''}>${esc(row.id)} · ${esc(positionLabel(row.id))} · ${esc(tf('参考 {n} 名球员', { n: row.sample }))}</option>`).join('');
  const aptitudes = catalog.positions.map(row => `<div class="aptitude-cell"><span>${esc(row.code)}</span><select data-bind="position_aptitudes.${row.code}" data-number="1">${catalog.aptitude_levels.map(level => `<option value="${level.value}" ${Number(player.position_aptitudes?.[row.code] || 0) === level.value ? 'selected' : ''}>${esc(tr(level.zh))}</option>`).join('')}</select></div>`).join('');
  const attack = catalog.play_styles.attack.map(row => [String(row.id), tr(row.zh)]);
  const defense = catalog.play_styles.defense.map(row => [String(row.id), tr(row.zh)]);
  return `<div class="row-between" style="margin-bottom:13px">
      <div class="inline-tip">${tr('基础能力范围 40–105 · 培养上限 105')}</div>
      <div class="row">
        <select id="archetype-select" style="min-height:34px;width:auto">${archetypes}</select>
        <button class="button secondary" data-action="load-archetype">${icon('spark')}${tr('套用参考')}</button>
        <button class="button subtle" data-action="reset-abilities">${icon('refresh')}${tr('重置 65')}</button>
      </div>
    </div>
    <div class="filter-tabs"><button class="${filter === 'all' ? 'active' : ''}" data-ability-filter="all">${tr('全部 26 项')}</button>${groups.map(group => `<button class="${filter === group.name ? 'active' : ''}" data-ability-filter="${esc(group.name)}">${esc(groupLabel(group.name))}</button>`).join('')}</div>
    ${panel(tr('基础能力'), `${statRows}<p class="note">${tr('数值越高越强。守门员能力对非门将位置的总评影响很小，但会保留在资料里。')}</p>`, '26 STATS')}
    ${panel(tr('位置适应度'), `<div class="aptitude-grid">${aptitudes}</div><p class="note">${tr('完全适应代表该位置可以正常发挥；部分适应会降低位置表现。')}</p>`, 'APTITUDE')}
    ${panel(tr('比赛风格'), `<div class="field-grid">
      ${field(tr('进攻比赛风格'), 'play_style.attack', player.play_style.attack, { choices: attack, hint: tr('无球跑动、持球习惯的总体倾向') })}
      ${field(tr('防守比赛风格'), 'play_style.defense', player.play_style.defense, { choices: defense })}
    </div>`, 'PLAY STYLE')}`;
}

export function renderTraining(app) {
  const { player, catalog, sim } = app;
  const target = app.trainingTarget || player.identity.position;
  const boosters = [[0, tr('不使用增能')], ...catalog.boosters.map(row => [row.id, boosterLabel(row, catalog)])];
  const groups = catalog.training_groups.map(group => {
    const count = player.training[group.id] || 0;
    const label = trainingLabel(group.zh);
    const rows = group.indices.map(index => {
      const row = byIndex(catalog)[index];
      const base = sim.base[String(index)];
      const trained = sim.trained[String(index)];
      return `<div class="training-stat-row"><span>${esc(row ? abilityLabel(row) : index)}</span><span>${base}</span><strong>${trained}</strong><strong style="color:${ratingColor(sim.final[String(index)])}">${sim.final[String(index)]}</strong></div>`;
    }).join('');
    return `<section class="training-card">
      <h3>${esc(label)}</h3>
      <div class="training-stat-head"><span>${tr('能力')}</span><span>${tr('基础')}</span><span>${tr('培养后')}</span><span>${tr('最终')}</span></div>
      ${rows}
      <div class="stepper">
        <div class="stepper-group"><button data-step="-1" data-group="${esc(group.id)}" aria-label="${tr('减少')}">−</button><input data-bind="training.${esc(group.id)}" type="number" min="0" max="40" value="${count}" aria-label="${esc(label)}"><button data-step="1" data-group="${esc(group.id)}" aria-label="${tr('增加')}">＋</button></div>
        <span data-group-cost="${esc(group.id)}"></span>
      </div>
    </section>`;
  }).join('');
  return `${panel(tr('等级设置'), `<div class="field-grid">
      ${field(tr('模拟当前等级'), 'level.initial', player.level.initial, { type: 'number', min: 1, max: 100, unit: tr('级') })}
      ${field(tr('等级上限'), 'level.max', player.level.max, { type: 'number', min: 1, max: 100, unit: tr('级') })}
    </div><p class="note">${tr('每提升 1 级获得 2 点培养点；同一个项目每加 4 次，下一次消耗增加 1 点。单次培养上限 +40，能力上限 105。')}</p>`, 'LEVEL')}
    <div class="budget-card" id="budget-card">
      <div class="budget-metrics">
        <div><span>${tr('等级提供')}</span><strong id="budget-total">0<small>${tr('点')}</small></strong></div>
        <div><span>${tr('已分配')}</span><strong id="budget-spent">0<small>${tr('点')}</small></strong></div>
        <div><span>${tr('剩余培养点')}</span><strong id="budget-remaining">0<small>${tr('点')}</small></strong></div>
      </div>
      <div class="budget-track"><i id="budget-progress"></i></div>
    </div>
    <div class="training-actions">
      <label class="field"><span>${tr('加点目标位置')}</span><select id="training-target" data-training-target>${catalog.positions.map(row => `<option value="${row.code}" ${row.code === target ? 'selected' : ''}>${row.code} · ${esc(positionLabel(row.code))}</option>`).join('')}</select></label>
      <button class="button secondary" data-action="auto-train">${icon('grow')}${tr('按位置分配')}</button>
      <button class="button primary" data-action="optimal-train">${icon('spark')}${tr('最优培养')}</button>
      <button class="button subtle" data-action="reset-training">${icon('refresh')}${tr('重置')}</button>
      <span class="inline-tip" id="training-target-note"></span>
    </div>
    <div class="training-grid">${groups}</div>
    ${player.card.type === 'Trending' ? `<p class="note">${tr('Trending 卡种按常规规则不能培养；如果希望自由加点，请在资料页换用其他卡种。')}</p>` : ''}
    ${panel(tr('球员增能'), `<div class="field-grid">
        ${field(tr('增能槽 1'), 'boosters.0', player.boosters[0] || 0, { choices: boosters })}
        ${field(tr('增能槽 2'), 'boosters.1', player.boosters[1] || 0, { choices: boosters })}
      </div><div style="margin-top:13px">${toggle('conditional_boosters', tr('把条件增能也计入预览'), player.conditional_boosters)}</div>
      <p class="note">${tr('增能会直接加到指定能力上，再计算总评。选择“不使用增能”即不生效；两个槽位请选择不同项目。')}</p>`, 'BOOSTERS')}
    ${panel(tr('全部 26 项明细'), `<div class="training-table-wrap"><table class="training-detail-table"><thead><tr><th>${tr('能力')}</th><th>${tr('基础')}</th><th>${tr('培养后')}</th><th>${tr('增能后')}</th><th>${tr('最终')}</th><th>${tr('变化')}</th></tr></thead><tbody id="training-comparison"></tbody></table></div>`, 'DETAIL')}`;
}

export function renderSkills(app) {
  const { player, catalog } = app;
  const attack = catalog.play_styles.attack.map(row => [String(row.id), tr(row.zh)]);
  const defense = catalog.play_styles.defense.map(row => [String(row.id), tr(row.zh)]);
  const ai = catalog.ai_styles.map(row => `<label class="ai-style-option"><input type="checkbox" data-ai-style="${row.key}" ${(player.ai_styles || []).includes(row.key) ? 'checked' : ''}><span>${esc(aiStyleLabel(row))}${isEn() ? '' : `<small>${esc(row.en)}</small>`}</span></label>`).join('');
  return `<div class="skill-toolbar">
      <div class="segmented"><button data-skill-mode="innate" class="${app.skillMode !== 'additional' ? 'active' : ''}">${tr('天生技能')}</button><button data-skill-mode="additional" class="${app.skillMode === 'additional' ? 'active' : ''}">${tr('额外习得')}</button></div>
      <div class="skill-counts"><span>${tr('天生')} <strong id="innate-count">${player.skills.innate.length}</strong></span><span>${tr('追加')} <strong id="additional-count">${player.skills.additional.length}/10</strong></span></div>
    </div>
    <div class="search-box">${icon('search')}<input class="input" id="skill-search" placeholder="${tr('搜索中文名、英文代号或编号')}" value="${esc(app.skillQuery || '')}"><label class="switch-label"><input type="checkbox" id="selected-only" ${app.selectedOnly ? 'checked' : ''}>${tr('只看已选')}</label></div>
    <div class="skill-legend"><span><i></i>${tr('天生')}</span><span><i class="blue"></i>${tr('额外习得')}</span><span>${tr('点击添加，再次点击取消')}</span></div>
    <div class="skill-grid" id="skill-grid"></div>
    ${panel(tr('比赛风格'), `<div class="field-grid">${field(tr('进攻比赛风格'), 'play_style.attack', player.play_style.attack, { choices: attack })}${field(tr('防守比赛风格'), 'play_style.defense', player.play_style.defense, { choices: defense })}</div>`, 'PLAY STYLE')}
    ${panel(tr('AI 比赛风格'), `<p class="panel-description">${tr('影响电脑控制这名球员时的跑位与处理球倾向，可多选或全部取消。')}</p><div class="ai-style-grid" style="margin-top:13px">${ai}</div>`, 'AI STYLE')}`;
}

export function skillGrid(app) {
  const { player, catalog } = app;
  const query = (app.skillQuery || '').trim().toLowerCase();
  const selected = new Set([...(player.skills.innate || []), ...(player.skills.additional || [])]);
  const rows = catalog.skills.filter(skill => {
    if (app.selectedOnly && !selected.has(skill.id)) return false;
    if (!query) return true;
    const haystack = `${skill.zh} ${skillEnglishForSearch(skill)} ${skill.code} ${skill.id}`.toLowerCase();
    return haystack.includes(query);
  });
  if (!rows.length) return `<div class="empty-state" style="padding:40px 16px">${tr('没有匹配的技能')}</div>`;
  return rows.map(skill => {
    const innate = (player.skills.innate || []).includes(skill.id);
    const additional = (player.skills.additional || []).includes(skill.id);
    const state = innate ? tr('天') : additional ? tr('追') : '+';
    const hint = isEn() ? skillLabel(skill) : (skill.desc || skill.code);
    return `<button class="skill-tile ${innate ? 'innate' : additional ? 'additional' : ''}" data-skill="${skill.id}" aria-pressed="${innate || additional}" title="${esc(hint)}"><span class="skill-name">${esc(skillLabel(skill))}<small>${String(skill.id).padStart(2, '0')} · ${esc(skill.code)}${skill.custom ? ' · ' + tr('原创效果') : ''}</small></span><span class="skill-state">${state}</span></button>`;
  }).join('');
}

function skillEnglishForSearch(skill) {
  const aliases = skill.aliases || [];
  return aliases.filter(item => item && /[A-Za-z]/.test(item)).join(' ');
}

export function renderCardPage(app) {
  const { player, catalog } = app;
  const card = player.card;
  const portrait = card.use_cutout && card.cutout_asset ? card.cutout_asset : card.portrait;
  const templateTiles = CARD_TEMPLATES.map(template => `<button class="template-tile ${card.template === template.id ? 'active' : ''}" data-template="${template.id}"><canvas data-template-canvas="${template.id}" width="180" height="258"></canvas><span>${esc(templateLabel(template))}</span></button>`).join('');
  const swatches = ['#7fe3bf', '#6fdcff', '#b9a4ff', '#e7c879', '#ffb27a', '#ff8fa3', '#f4f7fb', '#9fb2c4'].map(color => `<button class="swatch ${card.accent?.toLowerCase() === color ? 'active' : ''}" data-color-preset="${color}" style="background:${color}" title="${color}"></button>`).join('');
  return `${panel(tr('球员照片'), `<div class="card-person">
      <div class="photo-frame">${portrait ? `<img src="${assetUrl(portrait)}" alt="${tr('当前球员照片')}">` : `<span>${tr('还没有照片<br>透明 PNG 效果最好')}</span>`}</div>
      <div class="card-person-body">
        <p class="panel-description">${tr('导入人物照片后，卡面会自动裁切排版。纯色背景的照片可以直接用内置抠图；已经是透明 PNG 的会原样使用。')}</p>
        <div class="photo-actions">
          <button class="button primary" data-action="upload-portrait">${icon('upload')}${card.portrait ? tr('替换照片') : tr('导入照片')}</button>
          ${card.portrait ? `<button class="button secondary" data-action="cutout-photo">${icon('spark')}${tr('抠图')}</button><button class="button subtle" data-action="remove-portrait">${icon('trash')}${tr('移除')}</button>` : ''}
          ${card.cutout_asset ? `<label class="switch-label"><input type="checkbox" data-bind="card.use_cutout" ${card.use_cutout ? 'checked' : ''}>${tr('使用抠图结果')}</label>` : ''}
        </div>
        ${card.portrait ? rangeField('card.cutout_tolerance', tr('抠图容差'), card.cutout_tolerance ?? 34, 4, 120, 1, '', tr('背景越花越要调高；抠完再调一次即可')) : ''}
        <p class="note">${tr('透明 PNG 不需要抠图。如果人物穿着接近背景的颜色（例如白袜配白底），可能被一起扣掉，可降低容差或改用透明 PNG。')}</p>
      </div>
    </div>`, 'PORTRAIT')}
    ${panel(tr('卡面模板'), `<div class="gallery">${templateTiles}</div><p class="note">${esc(tf('模板只改变卡面风格；照片、姓名、能力与技能都会保留。当前：{name}。', { name: templateLabel(templateById(card.template)) }))}</p>`, 'TEMPLATE')}
    ${panel(tr('颜色与构图'), `<div class="field-grid">
        <div class="field"><span>${tr('主色')}</span><div class="color-field"><input type="color" data-bind="card.accent" value="${esc(card.accent)}"><code>${esc(card.accent)}</code></div></div>
        <div class="field"><span>${tr('快速配色')}</span><div class="swatches">${swatches}</div></div>
      </div>
      <div class="divider"></div>
      <div class="field-grid three">
        ${rangeField('card.photo.zoom', tr('照片缩放'), card.photo.zoom, .5, 3, .01, '×')}
        ${rangeField('card.photo.x', tr('水平位置'), card.photo.x, -150, 150, 1, '')}
        ${rangeField('card.photo.y', tr('垂直位置'), card.photo.y, -150, 150, 1, '')}
      </div>
      <div class="field-grid three" style="margin-top:12px">
        ${rangeField('card.photo.rotate', tr('旋转'), card.photo.rotate, -20, 20, 1, '°')}
        ${field(tr('卡面标题'), 'card.title', card.title, { placeholder: 'PERSONAL EDITION' })}
        ${field(tr('卡面编号'), 'card.serial', card.serial, { type: 'number', min: 1, max: 9999 })}
      </div>
      <p class="note">${tr('提示：直接拖动右侧卡面也可以移动照片。')}</p>`, 'LAYOUT')}
    ${panel(tr('卡面背景'), `<div class="field-grid">
        ${field(tr('背景方式'), 'card.background_style', card.background_style, { choices: [['theme', tr('使用模板背景')], ['image', tr('使用自定义背景图')]] })}
        <div class="field"><span>${tr('自定义卡面背景')}</span><div class="photo-actions" style="margin:0">${card.background_image ? `<img src="${assetUrl(card.background_image)}" alt="${tr('卡面背景')}" style="width:96px;height:56px;object-fit:cover;border-radius:5px;border:1px solid #2a3b4b">` : `<span class="inline-tip">${tr('未选择')}</span>`}<button class="button secondary small" data-action="upload-background">${icon('image')}${tr('上传卡面背景')}</button>${card.background_image ? `<button class="button subtle small" data-action="remove-background">${tr('移除')}</button>` : ''}</div></div>
      </div>
      ${card.background_image ? `<div class="divider"></div>
      <div class="field-grid three">
        ${rangeField('card.background_dim', tr('背景明暗'), card.background_dim ?? .4, 0, .85, .01, '')}
        ${rangeField('card.background_zoom', tr('背景缩放'), card.background_zoom ?? 1, 1, 3, .01, '×')}
        ${rangeField('card.background_x', tr('背景水平'), card.background_x ?? 0, -220, 220, 1, '')}
      </div>
      <div class="field-grid three" style="margin-top:12px">
        ${rangeField('card.background_y', tr('背景垂直'), card.background_y ?? 0, -220, 220, 1, '')}
        <div class="field"><span>${tr('卡面边框')}</span>${toggle('card.background_frame', tr('保留默认卡框'), card.background_frame !== false)}</div>
      </div>` : ''}
      <p class="note">${tr('自定义卡面背景会覆盖模板背景；关掉卡框后，整张图就是卡面。')} ${tr('选择“自定义卡面”模板可直接把背景图当作卡面底板。')}</p>`, 'BACKGROUND')}
    ${panel(tr('卡面显示项'), `<div class="check-grid">
        ${toggle('card.show.stats', tr('六项能力'), card.show.stats)}
        ${toggle('card.show.skills', tr('技能标签'), card.show.skills)}
        ${toggle('card.show.serial', tr('卡面编号'), card.show.serial)}
        ${toggle('card.show.badges', tr('国家 / 球队'), card.show.badges)}
        ${toggle('card.show.stars', tr('星级'), card.show.stars)}
        ${toggle('card.show.number', tr('背号水印'), card.show.number)}
      </div>`, 'VISIBLE')}
    ${panel(tr('导出卡面'), `<p class="panel-description">${tr('导出为 PNG：卡面 1200 × 1720，小头像 512 × 512。文件名会自动带上球员名字。')}</p><div class="photo-actions"><button class="button primary" data-action="export-card">${icon('image')}${tr('导出卡面 PNG')}</button><button class="button secondary" data-action="export-avatar">${icon('user')}${tr('导出小头像')}</button><button class="button subtle" data-action="open-export-page">${icon('archive')}${tr('更多导出选项')}</button></div>`, 'EXPORT')}`;
}

export function renderModelPage(app) {
  const { player } = app;
  const model = player.model;
  const capture = model.capture || {};
  const stats = model.stats;
  const statRows = stats ? `
      <div class="model-stat"><span>${tr('网格')}</span><strong>${stats.meshes}</strong></div>
      <div class="model-stat"><span>${tr('三角面')}</span><strong>${Number(stats.triangles).toLocaleString(numLocale())}</strong></div>
      <div class="model-stat"><span>${tr('顶点')}</span><strong>${Number(stats.vertices).toLocaleString(numLocale())}</strong></div>
      <div class="model-stat"><span>${tr('骨骼')}</span><strong>${stats.bones || 0}</strong></div>
      <div class="model-stat"><span>${tr('材质 / 贴图')}</span><strong>${stats.materials} / ${stats.textures}</strong></div>
      <div class="model-stat"><span>${tr('动画')}</span><strong>${stats.animations?.length || 0}</strong></div>` : '';
  return `<div class="model-toolbar">
      <button class="button primary" data-action="upload-model">${icon('cube')}${model.asset ? tr('替换模型') : tr('导入模型')}</button>
      ${model.asset ? `<button class="button subtle" data-action="remove-model">${icon('trash')}${tr('移除')}</button><button class="button secondary" data-action="export-glb">${icon('download')}${tr('导出 GLB')}</button><button class="button secondary" data-action="export-obj">${icon('download')}${tr('导出 OBJ')}</button>` : ''}
    </div>
    <div class="model-stage" id="model-stage"></div>
    <div class="row-between" style="margin:10px 0 12px">
      <span class="inline-tip">${model.asset ? esc(model.name || model.asset) : tr('支持 GLB / GLTF / OBJ，模型只用于预览与投稿，不写入游戏')}</span>
      <span class="inline-tip">${tr('左键旋转 · 滚轮缩放 · 右键平移')}</span>
    </div>
    ${model.asset ? `<div class="model-toolbar">
        <button class="button subtle" data-view="fit">${tr('适应画面')}</button>
        <button class="button subtle" data-view="front">${tr('正面')}</button>
        <button class="button subtle" data-view="side">${tr('侧面')}</button>
        <button class="button subtle" data-view="three-quarter">45°</button>
        <button class="button subtle" data-view="head">${tr('头部')}</button>
        <button class="button secondary" data-action="capture-portrait">${icon('camera')}${tr('取景为卡面照片')}</button>
        <button class="button subtle" data-action="capture-avatar">${icon('user')}${tr('取景为小头像')}</button>
      </div>` : ''}
    <div class="model-options">
      ${[['wireframe', tr('线框')], ['skeleton', tr('显示骨架')], ['rotate', tr('自动旋转')]].map(([key, label]) => `<label class="switch-label"><input type="checkbox" data-model-option="${key}">${label}</label>`).join('')}
    </div>
    ${panel(tr('模型调整'), `<div class="field-grid three">
        ${rangeField('model.transform.scale', tr('显示缩放'), model.transform.scale, .2, 3, .01, '×')}
        ${rangeField('model.transform.rotate', tr('水平旋转'), model.transform.rotate, -180, 180, 1, '°')}
        ${rangeField('model.transform.lift', tr('上下位置'), model.transform.lift, -1, 1, .01, '')}
      </div><p class="note">${tr('调整只影响预览与取景，不会改变导出的原始模型。')}</p>`, 'TRANSFORM')}
    ${stats ? panel(tr('模型信息'), `<div class="model-stats" id="model-stats">${statRows}</div>
        <p class="note">${tr('导入时已按最长边 1.75 个单位归一化显示。导出的 GLB / OBJ 使用模型原始坐标与材质。')}</p>`, 'MESH') : ''}
    ${Object.keys(capture).length ? panel(tr('已保存的取景'), `<div class="capture-grid">${capture.portrait ? `<div class="capture-card"><img src="${assetUrl(capture.portrait)}" alt="${tr('卡面照片')}"><span>${tr('卡面照片')}</span></div>` : ''}${capture.avatar ? `<div class="capture-card"><img src="${assetUrl(capture.avatar)}" alt="${tr('小头像')}"><span>${tr('小头像')}</span></div>` : ''}</div><p class="note">${tr('取景已自动用于卡面；也可以重新取景覆盖。')}</p>`, 'CAPTURE') : ''}
    ${panel(tr('使用说明'), `<p class="panel-description">${tr('模型可以是自制的头模、全身模型或任何 GLB / OBJ。这个制作器不会把模型打包进游戏，只负责预览、取景和导出文件。如果模型带骨骼或动画，也会一并保留在导出的 GLB 中。')}</p>`, 'NOTE')}`;
}

export function renderExportPage(app) {
  const { player } = app;
  const options = app.exportOptions || {};
  const items = [
    ['card', tr('卡面 PNG'), tr('1200 × 1720，带全部卡面信息')],
    ['avatar', tr('小头像 PNG'), tr('512 × 512，适合列表与头像')],
    ['json', tr('球员资料 JSON'), tr('完整数据与计算结果，可程序读取')],
    ['markdown', tr('球员资料 Markdown'), tr('人类可读的一页资料')],
    ['csv', tr('能力 CSV'), tr('26 项能力一行，适合表格')],
    ['model', tr('模型文件'), player.model.asset ? tr('原始 GLB / OBJ 文件') : tr('尚未导入模型')],
    ['modelCapture', tr('模型预览 PNG'), player.model.capture?.portrait ? tr('已保存的卡面取景') : tr('尚未取景')],
  ];
  const modelMissing = !player.model.asset;
  return `${panel(tr('导出内容'), `<div class="export-grid">${items.map(([key, title, note]) => {
      const disabled = (key === 'model' && modelMissing) || (key === 'modelCapture' && !player.model.capture?.portrait);
      return `<label class="export-item" ${disabled ? 'style="opacity:.5"' : ''}><input type="checkbox" data-export="${key}" ${options[key] && !disabled ? 'checked' : ''} ${disabled ? 'disabled' : ''}><div><strong>${esc(title)}</strong><small>${esc(note)}</small></div></label>`;
    }).join('')}</div>
    <div class="export-actions">
      <button class="button primary" data-action="export-files">${icon('download')}${tr('导出到本机')}</button>
      <button class="button secondary" data-action="export-zip">${icon('archive')}${tr('导出并压缩 ZIP')}</button>
      <button class="button subtle" data-action="open-exports">${icon('folder')}${tr('打开导出目录')}</button>
    </div>
    <div id="export-result"></div>
    <p class="note">${tr('导出目录：')}<code>${esc(app.appInfo?.data_dir || '')}\\exports</code>${tr('。文件保存在本机，不会上传。')}</p>`, 'EXPORT KIT')}
    ${panel(tr('当前球员工程'), `<div class="two-col">
      <div><p class="panel-description">${tr('导出 <strong>.psplayer</strong> 会把资料、照片、模型和所有设置打包成一个文件，便于备份或交给另一台电脑继续编辑。')}</p><div class="export-actions"><button class="button secondary" data-action="export-project">${icon('archive')}${tr('导出工程 .psplayer')}</button><button class="button subtle" data-action="import-project">${icon('upload')}${tr('导入工程')}</button></div></div>
      <div><p class="panel-description">${tr('导出卡面和数据时会写入程序旁边的 exports 目录；工程文件同样保存在这里。整个 data 目录建议定期备份。')}</p><div class="export-actions"><button class="button subtle" data-action="open-data">${icon('folder')}${tr('打开 data 目录')}</button><button class="button subtle" data-action="reveal-latest">${icon('folder')}${tr('打开最近一次导出')}</button></div></div>
    </div>`, 'PROJECT')}
    ${panel(tr('批量导出'), `<p class="panel-description">${tr('把“我的球员”里的全部球员依次导出为卡面、小头像和资料，最后压缩成一个 ZIP。模型和工程不包含在批量包里。')}</p><div class="export-actions"><button class="button secondary" data-action="export-all">${icon('archive')}${tr('导出全部球员')}</button></div>`, 'BATCH')}
    ${panel(tr('最近导出'), `<div class="history" id="export-history"><span class="inline-tip">${tr('正在读取…')}</span></div>`, 'HISTORY')}
    ${panel(tr('文件说明'), `<div class="doc"><p><strong>${tr('卡面 PNG')}</strong>${isEn() ? ': ' : '：'}${tr('1200 × 1720，可直接当作品展示或打印。照片、模板、姓名、总评与技能都按当前设置渲染。')}</p><p><strong>${tr('资料 JSON')}</strong>${isEn() ? ': ' : '：'}${tr('包含基础能力、培养、增能、最终能力、每位置总评、卡面配置和模型信息，字段名固定，便于自己写脚本继续处理。')}</p><p><strong>${tr('能力 CSV')}</strong>${isEn() ? ': ' : '：'}${tr('UTF-8 BOM 编码，Excel 直接打开不乱码。')}</p><p><strong>${tr('工程 .psplayer')}</strong>${isEn() ? ': ' : '：'}${tr('ZIP 格式，内含 player.json 与 assets。制作器可以直接导入。')}</p></div>`, 'FORMAT')}`;
}

export function renderHelp(app) {
  return isEn() ? renderHelpEn(app) : renderHelpZh(app);
}

function renderHelpZh(app) {
  return `${panel('这个工具做什么', `<div class="doc">
      <p>制作器只做三件事：<strong>把球员资料填完整</strong>、<strong>把卡面设计出来</strong>、<strong>把模型展示好</strong>。它不读取 APK，也不需要游戏安装包；所有数据来自内置的离线资料库，导出的是 PNG、JSON、CSV 和 GLB / OBJ。</p>
      <div class="steps">
        <div class="step"><b>1</b><strong>资料</strong><small>姓名、位置、身材、卡种与特征。</small></div>
        <div class="step"><b>2</b><strong>能力</strong><small>26 项基础值，或套用内置参考模板。</small></div>
        <div class="step"><b>3</b><strong>培养</strong><small>等级预算、加点、增能，实时看总评。</small></div>
        <div class="step"><b>4</b><strong>卡面</strong><small>照片、模板、配色、构图，导出 PNG。</small></div>
      </div>`, 'OVERVIEW')}
    ${panel('常用操作', `<div class="doc">
      <h3>新建与保存</h3>
      <p>点右上角“新建球员”建立独立工程。所有修改会自动保存到本机；<span class="kbd">Ctrl</span> + <span class="kbd">S</span> 可以立即保存。撤销是 <span class="kbd">Ctrl</span> + <span class="kbd">Z</span>，重做是 <span class="kbd">Ctrl</span> + <span class="kbd">Shift</span> + <span class="kbd">Z</span>。</p>
      <h3>照片与抠图</h3>
      <p>在“卡面设计”导入 JPG / PNG / WebP。透明 PNG 最省事；纯色背景照片点“抠图”，背景色越单一效果越好，容差可以反复调整。抠图结果会单独保存，不会覆盖原图。</p>
      <h3>模型</h3>
      <p>模型页支持 GLB、GLTF、OBJ。导入后可旋转、缩放、显示骨架或线框。“取景为卡面照片”会把当前视角渲染成透明 PNG 并直接用于卡面。导出的 GLB 保留原始坐标与材质。</p>
      <h3>导出</h3>
      <p>右侧预览下方的“导出卡面 PNG”直接下载；导出页可以把卡面、头像、资料、CSV、模型打包到一个文件夹，或压缩成 ZIP。</p>
    </div>`, 'WORKFLOW')}
    ${panel('数据和隐私', `<div class="doc">
      <p>所有内容保存在制作器目录的 <code>data</code> 文件夹：<code>players</code> 是球员工程，<code>assets</code> 是照片与模型，<code>exports</code> 是导出结果，<code>backups</code> 是保存时的自动备份。</p>
      <p>制作器只监听 <code>127.0.0.1</code>，不发送任何网络请求。关闭窗口后本地服务会自动退出。升级或移动软件时，保留整个 <code>data</code> 目录即可。</p>
      <p>建议定期导出 <strong>.psplayer</strong> 工程做异地备份，尤其是电脑要重装或换机时。</p>
    </div>`, 'PRIVACY')}
    ${panel('版本与说明', `<div class="doc">
      <p><strong>${esc(app.appInfo?.name || '球员工坊 · 制作器')}</strong> · 版本 ${esc(app.appInfo?.version || '1.0.0')}</p>
      <p>能力、技能、增能、位置回归公式与国籍 / 球队名称来自本地球员工坊 XI 1.4.1（r1428）的静态资料，不读取任何游戏安装包。卡面模板、排版和示例配色由制作器自行绘制。</p>
      <p>本软件免费用于个人娱乐、学习与交流，不得销售或用于盈利。游戏与球员相关名称、数值的权利归原权利人所有；本工具为非官方创作工具，与游戏官方无关联。</p>
      <p>数据目录：<code>${esc(app.appInfo?.data_dir || '')}</code></p>
    </div>`, 'ABOUT')}`;
}

function renderHelpEn(app) {
  return `${panel('What this tool does', `<div class="doc">
      <p>The studio does three things: <strong>build a complete player profile</strong>, <strong>design the card</strong>, and <strong>present the model</strong>. It never reads an APK or asks for the game install. All reference data ships offline; exports are PNG, JSON, CSV and GLB / OBJ.</p>
      <div class="steps">
        <div class="step"><b>1</b><strong>Profile</strong><small>Name, position, build, card type and traits.</small></div>
        <div class="step"><b>2</b><strong>Abilities</strong><small>All 26 values, or apply a built-in reference.</small></div>
        <div class="step"><b>3</b><strong>Development</strong><small>Level budget, points, boosters and live rating.</small></div>
        <div class="step"><b>4</b><strong>Card</strong><small>Photo, template, colours, framing and PNG.</small></div>
      </div>`, 'OVERVIEW')}
    ${panel('Everyday workflow', `<div class="doc">
      <h3>Create and save</h3>
      <p>Use <strong>New Player</strong> in the top bar to create a separate project. Every change saves locally; <span class="kbd">Ctrl</span> + <span class="kbd">S</span> saves now. Undo is <span class="kbd">Ctrl</span> + <span class="kbd">Z</span> and redo is <span class="kbd">Ctrl</span> + <span class="kbd">Shift</span> + <span class="kbd">Z</span>.</p>
      <h3>Photos and cutout</h3>
      <p>Import JPG / PNG / WebP in Card Design. Transparent PNGs are easiest. For solid backgrounds, use <strong>Cut out</strong>; a cleaner background works better, and the tolerance can be adjusted and repeated. The cutout is saved separately and never overwrites the original.</p>
      <h3>Models</h3>
      <p>Model Studio accepts GLB, GLTF and OBJ. Rotate, scale, show the skeleton or wireframe, then use <strong>Capture as card photo</strong> to render the current view as a transparent PNG. Exported GLB keeps original transforms and materials.</p>
      <h3>Export</h3>
      <p>The <strong>Export card PNG</strong> button under the preview downloads directly. The Export page can pack card, avatar, data, CSV and model into a folder or a ZIP.</p>
    </div>`, 'WORKFLOW')}
    ${panel('Data and privacy', `<div class="doc">
      <p>Everything lives in the <code>data</code> folder beside the app: <code>players</code> holds projects, <code>assets</code> holds photos and models, <code>exports</code> holds output, and <code>backups</code> holds automatic save backups.</p>
      <p>The studio only listens on <code>127.0.0.1</code> and sends no network requests. The local service stops after the window is closed. Keep the whole <code>data</code> folder when moving or upgrading.</p>
      <p>Export <strong>.psplayer</strong> projects regularly for off-machine backups, especially before reinstalling Windows or changing PCs.</p>
    </div>`, 'PRIVACY')}
    ${panel('Version and notices', `<div class="doc">
      <p><strong>${esc(tr('球员工坊 · 制作器'))}</strong> · version ${esc(app.appInfo?.version || '1.0.0')}</p>
      <p>Abilities, skills, boosters, position regression weights and nation / club names come from the local Player Studio XI 1.4.1 (r1428) static reference data; no game package is read. Card templates, layout and sample colours are drawn by this studio.</p>
      <p>Free for personal entertainment, learning and exchange. Do not sell or use commercially. Game and player names and values belong to their respective rights holders. This is an unofficial creative tool, not affiliated with the game publisher.</p>
      <p>Data folder: <code>${esc(app.appInfo?.data_dir || '')}</code></p>
    </div>`, 'ABOUT')}`;
}
