/* 制作器主控制器：状态、保存、页面渲染、导出与事件绑定。 */

import {
  $, $$, esc, clone, simulate, normalizePlayer, newPlayer, cardType, positionName,
  abilityRows, byIndex, ratingColor, trainingCost, autoAllocate, optimalTraining, fileStem, downloadBlob, clamp,
} from './core.js';
import * as api from './api.js';
import { drawCard, drawAvatar, cardCanvas, avatarCanvas, templateById, CARD_TEMPLATES, loadImage, resolvePortrait } from './card.js';
import { cutout } from './portrait.js';
import { ModelViewer } from './model.js';
import {
  PAGES, pageMeta, renderPlayers, renderProfile, renderAbilities, renderTraining, renderSkills,
  renderCardPage, renderModelPage, renderExportPage, renderHelp, skillGrid,
} from './pages.js';
import {
  initLanguage, getLang, setLang, isEn, tr, tf, fileSuffix, positionLabel, cardTypeLabel, cardTypeBadge,
  skillLabel, abilityLabel, sixLabel, groupLabel, skillEnglish, footLabel, nationDisplay, teamDisplay, localizeError,
} from './i18n.js';
import { icon, hydrateIcons, setPath, getPath, formatBytes, formatTime } from './ui.js';

const app = {
  catalog: null, player: null, sim: null, projects: [], appInfo: {}, settings: {},
  page: 'players', preview: 'card', abilityFilter: 'all', skillMode: 'innate', skillQuery: '', selectedOnly: false,
  trainingTarget: 'CF',
  exportOptions: { card: true, avatar: true, json: true, markdown: true, csv: true, model: true, modelCapture: true },
  viewer: null, past: [], future: [], version: 0, savedVersion: 0, saveTimer: null, savePromise: null,
  cardToken: 0, renderToken: 0, lastKey: '', lastTime: 0, lastExportFolder: '', lastExportPath: '', lastExportUrl: '',
  mountedModelAsset: null, drag: null,
};

const MAIN_PAGES = ['players', 'profile', 'abilities', 'training', 'skills', 'card', 'model'];
const VIEWS = {
  players: renderPlayers, profile: renderProfile, abilities: renderAbilities, training: renderTraining,
  skills: renderSkills, card: renderCardPage, model: renderModelPage, export: renderExportPage, help: renderHelp,
};

/* ---------------- 启动 ---------------- */
async function boot() {
  initLanguage();
  hydrateIcons(document);
  const data = await api.api('bootstrap');
  app.catalog = data.catalog;
  app.projects = data.projects || [];
  app.appInfo = data.app || {};
  app.settings = data.settings || {};
  try {
    const savedOptions = JSON.parse(localStorage.getItem('maker.exportOptions') || 'null');
    if (savedOptions) app.exportOptions = { ...app.exportOptions, ...savedOptions };
  } catch { /* ignore */ }

  const saved = localStorage.getItem('maker.last');
  const row = app.projects.find(item => item.id === saved) || app.projects[0];
  if (row?.project) app.player = normalizePlayer(row.project, app.catalog);
  else {
    app.player = newPlayer(app.catalog, { name: tr('新球员') });
    await flushSave(true);
  }
  app.trainingTarget = app.player.identity.position;
  app.sim = simulate(app.player, app.catalog);
  const params = new URLSearchParams(location.search);
  if (params.get('nointro') === '1') localStorage.setItem('maker.announcement.v1', '1');
  if (PAGES[params.get('page')]) app.page = params.get('page');

  const canvas = $('#player-card');
  canvas.width = 1200;
  canvas.height = 1720;

  app.viewer = new ModelViewer(() => {});
  bindGlobal();
  buildDialogs();
  applyShellLanguage();
  renderNav();
  render();
  updateWelcome();
  setInterval(() => api.api('ping').catch(() => {}), 15000);
  window.__makerBooted = true;
  window.__maker = app;
  window.__makerActions = ACTIONS;
}

/* ---------------- 导航与页面渲染 ---------------- */
function renderNav() {
  const nav = $('#navigation');
  nav.innerHTML = MAIN_PAGES.map(id => {
    const page = pageMeta(id);
    const count = id === 'players' && app.projects.length ? `<span class="nav-count">${app.projects.length}</span>` : '';
    return `<button class="nav-item ${id === app.page ? 'active' : ''}" data-page="${id}" title="${esc(page.title)}">${icon(page.icon)}<span>${esc(page.title)}</span>${count}</button>`;
  }).join('');
  $$('.sidebar [data-page]').forEach(node => node.classList.toggle('active', node.dataset.page === app.page));
  const compact = $('#compact-page');
  if (compact) {
    compact.innerHTML = [...MAIN_PAGES, 'export', 'help'].map(id => `<option value="${id}" ${id === app.page ? 'selected' : ''}>${esc(pageMeta(id).title)}</option>`).join('');
  }
}

function render() {
  if (!app.player) return;
  const page = pageMeta(app.page);
  document.body.dataset.page = app.page;
  document.title = `${tr('球员工坊 · 制作器')} · ${page.title}`;
  $('#breadcrumb').textContent = page.short;
  $('#page-title').textContent = page.title;
  $('#page-description').textContent = page.description;
  $('#page-eyebrow').textContent = page.eyebrow;
  $('#page-badge').textContent = app.page === 'players' ? tf('{n} 名球员', { n: app.projects.length }) : `OVR ${app.sim.overall} · ${app.player.identity.position}`;
  $('#project-id').textContent = (app.player.id || '').slice(0, 8) + ' · ' + (app.player.id || '').slice(-6);
  $$('.sidebar [data-page]').forEach(node => node.classList.toggle('active', node.dataset.page === app.page));
  renderNav();
  applyShellLanguage();
  const content = $('#editor-content');
  content.innerHTML = VIEWS[app.page](app);
  hydrateIcons(content);
  mountPage();
  updateLive();
  updateUndo();
  window.scrollTo({ top: 0, behavior: 'instant' });
}

async function mountPage() {
  const token = ++app.renderToken;
  if (app.page === 'players') await mountPlayers(token);
  else if (app.page === 'skills') renderSkillGrid();
  else if (app.page === 'card') await mountTemplates(token);
  else if (app.page === 'model') await mountModel();
  else if (app.page === 'export') loadHistory();
}

function navigate(page) {
  if (!PAGES[page]) return;
  app.page = page;
  render();
}

function applyShellLanguage() {
  document.querySelectorAll('[data-i18n]').forEach(node => { node.textContent = tr(node.dataset.i18n); });
  document.querySelectorAll('[data-i18n-html]').forEach(node => { node.innerHTML = tr(node.dataset.i18nHtml); });
  document.querySelectorAll('[data-i18n-title]').forEach(node => { node.title = tr(node.dataset.i18nTitle); });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(node => { node.placeholder = tr(node.dataset.i18nPlaceholder); });
  const toggle = $('#lang-toggle');
  if (toggle) {
    toggle.textContent = isEn() ? '中文' : 'EN';
    toggle.title = tr('切换语言');
    toggle.setAttribute('aria-label', tr('切换语言'));
  }
  const newPlayer = $('#new-player');
  if (newPlayer) newPlayer.innerHTML = `${icon('plus')}${esc(tr('新建球员'))}`;
  const quickExport = $('#quick-export');
  if (quickExport) quickExport.innerHTML = `${icon('export')}${esc(tr('导出'))}`;
  const exportCard = $('#export-card');
  if (exportCard) exportCard.innerHTML = `${icon('image')}${esc(tr('导出卡面 PNG'))}`;
  const openModel = $('#open-model-page');
  if (openModel) openModel.textContent = tr('打开模型工作区');
  const hint = $('.model-hint');
  if (hint) hint.textContent = tr('导入 GLB / OBJ 后，可在模型页取景并直接变成卡面照片。');
  const previewHeader = $('.preview-header > span:first-child');
  if (previewHeader) previewHeader.innerHTML = `<i class="live-dot"></i>${esc(tr('实时预览'))}`;
  $$('[data-preview]').forEach(node => {
    const labels = { card: '球员卡面', data: '能力概览', model: '模型取景' };
    node.textContent = tr(labels[node.dataset.preview] || '');
  });
  const footer = $('.preview-footer p');
  if (footer) footer.textContent = tr('总评使用内置位置回归公式，包含培养与增能，不包含教练和状态箭头。卡面与模型都是本机设计稿，不会写入游戏。');
  const identityLabel = $('.identity-mark div > span');
  if (identityLabel) identityLabel.textContent = tr('球员编号');
  const status = $('#save-status');
  if (status) {
    const kind = status.classList.contains('saving') ? 'saving' : status.classList.contains('error') ? 'error' : '';
    setSaveStatus(kind, kind === 'saving' ? tr('正在保存…') : kind === 'error' ? tr('保存失败，按 Ctrl+S 重试') : tr('已保存到本机'));
  }
}

function changeLanguage(value) {
  if (value === getLang()) return;
  setLang(value);
  buildDialogs();
  applyShellLanguage();
  renderNav();
  render();
  app.viewer?.refreshLanguage?.();
}

async function mountPlayers(token) {
  for (const canvas of $$('[data-player-thumb]')) {
    if (token !== app.renderToken) return;
    const row = app.projects.find(item => item.id === canvas.dataset.playerThumb);
    if (!row?.project) continue;
    try {
      const player = normalizePlayer(row.project, app.catalog);
      const sim = simulate(player, app.catalog);
      await drawCard(canvas, player, sim, app.catalog);
    } catch { /* 单张缩略图失败不影响列表 */ }
  }
}

async function mountTemplates(token) {
  const card = app.player.card;
  for (const canvas of $$('[data-template-canvas]')) {
    if (token !== app.renderToken) return;
    const template = canvas.dataset.templateCanvas;
    const info = templateById(template);
    const preview = {
      ...clone(app.player),
      card: {
        ...clone(card),
        template,
        accent: info.accent,
        background_frame: template === 'custom' ? false : card.background_frame,
        background_style: template === 'custom' ? 'image' : card.background_style,
      },
    };
    try { await drawCard(canvas, preview, app.sim, app.catalog); } catch { /* ignore */ }
  }
}

async function mountModel() {
  const stage = $('#model-stage');
  if (!stage) return;
  app.viewer.attach(stage);
  const model = app.player.model;
  if (!model.asset) {
    if (app.mountedModelAsset) { app.viewer.clear(); app.mountedModelAsset = null; }
    else if (!app.viewer.subject) app.viewer.readout.textContent = tr('还没有导入模型');
    return;
  }
  if (app.mountedModelAsset !== model.asset) {
    if (app.modelLoading === model.asset) return;
    app.modelLoading = model.asset;
    const playerId = app.player.id;
    try {
      const meta = await app.viewer.load(model.asset, model.name);
      if (app.player.id !== playerId) return;
      app.mountedModelAsset = model.asset;
      app.player.model.stats = meta;
      app.player.model.format = (model.name || model.asset).split('.').pop().toUpperCase();
      scheduleSave(true);
      if (app.page === 'model' && !$('#model-stats')) render();
    } catch (error) {
      toast(error.message, true);
    } finally {
      app.modelLoading = null;
    }
  } else {
    app.viewer.applyTransform(model.transform);
  }
}

/* ---------------- 实时预览 ---------------- */
function updateLive() {
  if (!app.player || !app.catalog) return;
  app.sim = simulate(app.player, app.catalog);
  $('#page-badge').textContent = app.page === 'players' ? tf('{n} 名球员', { n: app.projects.length }) : `OVR ${app.sim.overall} · ${app.player.identity.position}`;
  $('#preview-state').textContent = app.page === 'export' ? tr('导出预览') : tr('设计工程');
  const card = app.player.card;
  const typeLabel = cardTypeBadge(card.type);
  $('#preview-series').textContent = `${typeLabel} · ${(card.title || 'PERSONAL EDITION').toUpperCase()}`;
  $('#preview-level').textContent = `Lv.${app.player.level.initial} / ${app.player.level.max}`;
  const ovr = app.sim.overall;
  $('#overall-summary').innerHTML = `<div class="ovr-main"><span>${esc(tf('计算总评 · {pos}', { pos: app.player.identity.position }))}</span><strong style="color:${ratingColor(ovr)}">${ovr}</strong></div>
    <p>${esc(tf('基础 {base} → 培养 {trained}', { base: app.sim.baseOverall, trained: app.sim.trainedOverall }))}<br>${esc(tf('增能 {boosted}', { boosted: app.sim.boostedOverall }))}<small>${esc(tr('内置位置回归公式 · 不含教练与状态箭头'))}</small></p>`;
  $('#preview-six').innerHTML = app.catalog.six_stats.map(group => {
    const value = app.sim.six[group.key];
    const base = app.sim.baseSix[group.key];
    return `<div class="mini-stat"><span>${esc(sixLabel(group))}</span><strong style="color:${ratingColor(value)}">${value}</strong>${value !== base ? `<small>${value > base ? '+' : ''}${value - base}</small>` : ''}</div>`;
  }).join('');
  drawPreview();
  updateRadar();
  updateStatOverview();
  updateModelPreview();
  updateTrainingDom();
  if (app.page === 'model') app.viewer?.applyTransform(app.player.model.transform);
}

async function drawPreview() {
  const canvas = $('#player-card');
  if (!canvas) return;
  const token = ++app.cardToken;
  try {
    const result = await drawCard(canvas, app.player, app.sim, app.catalog);
    if (token !== app.cardToken) return;
    $('#card-empty-hint')?.toggleAttribute('hidden', result.hasPortrait);
  } catch (error) {
    console.error(error);
  }
}

function radarSvg(values, base, labels) {
  const point = (index, radius) => [155 + Math.sin((index * Math.PI) / 3) * radius, 143 - Math.cos((index * Math.PI) / 3) * radius];
  const polygon = list => list.map((value, index) => point(index, Math.max(6, (value / 110) * 102)).join(',')).join(' ');
  const rings = [0.25, 0.5, 0.75, 1].map(factor => `<polygon points="${Array.from({ length: 6 }, (_, index) => point(index, 102 * factor).join(',')).join(' ')}" fill="none" stroke="#233443" stroke-width="1"/>`).join('');
  const spokes = Array.from({ length: 6 }, (_, index) => {
    const [x, y] = point(index, 102);
    return `<path d="M155 143 ${x} ${y}" stroke="#233443"/>`;
  }).join('');
  return `<svg viewBox="0 0 310 285" aria-label="${esc(tr('六维能力雷达图'))}">${rings}${spokes}<polygon points="${polygon(base)}" fill="#6c8aa518" stroke="#6c8aa5" stroke-dasharray="3 4"/><polygon points="${polygon(values)}" fill="#71d4a72b" stroke="#85d8b4" stroke-width="2"/>${labels.map((name, index) => {
    const [x, y] = point(index, 127);
    return `<text x="${x}" y="${y}" fill="#8ba4b7" font-size="10" text-anchor="middle">${name}</text><text x="${x}" y="${y + 15}" fill="#b7dbc9" font-size="11" text-anchor="middle">${values[index]}</text>`;
  }).join('')}</svg><div class="radar-caption">${esc(tr('实线：培养与增能后 · 虚线：1 级基础'))}</div>`;
}

function updateRadar() {
  const chart = $('#radar-chart');
  const overview = $('#stat-overview');
  if (!chart || !overview) return;
  const labels = app.catalog.six_stats.map(group => sixLabel(group));
  const values = app.catalog.six_stats.map(group => app.sim.six[group.key]);
  const base = app.catalog.six_stats.map(group => app.sim.baseSix[group.key]);
  chart.innerHTML = radarSvg(values, base, labels);
  const positionRatings = app.catalog.positions.map(row => `<span class="${row.code === app.player.identity.position ? 'active' : ''}">${row.code} <strong>${app.sim.byPosition[row.code]}</strong></span>`).join('');
  overview.innerHTML = [
    [tr('计算总评'), app.sim.overall, tr('基础') + ' ' + app.sim.baseOverall],
    [tr('模拟等级'), app.player.level.initial, tr('上限 ') + app.player.level.max],
    [tr('剩余培养点'), app.sim.remaining, tr('已用 ') + app.sim.spent],
    [tr('技能数量'), app.player.skills.innate.length + app.player.skills.additional.length, tf('天生 {n} · 追加 {m}', { n: app.player.skills.innate.length, m: app.player.skills.additional.length })],
  ].map(([label, value, note]) => `<div class="overview-row"><span>${esc(label)}</span><strong>${value}<small>${esc(note)}</small></strong></div>`).join('')
    + `<div class="position-ratings"><p>${tr('各位置计算总评')}</p><div class="pos-grid">${positionRatings}</div></div>`;
}

function updateStatOverview() { /* 由 updateRadar 一并更新 */ }

function updateModelPreview() {
  const wrap = $('#model-capture-wrap');
  if (!wrap) return;
  const capture = app.player.model.capture || {};
  if (capture.portrait) wrap.innerHTML = `<img src="${api.assetUrl(capture.portrait)}" alt="${esc(tr('模型取景'))}">`;
  else if (app.player.model.asset) wrap.innerHTML = `<div class="empty-mini">${tr('模型已导入<br>到模型页取景即可变成卡面照片')}</div>`;
  else wrap.innerHTML = `<div class="empty-mini">${tr('还没有导入 3D 模型')}</div>`;
}

function updateTrainingDom() {
  const budget = $('#budget-card');
  if (!budget) return;
  const sim = app.sim;
  budget.classList.toggle('invalid', !sim.valid);
  $('#budget-total').innerHTML = `${sim.budget}<small>${tr('点')}</small>`;
  $('#budget-spent').innerHTML = `${sim.spent}<small>${tr('点')}</small>`;
  $('#budget-remaining').innerHTML = `${Math.max(0, sim.remaining)}<small>${tr('点')}</small>`;
  $('#budget-progress').style.width = (sim.budget ? Math.min(100, (sim.spent / sim.budget) * 100) : 0) + '%';
  $('#budget-progress').style.background = sim.valid ? 'var(--mint)' : 'var(--red)';
  for (const group of app.catalog.training_groups) {
    const count = Number(app.player.training[group.id] || 0);
    const used = trainingCost(count);
    const next = trainingCost(count + 1) - used;
    const costLabel = document.querySelector(`[data-group-cost="${group.id}"]`);
    if (costLabel) costLabel.textContent = tf('已用 {used} 点 · 下次 {next} 点', { used, next });
    const plus = document.querySelector(`[data-step="1"][data-group="${group.id}"]`);
    const minus = document.querySelector(`[data-step="-1"][data-group="${group.id}"]`);
    if (plus) plus.disabled = next > sim.remaining || count >= 40;
    if (minus) minus.disabled = !count;
  }
  const target = app.trainingTarget || app.player.identity.position;
  const note = $('#training-target-note');
  if (note) note.textContent = tf('目标 {pos} · 该位置总评 {ovr}', { pos: target, ovr: sim.byPosition[target] ?? '—' });
  const tbody = $('#training-comparison');
  if (tbody) {
    tbody.innerHTML = abilityRows(app.catalog).map(row => {
      const index = String(row.index);
      const delta = sim.final[index] - sim.base[index];
      return `<tr><th>${esc(abilityLabel(row))}</th><td>${sim.base[index]}</td><td>${sim.trained[index]}</td><td>${sim.boosted[index]}</td><td style="color:${ratingColor(sim.final[index])}">${sim.final[index]}</td><td>${delta > 0 ? '+' : ''}${delta}</td></tr>`;
    }).join('');
  }
}

function renderSkillGrid() {
  const grid = $('#skill-grid');
  if (!grid) return;
  grid.innerHTML = skillGrid(app);
  $('#innate-count').textContent = app.player.skills.innate.length;
  $('#additional-count').textContent = app.player.skills.additional.length + '/10';
}

function syncTrainingInputs() {
  $$('[data-bind^="training."]').forEach(input => {
    const group = input.dataset.bind.slice('training.'.length);
    if (document.activeElement !== input) input.value = app.player.training[group] ?? 0;
  });
}

/* ---------------- 保存与撤销 ---------------- */
function setSaveStatus(kind, text) {
  const node = $('#save-status');
  if (!node) return;
  node.className = 'save-status' + (kind ? ' ' + kind : '');
  node.innerHTML = `<i class="dot"></i>${esc(text)}`;
}

function scheduleSave(force = false) {
  setSaveStatus('saving', tr('正在保存…'));
  clearTimeout(app.saveTimer);
  app.saveTimer = setTimeout(() => flushSave(force).catch(() => {}), 650);
}

async function flushSave(force = false) {
  if (!app.player) return;
  clearTimeout(app.saveTimer);
  if (app.savePromise) {
    await app.savePromise;
    if (app.savedVersion < app.version) scheduleSave();
    return;
  }
  if (!force && app.savedVersion === app.version) return;
  const snapshot = clone(app.player);
  const version = app.version;
  setSaveStatus('saving', tr('正在保存…'));
  app.savePromise = api.api('project/save', { project: snapshot }).then(result => {
    const saved = result.project;
    app.savedVersion = version;
    if (app.player.id === saved.id) app.player.updated_at = saved.updated_at;
    updateProjectRow(saved);
    localStorage.setItem('maker.last', saved.id);
    if (app.savedVersion === app.version) setSaveStatus('', tr('已保存到本机'));
  }).catch(error => {
    setSaveStatus('error', tr('保存失败，按 Ctrl+S 重试'));
    toast(error.message, true);
    throw error;
  }).finally(() => { app.savePromise = null; });
  try { await app.savePromise; } catch { /* 已在状态栏提示 */ }
  if (app.savedVersion < app.version) scheduleSave();
}

function updateProjectRow(project) {
  const summary = {
    id: project.id, name: project.identity?.name || tr('未命名球员'),
    position: project.identity?.position || 'CF', card_type: project.card?.type || 'Epic',
    updated_at: project.updated_at, card: project.card, level: project.level?.initial || 1,
    portrait: project.card?.portrait, model: project.model?.asset, project: clone(project),
  };
  const index = app.projects.findIndex(row => row.id === project.id);
  if (index >= 0) app.projects[index] = summary;
  else app.projects.push(summary);
  app.projects.sort((a, b) => String(b.updated_at || '').localeCompare(String(a.updated_at || '')));
}

function commit(mutator, key = 'edit', options = {}) {
  const now = performance.now();
  if (key !== app.lastKey || now - app.lastTime > 700) {
    app.past.push(clone(app.player));
    if (app.past.length > 80) app.past.shift();
    app.lastKey = key;
    app.lastTime = now;
  }
  app.future = [];
  mutator(app.player);
  app.version += 1;
  scheduleSave();
  if (options.rerender) render();
  else updateLive();
  updateUndo();
}

function updateUndo() {
  $('#undo-button').disabled = !app.past.length;
  $('#redo-button').disabled = !app.future.length;
}

function undo() {
  if (!app.past.length) return;
  app.future.push(clone(app.player));
  app.player = app.past.pop();
  app.version += 1;
  app.lastKey = '';
  scheduleSave();
  render();
}

function redo() {
  if (!app.future.length) return;
  app.past.push(clone(app.player));
  app.player = app.future.pop();
  app.version += 1;
  app.lastKey = '';
  scheduleSave();
  render();
}

/* ---------------- 输入绑定 ---------------- */
function syncInputs(path, value) {
  $$(`[data-bind="${CSS.escape(path)}"]`).forEach(node => {
    if (node === document.activeElement) return;
    if (node.type === 'checkbox') node.checked = Boolean(value);
    else node.value = value;
  });
  $$(`[data-value="${CSS.escape(path)}"]`).forEach(node => {
    node.textContent = String(value) + (node.dataset.unit || '');
  });
}

function handleBoundInput(el) {
  const path = el.dataset.bind;
  if (!path) return;
  let value = el.type === 'checkbox' ? el.checked : el.value;
  if (el.type === 'number' || el.type === 'range' || el.dataset.number) {
    if (value === '') return;
    value = Number(value);
    if (!Number.isFinite(value)) return;
    if (el.min !== '') value = Math.max(Number(el.min), value);
    if (el.max !== '') value = Math.min(Number(el.max), value);
  }
  const label = el.closest('.field')?.querySelector('span')?.textContent || path;
  commit(player => {
    setPath(player, path, value);
    if (path === 'identity.nation') {
      const needle = String(value).trim().toLowerCase();
      const row = app.catalog.nations.find(item => item.zh === value.trim() || item.en.toLowerCase() === needle);
      player.identity.nation_id = row?.id ?? null;
      if (row) {
        player.identity.nation = isEn() ? row.en : row.zh;
        value = player.identity.nation;
      }
    }
    if (path === 'identity.team') {
      const needle = String(value).trim().toLowerCase();
      const row = app.catalog.teams.find(item => item.zh.toLowerCase() === needle || item.en.toLowerCase() === needle);
      player.identity.team_id = row?.id ?? null;
      if (row) {
        player.identity.team = isEn() ? row.en : row.zh;
        value = player.identity.team;
      }
    }
    if (path === 'level.max') player.level.initial = Math.min(player.level.initial, player.level.max);
    if (path === 'level.initial') player.level.initial = Math.min(Math.max(1, player.level.initial), player.level.max);
    if (path === 'boosters.0' || path === 'boosters.1') {
      const slot = path.endsWith('0') ? 0 : 1;
      if (value && value === player.boosters[1 - slot]) player.boosters[1 - slot] = 0;
    }
    if (path === 'identity.position') app.trainingTarget = player.identity.position;
  }, path);
  syncInputs(path, value);
  if (path === 'level.max') {
    const initial = $('[data-bind="level.initial"]');
    if (initial) { initial.max = value; initial.value = app.player.level.initial; }
  }
  if (path.startsWith('boosters.')) {
    $$('[data-bind^="boosters."]').forEach(node => { node.value = app.player.boosters[Number(node.dataset.bind.at(-1))] || 0; });
  }
  if (path === 'card.use_cutout') render();
  if (label && path.startsWith('abilities.')) {
    const finalNode = document.querySelector(`[data-stat-final="${path.split('.')[1]}"]`);
    if (finalNode) {
      const index = path.split('.')[1];
      const delta = app.sim.final[index] - app.player.abilities[index];
      finalNode.style.color = ratingColor(app.sim.final[index]);
      finalNode.innerHTML = `${app.sim.final[index]}${delta ? `<small>${delta > 0 ? '+' : ''}${delta}</small>` : ''}`;
    }
  }
}

document.addEventListener('input', event => {
  const el = event.target;
  if (el.id === 'skill-search') { app.skillQuery = el.value; renderSkillGrid(); return; }
  if (el.id === 'selected-only') { app.selectedOnly = el.checked; renderSkillGrid(); return; }
  if (el.dataset.trainingTarget !== undefined) { app.trainingTarget = el.value; updateLive(); return; }
  if (el.dataset.export !== undefined) {
    app.exportOptions[el.dataset.export] = el.checked;
    localStorage.setItem('maker.exportOptions', JSON.stringify(app.exportOptions));
    return;
  }
  if (el.dataset.aiStyle !== undefined) {
    const key = el.dataset.aiStyle;
    commit(player => {
      const set = new Set(player.ai_styles || []);
      if (el.checked) set.add(key); else set.delete(key);
      player.ai_styles = app.catalog.ai_styles.map(row => row.key).filter(item => set.has(item));
    }, 'ai-style-' + key);
    return;
  }
  if (el.dataset.bind) handleBoundInput(el);
});

/* ---------------- 点击事件 ---------------- */
document.addEventListener('click', event => {
  const nav = event.target.closest('button[data-page], a[data-page]');
  if (nav) { event.preventDefault(); navigate(nav.dataset.page); return; }
  const previewTab = event.target.closest('[data-preview]');
  if (previewTab) { showPreview(previewTab.dataset.preview); return; }
  const action = event.target.closest('[data-action]');
  if (action) { runAction(action); return; }
  const typeButton = event.target.closest('[data-card-type]');
  if (typeButton) {
    const type = cardType(app.catalog, typeButton.dataset.cardType);
    commit(player => {
      player.card.type = type.id;
      player.card.template = type.theme;
      player.card.accent = type.accent;
      player.card.series = cardTypeBadge(type.id);
    }, 'card-type', { rerender: true });
    toast(tf('卡种已切换为 {name}', { name: cardTypeLabel(type) }));
    return;
  }
  const template = event.target.closest('[data-template]');
  if (template) {
    const info = templateById(template.dataset.template);
    commit(player => {
      player.card.template = info.id;
      player.card.accent = info.accent;
      if (info.id === 'custom') {
        player.card.background_style = 'image';
        player.card.background_frame = false;
      } else {
        player.card.background_frame = true;
      }
    }, 'template-' + info.id, { rerender: true });
    return;
  }
  const color = event.target.closest('[data-color-preset]');
  if (color) {
    commit(player => { player.card.accent = color.dataset.colorPreset; }, 'accent', { rerender: true });
    return;
  }
  const filter = event.target.closest('[data-ability-filter]');
  if (filter) { app.abilityFilter = filter.dataset.abilityFilter; render(); return; }
  const skillMode = event.target.closest('[data-skill-mode]');
  if (skillMode) {
    app.skillMode = skillMode.dataset.skillMode;
    $$('[data-skill-mode]').forEach(node => node.classList.toggle('active', node === skillMode));
    return;
  }
  const skill = event.target.closest('[data-skill]');
  if (skill) { toggleSkill(Number(skill.dataset.skill)); return; }
  const step = event.target.closest('[data-step]');
  if (step) {
    const group = step.dataset.group;
    const delta = Number(step.dataset.step);
    commit(player => {
      player.training[group] = clamp(Number(player.training[group] || 0) + delta, 0, 40);
    }, 'training.' + group);
    $$(`[data-bind="training.${group}"]`).forEach(node => { node.value = app.player.training[group]; });
    updateLive();
    return;
  }
  const openPlayer = event.target.closest('[data-open-player]');
  if (openPlayer) { openPlayerCard(openPlayer.dataset.openPlayer); return; }
  const duplicate = event.target.closest('[data-duplicate-player]');
  if (duplicate) { duplicatePlayer(duplicate.dataset.duplicatePlayer); return; }
  const remove = event.target.closest('[data-delete-player]');
  if (remove) { deletePlayer(remove.dataset.deletePlayer); return; }
  const exportOne = event.target.closest('[data-export-player]');
  if (exportOne) { exportProjectPackage(exportOne.dataset.exportPlayer); return; }
  const view = event.target.closest('[data-view]');
  if (view) { app.viewer?.view(view.dataset.view); return; }
  const revealButton = event.target.closest('[data-reveal-export]');
  if (revealButton) { api.reveal(revealButton.dataset.revealExport).catch(error => toast(error.message, true)); return; }
  const openExport = event.target.closest('[data-open-export-folder]');
  if (openExport) { api.reveal(openExport.dataset.openExportFolder).catch(error => toast(error.message, true)); return; }
});

document.addEventListener('dblclick', event => {
  const card = event.target.closest('.player-card');
  if (!card || event.target.closest('button')) return;
  const button = card.querySelector('[data-open-player]');
  if (button) openPlayerCard(button.dataset.openPlayer);
});

document.addEventListener('change', event => {
  const el = event.target;
  if (el.dataset.trainingTarget !== undefined) { app.trainingTarget = el.value; updateLive(); }
  if (el.dataset.aiStyle !== undefined && el.type === 'checkbox') {
    const key = el.dataset.aiStyle;
    commit(player => {
      const set = new Set(player.ai_styles || []);
      if (el.checked) set.add(key); else set.delete(key);
      player.ai_styles = app.catalog.ai_styles.map(row => row.key).filter(item => set.has(item));
    }, 'ai-style-' + key);
  }
  if (el.dataset.modelOption) {
    app.viewer?.setOptions({ [el.dataset.modelOption]: el.checked });
  }
});

function toggleSkill(id) {
  const mode = app.skillMode;
  const player = app.player;
  const innate = player.skills.innate.includes(id);
  const additional = player.skills.additional.includes(id);
  if (mode === 'additional' && !additional && !innate && player.skills.additional.length >= 10) {
    toast(tr('额外习得技能最多 10 项，请先取消其中一项'), true);
    return;
  }
  commit(p => {
    p.skills.innate = p.skills.innate.filter(item => item !== id);
    p.skills.additional = p.skills.additional.filter(item => item !== id);
    if (mode === 'innate' && !innate) p.skills.innate.push(id);
    if (mode === 'additional' && !additional) p.skills.additional.push(id);
  }, 'skill-' + id);
  renderSkillGrid();
}

/* ---------------- 动作 ---------------- */
const ACTIONS = {
  'new-player': () => openNewDialog(),
  'import-project': () => importProjectFile(),
  'export-project': () => exportProjectPackage(app.player.id),
  'upload-portrait': () => uploadPortrait(),
  'remove-portrait': () => commit(player => { player.card.portrait = null; player.card.cutout_asset = null; }, 'remove-portrait', { rerender: true }),
  'cutout-photo': button => runCutout(button),
  'upload-background': () => uploadBackground(),
  'remove-background': () => commit(player => { player.card.background_image = null; }, 'remove-bg', { rerender: true }),
  'export-card': () => downloadCard(),
  'export-avatar': () => downloadAvatar(),
  'open-export-page': () => navigate('export'),
  'open-model-page': () => navigate('model'),
  'load-archetype': () => applyArchetype(),
  'reset-abilities': () => commit(player => {
    for (const row of app.catalog.abilities) player.abilities[String(row.index)] = 65;
  }, 'reset-abilities', { rerender: true }),
  'auto-train': () => {
    commit(player => { player.training = autoAllocate(player, app.catalog, app.trainingTarget || player.identity.position); }, 'auto-train');
    syncTrainingInputs();
    updateLive();
    toast(tr('已按目标位置生成参考加点'));
  },
  'optimal-train': () => {
    commit(player => { player.training = optimalTraining(player, app.catalog, app.trainingTarget || player.identity.position); }, 'optimal-train');
    syncTrainingInputs();
    updateLive();
    toast(tr('已按总评最优重新分配培养点'));
  },
  'reset-training': () => {
    commit(player => { for (const group of app.catalog.training_groups) player.training[group.id] = 0; }, 'reset-training');
    syncTrainingInputs();
    updateLive();
  },
  'upload-model': () => uploadModel(),
  'remove-model': () => removeModel(),
  'export-glb': () => downloadModel('glb'),
  'export-obj': () => downloadModel('obj'),
  'capture-portrait': () => captureModel('portrait'),
  'capture-avatar': () => captureModel('avatar'),
  'export-files': button => runExport(button, false),
  'export-zip': button => runExport(button, true),
  'export-all': button => exportAll(button),
  'open-exports': () => api.reveal().catch(error => toast(error.message, true)),
  'open-data': () => api.reveal(app.appInfo.data_dir).catch(error => toast(error.message, true)),
  'reveal-latest': () => {
    if (!app.lastExportFolder) return toast(tr('还没有导出记录'), true);
    api.reveal(app.lastExportFolder).catch(error => toast(error.message, true));
  },
};

function runAction(button) {
  const handler = ACTIONS[button.dataset.action];
  if (!handler) return;
  withBusy(button, () => handler(button)).catch(error => toast(error.message, true));
}

async function withBusy(button, task) {
  if (button?.classList.contains('busy')) return;
  button?.classList.add('busy');
  try { return await task(); } finally { button?.classList.remove('busy'); }
}

/* ---------------- 新建 / 切换球员 ---------------- */
function buildDialogs() {
  document.querySelector('#player-dialog')?.remove();
  const dialog = document.createElement('dialog');
  dialog.className = 'modal';
  dialog.id = 'player-dialog';
  dialog.innerHTML = `<form method="dialog" class="modal-body">
    <div class="eyebrow">NEW PLAYER</div><h2>${tr('新建球员')}</h2>
    <p>${tr('建立一个独立球员工程。已保存的球员不会被覆盖，资料会立即写入本机。')}</p>
    <div class="field-grid" style="margin-top:16px">
      <label class="field"><span>${tr('球员姓名')}</span><input class="input" id="np-name" maxlength="40" placeholder="${tr('例如：凌 风')}"></label>
      <label class="field"><span>${tr('主要位置')}</span><select id="np-position">${app.catalog.positions.map(row => `<option value="${row.code}">${row.code} · ${positionLabel(row.code)}</option>`).join('')}</select></label>
      <label class="field"><span>${tr('卡种')}</span><select id="np-type">${app.catalog.card_types.map(row => `<option value="${row.id}">${cardTypeLabel(row)}</option>`).join('')}</select></label>
      <label class="field"><span>${tr('参考模板（可选）')}</span><select id="np-archetype"><option value="">${tr('不使用参考')}</option>${app.catalog.archetypes.map(row => `<option value="${row.id}">${row.id} · ${positionLabel(row.id)}</option>`).join('')}</select></label>
    </div>
    <div class="row" style="margin-top:20px;justify-content:flex-end">
      <button class="button subtle" value="cancel">${tr('取消')}</button>
      <button class="button primary" value="create" id="np-create">${icon('plus')}${tr('创建球员')}</button>
    </div>
  </form>`;
  document.body.append(dialog);
  dialog.addEventListener('close', async () => {
    if (dialog.returnValue !== 'create') return;
    const name = $('#np-name').value.trim() || tr('新球员');
    const position = $('#np-position').value;
    const type = cardType(app.catalog, $('#np-type').value);
    const archetype = $('#np-archetype').value;
    await createPlayer(name, position, type, archetype);
  });
}

function openNewDialog() {
  const dialog = $('#player-dialog');
  if (!dialog) return;
  $('#np-name').value = '';
  $('#np-position').value = 'CF';
  $('#np-type').value = 'Epic';
  $('#np-archetype').value = '';
  dialog.returnValue = '';
  dialog.showModal();
  setTimeout(() => $('#np-name').focus(), 50);
}

async function createPlayer(name, position, type, archetype) {
  const player = newPlayer(app.catalog, { name, position, card_type: type.id });
  player.card.template = type.theme;
  player.card.accent = type.accent;
  if (archetype) {
    const row = app.catalog.archetypes.find(item => item.id === archetype);
    if (row) {
      for (const [index, value] of Object.entries(row.abilities)) player.abilities[index] = value;
      player.identity.position = archetype;
      player.position_aptitudes[archetype] = 2;
    }
  }
  app.player = player;
  app.trainingTarget = player.identity.position;
  app.past = [];
  app.future = [];
  app.version += 1;
  app.savedVersion = -1;
  app.page = 'profile';
  app.mountedModelAsset = null;
  app.viewer?.clear();
  await flushSave(true);
  render();
  toast(tf('已创建 {name}，修改会自动保存', { name }));
}

async function openPlayerCard(id) {
  const row = app.projects.find(item => item.id === id);
  if (!row?.project) return toast(tr('找不到这名球员'), true);
  await flushSave();
  app.player = normalizePlayer(row.project, app.catalog);
  app.trainingTarget = app.player.identity.position;
  app.past = [];
  app.future = [];
  app.version += 1;
  app.savedVersion = app.version;
  app.mountedModelAsset = null;
  app.viewer?.clear();
  app.page = 'profile';
  localStorage.setItem('maker.last', app.player.id);
  render();
}

async function duplicatePlayer(id) {
  const row = app.projects.find(item => item.id === id);
  if (!row?.project) return;
  const copy = clone(row.project);
  copy.id = crypto.randomUUID();
  copy.created_at = copy.updated_at = new Date().toISOString();
  copy.identity.name = (copy.identity.name || tr('球员')) + (isEn() ? ' (Copy)' : ` ${tr('副本')}`);
  copy.card.serial = Number(copy.card.serial || 1) + 1;
  const result = await api.api('project/save', { project: copy });
  updateProjectRow(result.project);
  await openPlayerCard(result.project.id);
  toast(tr('已复制球员，可以独立编辑'));
}

async function deletePlayer(id) {
  const row = app.projects.find(item => item.id === id);
  if (!row) return;
  const ok = await confirmDialog(tr('删除球员'), tf('确定删除“{name}”吗？工程文件会从 data/players 移除，自动备份也会一起清理。', { name: row.name }), tr('删除'), true);
  if (!ok) return;
  await api.api('project/delete', { id });
  app.projects = app.projects.filter(item => item.id !== id);
  if (app.player?.id === id) {
    if (app.projects.length) {
      app.player = normalizePlayer(app.projects[0].project, app.catalog);
      app.trainingTarget = app.player.identity.position;
      app.savedVersion = app.version;
    } else {
      app.player = newPlayer(app.catalog, { name: tr('新球员') });
      app.trainingTarget = app.player.identity.position;
      app.version += 1;
      app.savedVersion = -1;
      await flushSave(true);
    }
    app.page = 'players';
    app.mountedModelAsset = null;
    app.viewer?.clear();
  }
  render();
  toast(tr('球员已删除'));
}

async function importProjectFile() {
  const file = await pickFile('.psplayer,.zip,application/zip');
  if (!file) return;
  const result = await api.importProject(file);
  updateProjectRow(result.project);
  await openPlayerCard(result.project.id);
  toast(result.assets ? tf('工程已导入，恢复 {n} 个素材', { n: result.assets }) : tr('工程已导入'));
}

async function exportProjectPackage(id) {
  if (!id) return;
  await flushSave();
  const result = await api.exportProject(id);
  app.lastExportPath = result.path;
  app.lastExportUrl = result.url;
  toast(tf('工程已导出：{name}', { name: result.name }));
  const link = document.createElement('a');
  link.href = result.url;
  link.download = result.name;
  document.body.append(link);
  link.click();
  link.remove();
}

/* ---------------- 照片与抠图 ---------------- */
async function uploadPortrait() {
  const file = await pickFile('image/png,image/jpeg,image/webp,image/gif');
  if (!file) return;
  const asset = await api.uploadAsset(file, 'image');
  commit(player => {
    player.card.portrait = asset.id;
    player.card.cutout_asset = null;
    player.card.use_cutout = false;
    player.card.photo = { zoom: 1, x: 0, y: 0, rotate: 0 };
  }, 'portrait', { rerender: true });
  toast(tr('照片已导入，可以点“抠图”去掉纯色背景'));
}

async function uploadBackground() {
  const file = await pickFile('image/png,image/jpeg,image/webp');
  if (!file) return;
  const asset = await api.uploadAsset(file, 'image');
  commit(player => {
    player.card.background_image = asset.id;
    player.card.background_style = 'image';
  }, 'background', { rerender: true });
}

async function runCutout(button) {
  const tolerance = Number($('[data-bind="card.cutout_tolerance"]')?.value || app.player.card.cutout_tolerance || 34);
  toast(tr('正在抠图，请稍候…'));
  const result = await cutout(app.player.card.portrait, { tolerance });
  const file = new File([result.blob], `cutout-${Date.now()}.png`, { type: 'image/png' });
  const asset = await api.uploadAsset(file, 'image');
  commit(player => {
    player.card.cutout_asset = asset.id;
    player.card.use_cutout = true;
  }, 'cutout', { rerender: true });
  toast(tr('抠图完成，已用于卡面；容差可以再调'));
}

/* ---------------- 能力模板 ---------------- */
function applyArchetype() {
  const select = $('#archetype-select');
  const row = app.catalog.archetypes.find(item => item.id === select?.value);
  if (!row) return;
  commit(player => {
    for (const [index, value] of Object.entries(row.abilities)) player.abilities[index] = value;
  }, 'archetype-' + row.id, { rerender: true });
  toast(tf('已套用 {pos} 参考能力（{n} 名球员平均）', { pos: positionLabel(row.id), n: row.sample }));
}

/* ---------------- 模型 ---------------- */
async function uploadModel() {
  const file = await pickFile('.glb,.gltf,.obj');
  if (!file) return;
  const asset = await api.uploadAsset(file, 'model');
  const extension = file.name.split('.').pop().toLowerCase();
  app.mountedModelAsset = null;
  commit(player => {
    player.model.asset = asset.id;
    player.model.name = file.name;
    player.model.format = extension.toUpperCase();
    player.model.stats = null;
    player.model.capture = null;
  }, 'model-upload', { rerender: true });
  toast(tr('模型已导入，正在读取网格'));
}

async function removeModel() {
  commit(player => {
    player.model = { asset: null, name: '', format: '', transform: { scale: 1, rotate: 0, lift: 0 }, capture: null, stats: null };
  }, 'model-remove', { rerender: true });
  app.mountedModelAsset = null;
  app.viewer?.clear();
}

async function downloadModel(format) {
  if (!app.viewer?.subject) return toast(tr('请先导入模型'), true);
  const source = (app.player.model.name || app.player.model.asset || '').split('.').pop().toLowerCase();
  let blob;
  let extension = format;
  if (format === 'glb' && (source === 'glb' || source === 'gltf')) {
    blob = await app.viewer.originalBlob();
    extension = source;
  } else if (format === 'obj' && source === 'obj') {
    blob = await app.viewer.originalBlob();
    extension = 'obj';
  } else if (format === 'obj') {
    blob = app.viewer.exportOBJ();
  } else {
    blob = await app.viewer.exportGLB();
  }
  downloadBlob(blob, `${fileStem(app.player.identity.name)}${fileSuffix('model')}.${extension}`);
  toast(tf('已导出 {format} 模型', { format: extension.toUpperCase() }));
}

async function captureModel(mode) {
  if (!app.viewer?.subject) return toast(tr('请先导入模型'), true);
  toast(mode === 'avatar' ? tr('正在取景小头像…') : tr('正在取景卡面照片…'));
  const blob = await app.viewer.capture(mode);
  const asset = await api.uploadAsset(new File([blob], `capture-${mode}-${Date.now()}.png`, { type: 'image/png' }), 'image');
  commit(player => {
    player.model.capture = { ...(player.model.capture || {}), [mode === 'avatar' ? 'avatar' : 'portrait']: asset.id };
    if (mode !== 'avatar') {
      player.card.portrait = asset.id;
      player.card.cutout_asset = null;
      player.card.use_cutout = false;
      player.card.photo = { zoom: 1, x: 0, y: 0, rotate: 0 };
    }
  }, 'capture-' + mode, { rerender: true });
  toast(mode === 'avatar' ? tr('小头像已保存') : tr('取景已用于卡面照片'));
}

/* ---------------- 导出卡面 ---------------- */
function canvasBlob(canvas) {
  return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error(tr('画布导出失败'))), 'image/png'));
}

async function downloadCard() {
  const canvas = await cardCanvas(app.player, app.sim, app.catalog, 1200);
  const blob = await canvasBlob(canvas);
  downloadBlob(blob, `${fileStem(app.player.identity.name)}${fileSuffix('card')}`);
  toast(tr('卡面已导出：1200 × 1720 PNG'));
}

async function downloadAvatar() {
  const canvas = await avatarCanvas(app.player, app.sim, app.catalog, 512);
  const blob = await canvasBlob(canvas);
  downloadBlob(blob, `${fileStem(app.player.identity.name)}${fileSuffix('avatar')}`);
  toast(tr('小头像已导出：512 × 512 PNG'));
}

/* ---------------- 资料文件 ---------------- */
function buildPlayerData(player, sim) {
  const rows = app.catalog.abilities;
  return {
    format: 'player-maker/player-data',
    version: 1,
    language: getLang(),
    generated_by: { name: tr('球员工坊 · 制作器'), version: app.appInfo.version || '1.0.0' },
    generated_at: localIso(),
    catalog: { release_id: app.catalog.release_id, source: app.catalog.generated_from },
    player: {
      id: player.id,
      identity: player.identity,
      card: player.card,
      level: player.level,
      traits: player.traits,
      condition: player.condition,
      play_style: player.play_style,
      position_aptitudes: player.position_aptitudes,
      skills: {
        innate: player.skills.innate.map(id => skillInfo(id)),
        additional: player.skills.additional.map(id => skillInfo(id)),
      },
      ai_styles: player.ai_styles,
      boosters: (player.boosters || []).filter(Boolean).map(id => {
        const row = app.catalog.boosters.find(item => item.id === id);
        return row ? { id: row.id, label: row.zh, en: boosterEnglish(row), effects: row.effects, conditional: row.conditional } : null;
      }).filter(Boolean),
      model: player.model,
      notes: player.notes,
    },
    ratings: {
      overall: sim.overall,
      base: sim.baseOverall,
      trained: sim.trainedOverall,
      boosted: sim.boostedOverall,
      by_position: sim.byPosition,
      six: sim.six,
    },
    abilities: rows.map(row => {
      const index = String(row.index);
      return {
        index: row.index, key: row.key, zh: row.zh, en: row.en,
        base: sim.base[index], trained: sim.trained[index], boosted: sim.boosted[index], final: sim.final[index],
      };
    }),
  };
}

function boosterEnglish(booster) {
  const entries = Object.entries(booster.effects || {});
  if (!entries.length) return 'No permanent effect';
  if (entries.length >= 26) return `All abilities ${entries[0][1] >= 0 ? '+' : ''}${entries[0][1]}`;
  return entries.map(([index, value]) => {
    const row = app.catalog.abilities.find(item => item.index === Number(index));
    return `${row ? row.en : index} ${value >= 0 ? '+' : ''}${value}`;
  }).join(' · ');
}

function skillInfo(id) {
  const row = app.catalog.skills.find(item => item.id === Number(id));
  return row ? { id: row.id, zh: row.zh, en: skillEnglish(row), code: row.code } : { id: Number(id), zh: '', en: '', code: '' };
}

function buildMarkdown(player, sim) {
  const rows = app.catalog.abilities;
  const identity = player.identity;
  const card = cardType(app.catalog, player.card.type);
  const skillRows = [...player.skills.innate, ...player.skills.additional].map(id => skillInfo(id));
  const innate = player.skills.innate.map(id => isEn() ? skillInfo(id).en : skillInfo(id).zh).filter(Boolean);
  const additional = player.skills.additional.map(id => isEn() ? skillInfo(id).en : skillInfo(id).zh).filter(Boolean);
  const boosters = (player.boosters || []).filter(Boolean).map(id => app.catalog.boosters.find(item => item.id === id)).filter(Boolean).map(row => isEn() ? boosterEnglish(row) : row.zh);
  const table = rows.map(row => `| ${abilityLabel(row)} | ${sim.base[String(row.index)]} | ${sim.trained[String(row.index)]} | ${sim.boosted[String(row.index)]} | ${sim.final[String(row.index)]} |`).join('\n');
  if (isEn()) {
    return `# ${identity.name || 'Unnamed player'}

> ${identity.position} · ${cardTypeLabel(card)} · Overall ${sim.overall}

- Shirt name: ${identity.shirt_name || identity.name || ''}
- Age / Height / Weight: ${identity.age} yrs / ${identity.height_cm} cm / ${identity.weight_kg} kg
- Preferred foot: ${footLabel(identity.foot)}
- Nationality: ${nationDisplay(app.catalog, identity)}
- Club: ${teamDisplay(app.catalog, identity)}
- Card: ${cardTypeLabel(card)} · ${player.card.title || ''} · NO.${String(player.card.serial || 1).padStart(4, '0')}

## Ratings

| Item | Value |
| --- | ---: |
| Overall | ${sim.overall} |
| Base overall | ${sim.baseOverall} |
| Trained | ${sim.trainedOverall} |
| Boosted | ${sim.boostedOverall} |

## Abilities

| Ability | Base | Trained | Boosted | Final |
| --- | ---: | ---: | ---: | ---: |
${table}

## Skills

- Innate skills: ${innate.join(', ') || 'None'}
- Additional skills: ${additional.join(', ') || 'None'}
- Boosters: ${boosters.join(', ') || 'None'}

## Notes

${player.notes || 'None'}

---

Generated by ${tr('球员工坊 · 制作器')} v${app.appInfo.version || '1.0.0'} · ${new Date().toLocaleString('en-GB')}
`;
  }
  return `# ${identity.name || '未命名球员'}

> ${identity.position} · ${cardTypeLabel(card)} · 总评 ${sim.overall}

- 球衣名：${identity.shirt_name || identity.name || ''}
- 年龄 / 身高 / 体重：${identity.age} 岁 / ${identity.height_cm} cm / ${identity.weight_kg} kg
- 惯用脚：${identity.foot}
- 国籍：${identity.nation || ''}
- 俱乐部：${identity.team || ''}
- 卡面：${cardTypeLabel(card)} · ${player.card.title || ''} · NO.${String(player.card.serial || 1).padStart(4, '0')}

## 总评

| 项目 | 数值 |
| --- | ---: |
| 计算总评 | ${sim.overall} |
| 基础总评 | ${sim.baseOverall} |
| 培养后 | ${sim.trainedOverall} |
| 增能后 | ${sim.boostedOverall} |

## 能力

| 能力 | 基础 | 培养后 | 增能后 | 最终 |
| --- | ---: | ---: | ---: | ---: |
${table}

## 技能

- 天生技能：${innate.join('、') || '无'}
- 额外习得：${additional.join('、') || '无'}
- 球员增能：${boosters.join('、') || '无'}

## 备注

${player.notes || '无'}

---

由 ${tr('球员工坊 · 制作器')} v${app.appInfo.version || '1.0.0'} 生成 · ${new Date().toLocaleString('zh-CN')}
`;
}

function buildCsv(player, sim) {
  const rows = app.catalog.abilities.map(row => abilityLabel(row));
  const header = [tr('姓名'), tr('位置'), tr('卡种'), tr('总评'), ...rows];
  const values = [player.identity.name, player.identity.position, cardTypeLabel(cardType(app.catalog, player.card.type)), sim.overall,
    ...app.catalog.abilities.map(row => sim.final[String(row.index)])];
  const quote = value => `"${String(value ?? '').replaceAll('"', '""')}"`;
  return '\uFEFF' + [header, values].map(row => row.map(quote).join(',')).join('\r\n');
}

/* ---------------- 打包导出 ---------------- */
function selectedExport(options = app.exportOptions) {
  return {
    card: options.card !== false,
    avatar: options.avatar !== false,
    json: options.json !== false,
    markdown: options.markdown !== false,
    csv: options.csv !== false,
    model: options.model !== false && Boolean(app.player.model.asset),
    modelCapture: options.modelCapture !== false && Boolean(app.player.model.capture?.portrait),
  };
}

async function writePlayerFiles(player, sim, folder, options, stem) {
  const written = [];
  const write = async (name, blob) => {
    const result = await api.saveExportFile(folder, name, blob);
    written.push({ name: result.name, size: blob.size });
    return result;
  };
  if (options.card) {
    const canvas = await cardCanvas(player, sim, app.catalog, 1200);
    await write(`${stem}${fileSuffix('card')}`, await canvasBlob(canvas));
  }
  if (options.avatar) {
    const canvas = await avatarCanvas(player, sim, app.catalog, 512);
    await write(`${stem}${fileSuffix('avatar')}`, await canvasBlob(canvas));
  }
  if (options.json) {
    const data = buildPlayerData(player, sim);
    await write(`${stem}${fileSuffix('json')}`, new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
  }
  if (options.markdown) {
    await write(`${stem}${fileSuffix('markdown')}`, new Blob([buildMarkdown(player, sim)], { type: 'text/markdown;charset=utf-8' }));
  }
  if (options.csv) {
    await write(`${stem}${fileSuffix('csv')}`, new Blob([buildCsv(player, sim)], { type: 'text/csv;charset=utf-8' }));
  }
  if (options.model && player.model.asset) {
    const extension = (player.model.name || player.model.asset).split('.').pop().toLowerCase();
    const response = await fetch(api.assetUrl(player.model.asset));
    if (response.ok) await write(`${stem}${fileSuffix('model')}.${extension}`, await response.blob());
  }
  if (options.modelCapture && player.model.capture?.portrait) {
    const response = await fetch(api.assetUrl(player.model.capture.portrait));
    if (response.ok) await write(`${stem}${fileSuffix('modelPreview')}`, await response.blob());
  }
  return written;
}

async function runExport(button, zip) {
  await flushSave();
  const options = selectedExport();
  if (!Object.values(options).some(Boolean)) return toast(tr('请至少选择一项导出内容'), true);
  const stem = fileStem(app.player.identity.name);
  const folder = await api.startExport(stem);
  const written = await writePlayerFiles(app.player, app.sim, folder.folder, options, stem);
  app.lastExportFolder = folder.path;
  let result = null;
  if (zip) {
    result = await api.finishExport(folder.folder, `${stem}-${stampText()}.zip`);
    app.lastExportUrl = result.url;
    app.lastExportPath = result.path;
  }
  showExportResult(written, folder, result, stem, zip);
  toast(zip ? tf('已打包 {n} 个文件', { n: written.length }) : tf('已导出 {n} 个文件到本机', { n: written.length }));
}

function stampText() {
  const now = new Date();
  const pad = value => String(value).padStart(2, '0');
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
}

function localIso() {
  const now = new Date();
  const pad = value => String(value).padStart(2, '0');
  const offset = -now.getTimezoneOffset();
  const sign = offset >= 0 ? '+' : '-';
  const hours = Math.floor(Math.abs(offset) / 60);
  const minutes = Math.abs(offset) % 60;
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}${sign}${pad(hours)}:${pad(minutes)}`;
}

function showExportResult(written, folder, result, stem, zipped = false) {
  const target = $('#export-result');
  if (!target) return;
  const links = zipped ? '' : written.map(row => `<div class="file-row"><span class="name">${esc(row.name)}</span><span class="size">${formatBytes(row.size)}</span><a href="/exports/${encodeURIComponent(folder.folder)}/${encodeURIComponent(row.name)}?download=1" download>${tr('下载')}</a></div>`).join('');
  target.innerHTML = `<div class="export-result">${zipped ? esc(tf('已打包 {n} 个文件', { n: written.length })) : esc(tf('已导出 {n} 个文件到', { n: written.length }))}<br><code>${esc(zipped ? (result?.path || folder.path) : folder.path)}</code>
    ${links ? `<div class="file-list" style="margin-top:9px">${links}</div>` : ''}
    ${result ? `<div style="margin-top:10px">${tr('压缩包：')}<a class="text-link" href="${result.url}" download="${esc(result.name)}">${esc(result.name)}</a></div>` : ''}
    <div class="photo-actions" style="margin-top:10px">${zipped ? `<button class="button secondary small" data-action="open-exports">${icon('folder')}${tr('打开导出目录')}</button>` : `<button class="button secondary small" data-reveal-export="${esc(folder.path)}">${icon('folder')}${tr('打开文件夹')}</button>`}</div>
  </div>`;
  hydrateIcons(target);
}

async function exportAll(button) {
  await flushSave();
  if (!app.projects.length) return toast(tr('还没有球员可以导出'), true);
  const folder = await api.startExport(tr('全部球员'));
  let total = 0;
  for (const [index, row] of app.projects.entries()) {
    if (!row.project) continue;
    const player = normalizePlayer(row.project, app.catalog);
    const sim = simulate(player, app.catalog);
    const stem = fileStem(player.identity.name);
    const files = await writePlayerFiles(player, sim, folder.folder, {
      card: true, avatar: true, json: true, markdown: true, csv: false, model: false, modelCapture: false,
    }, `${String(index + 1).padStart(2, '0')}-${stem}`);
    total += files.length;
    toast(tf('已导出 {n} / {total}：{name}', { n: index + 1, total: app.projects.length, name: player.identity.name }));
  }
  const result = await api.finishExport(folder.folder, `${tr('全部球员')}-${stampText()}.zip`);
  app.lastExportFolder = folder.path;
  app.lastExportUrl = result.url;
  app.lastExportPath = result.path;
  const target = $('#export-result');
  if (target) {
    target.innerHTML = `<div class="export-result">${esc(tf('已导出 {n} 名球员、{m} 个文件。', { n: app.projects.length, m: total }))}<br>${tr('压缩包：')}<a class="text-link" href="${result.url}" download="${esc(result.name)}">${esc(result.name)}</a>
      <div class="photo-actions" style="margin-top:10px"><button class="button secondary small" data-action="open-exports">${icon('folder')}${tr('打开导出目录')}</button></div></div>`;
    hydrateIcons(target);
  }
  toast(tr('全部球员已打包导出'));
}

async function loadHistory() {
  const target = $('#export-history');
  if (!target) return;
  try {
    const data = await api.api('exports');
    if (!data.rows.length) { target.innerHTML = `<span class="inline-tip">${tr('还没有导出记录')}</span>`; return; }
    target.innerHTML = data.rows.map(row => {
      const name = esc(row.name);
      if (row.dir) {
        return `<div class="history-row"><strong>${name}</strong><span>${tf('{n} 个文件', { n: row.count || 0 })}</span><span class="size">${esc(formatTime(new Date(row.mtime * 1000).toISOString()))}</span><button class="button subtle small" data-open-export-folder="${esc(row.name)}">${tr('打开')}</button></div>`;
      }
      return `<div class="history-row"><strong>${name}</strong><span>${formatBytes(row.size)}</span><a class="button subtle small" href="/exports/${encodeURIComponent(row.name)}?download=1" download>${tr('下载')}</a></div>`;
    }).join('');
  } catch (error) {
    target.innerHTML = `<span class="inline-tip">${esc(error.message)}</span>`;
  }
}

/* ---------------- 预览标签 ---------------- */
function showPreview(name) {
  app.preview = name;
  $$('[data-preview]').forEach(node => node.classList.toggle('active', node.dataset.preview === name));
  for (const kind of ['card', 'data', 'model']) $('#preview-' + kind)?.classList.toggle('hidden', kind !== name);
  if (name === 'data') updateRadar();
  if (name === 'model') updateModelPreview();
}

/* ---------------- 弹窗、提示与文件选择 ---------------- */
function toast(message, error = false) {
  const container = $('#toasts');
  const node = document.createElement('div');
  node.className = 'toast' + (error ? ' error' : '');
  node.textContent = message;
  container.append(node);
  while (container.children.length > 4) container.firstElementChild.remove();
  setTimeout(() => node.remove(), error ? 8000 : 4200);
}

function confirmDialog(title, message, okLabel = tr('确定'), danger = false) {
  return new Promise(resolve => {
    const dialog = document.createElement('dialog');
    dialog.className = 'modal';
    dialog.innerHTML = `<div class="modal-body"><div class="eyebrow">CONFIRM</div><h2>${esc(title)}</h2><p>${message}</p>
      <div class="row" style="margin-top:20px;justify-content:flex-end">
        <button class="button subtle" data-result="0">${tr('取消')}</button>
        <button class="button ${danger ? 'danger' : 'primary'}" data-result="1">${esc(okLabel)}</button>
      </div></div>`;
    document.body.append(dialog);
    dialog.addEventListener('click', event => {
      const button = event.target.closest('[data-result]');
      if (!button) return;
      dialog.close();
      resolve(button.dataset.result === '1');
    });
    dialog.addEventListener('close', () => { dialog.remove(); resolve(false); }, { once: true });
    dialog.showModal();
  });
}

function pickFile(accept) {
  return new Promise(resolve => {
    const input = $('#hidden-file');
    input.value = '';
    input.accept = accept;
    input.onchange = () => resolve(input.files?.[0] || null);
    input.click();
  });
}

function updateWelcome() {
  const dialog = $('#welcome-dialog');
  if (!dialog) return;
  if (localStorage.getItem('maker.announcement.v1') === '1') return;
  dialog.showModal();
  $('#welcome-dont-show').checked = false;
  $('#welcome-start').addEventListener('click', () => {
    if ($('#welcome-dont-show').checked) localStorage.setItem('maker.announcement.v1', '1');
    dialog.close();
  }, { once: true });
}

/* ---------------- 全局交互 ---------------- */
function bindGlobal() {
  $('#undo-button').addEventListener('click', undo);
  $('#redo-button').addEventListener('click', redo);
  $('#new-player').addEventListener('click', () => openNewDialog());
  $('#quick-export').addEventListener('click', () => navigate('export'));
  $('#export-card').addEventListener('click', () => withBusy($('#export-card'), downloadCard).catch(error => toast(error.message, true)));
  $('#open-model-page').addEventListener('click', () => navigate('model'));
  $('#open-data').addEventListener('click', () => api.reveal(app.appInfo.data_dir).catch(error => toast(error.message, true)));
  $('#compact-page').addEventListener('change', event => navigate(event.target.value));
  $('#lang-toggle').addEventListener('click', () => changeLanguage(isEn() ? 'zh' : 'en'));

  document.addEventListener('keydown', event => {
    const mod = event.ctrlKey || event.metaKey;
    if (mod && event.key.toLowerCase() === 's') {
      event.preventDefault();
      flushSave(true).then(() => toast(tr('工程已保存'))).catch(() => {});
    }
    if (mod && event.key.toLowerCase() === 'z' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) {
      event.preventDefault();
      if (event.shiftKey) redo(); else undo();
    }
  });

  const canvas = $('#player-card');
  canvas.style.cursor = 'grab';
  canvas.addEventListener('pointerdown', event => {
    if (!app.player?.card?.portrait) return;
    app.drag = {
      x: event.clientX, y: event.clientY,
      px: Number(app.player.card.photo.x) || 0, py: Number(app.player.card.photo.y) || 0,
      snapshot: clone(app.player),
    };
    try { canvas.setPointerCapture(event.pointerId); } catch { /* synthetic pointer events */ }
    canvas.style.cursor = 'grabbing';
  });
  canvas.addEventListener('pointermove', event => {
    if (!app.drag) return;
    const scale = 600 / event.target.clientWidth;
    const photo = app.player.card.photo;
    photo.x = clamp(Math.round(app.drag.px + (event.clientX - app.drag.x) * scale), -150, 150);
    photo.y = clamp(Math.round(app.drag.py + (event.clientY - app.drag.y) * scale), -150, 150);
    syncInputs('card.photo.x', photo.x);
    syncInputs('card.photo.y', photo.y);
    app.sim = simulate(app.player, app.catalog);
    drawPreview();
    scheduleSave();
  });
  const endDrag = () => {
    if (!app.drag) return;
    if (JSON.stringify(app.drag.snapshot.card.photo) !== JSON.stringify(app.player.card.photo)) {
      app.past.push(app.drag.snapshot);
      if (app.past.length > 80) app.past.shift();
      app.future = [];
      app.version += 1;
      scheduleSave();
      updateUndo();
    }
    app.drag = null;
    canvas.style.cursor = 'grab';
  };
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);

  document.addEventListener('dragover', event => {
    if (!event.dataTransfer?.types?.includes('Files')) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  document.addEventListener('drop', event => {
    const file = event.dataTransfer?.files?.[0];
    if (!file) return;
    event.preventDefault();
    if (/\.(glb|gltf|obj)$/i.test(file.name)) {
      if (app.page !== 'model') navigate('model');
      importDroppedModel(file);
      return;
    }
    if (/^image\//.test(file.type)) {
      if (app.page !== 'card') navigate('card');
      importDroppedImage(file);
      return;
    }
    if (/\.psplayer$|\.zip$/i.test(file.name)) importDroppedProject(file);
  });

  window.addEventListener('beforeunload', () => { if (app.savedVersion < app.version) flushSave(); });
}

async function importDroppedImage(file) {
  const asset = await api.uploadAsset(file, 'image');
  commit(player => {
    player.card.portrait = asset.id;
    player.card.cutout_asset = null;
    player.card.use_cutout = false;
    player.card.photo = { zoom: 1, x: 0, y: 0, rotate: 0 };
  }, 'portrait', { rerender: true });
  toast(tr('照片已导入'));
}

async function importDroppedModel(file) {
  const asset = await api.uploadAsset(file, 'model');
  const extension = file.name.split('.').pop().toLowerCase();
  app.mountedModelAsset = null;
  commit(player => {
    player.model.asset = asset.id;
    player.model.name = file.name;
    player.model.format = extension.toUpperCase();
    player.model.stats = null;
    player.model.capture = null;
  }, 'model-upload', { rerender: true });
  toast(tr('模型已导入'));
}

async function importDroppedProject(file) {
  const result = await api.importProject(file);
  updateProjectRow(result.project);
  await openPlayerCard(result.project.id);
  toast(tr('工程已导入'));
}

/* ---------------- 启动 ---------------- */
boot().catch(error => {
  console.error(error);
  const content = $('#editor-content');
  if (content) content.innerHTML = `<div class="empty-state"><strong>${tr('制作器没有启动成功')}</strong>${esc(error.message)}<br>${tr('请关闭窗口后重新启动；如果问题持续，查看 data/studio.log。')}</div>`;
  toast(error.message, true);
});

