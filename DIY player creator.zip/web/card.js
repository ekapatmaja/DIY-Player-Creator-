/* 卡面渲染引擎：600 × 860 逻辑画布，2 倍导出 1200 × 1720。
   所有图形由 Canvas 绘制，不依赖游戏原版卡图。 */

import { assetUrl } from './api.js';
import { ratingColor, clamp } from './core.js';
import { tr, isEn, sixLabel, skillLabel, nationDisplay, teamDisplay, footLabel, cardTypeBadge } from './i18n.js';

export const CARD_W = 600;
export const CARD_H = 860;

const FONT_UI = '"Microsoft YaHei", "Microsoft YaHei UI", "Segoe UI", system-ui, sans-serif';
const FONT_NUM = '"Bahnschrift", "DIN Alternate", "Arial Black", Impact, sans-serif';
const FONT_EN = '"Bahnschrift", "Segoe UI", Arial, sans-serif';

export const CARD_TEMPLATES = [
  { id: 'bigtime', label: 'Big Time · 碎光', accent: '#5fe1ff', bg: ['#041a2e', '#01050c'], pattern: 'shards', frame: 'sport' },
  { id: 'showtime', label: 'Show Time · 聚光', accent: '#ff7ac8', bg: ['#2a0a24', '#0a030e'], pattern: 'stage', frame: 'stage' },
  { id: 'epic', label: '史诗 · 星辰', accent: '#b9a4ff', bg: ['#241743', '#0a0716'], pattern: 'rays', frame: 'ornate' },
  { id: 'legend', label: '传奇 · 鎏金', accent: '#e7c879', bg: ['#20180a', '#0a0805'], pattern: 'burst', frame: 'ornate' },
  { id: 'featured', label: '精选 · 青瓷', accent: '#8fe8d1', bg: ['#0d2b2a', '#06100f'], pattern: 'grid', frame: 'clean' },
  { id: 'highlight', label: '高光 · 熔岩', accent: '#ffb27a', bg: ['#321410', '#120604'], pattern: 'rays', frame: 'sport' },
  { id: 'potw', label: 'POTW · 夜色', accent: '#ffd76a', bg: ['#1b1708', '#070603'], pattern: 'burst', frame: 'clean' },
  { id: 'standard', label: '标准 · 玄铁', accent: '#a9bfd6', bg: ['#182430', '#080d12'], pattern: 'grid', frame: 'clean' },
  { id: 'custom', label: '自定义卡面', accent: '#8fd8ff', bg: ['#101a25', '#060a0f'], pattern: 'none', frame: 'clean' },
];

const imageCache = new Map();

export function templateById(id) {
  return CARD_TEMPLATES.find(row => row.id === id) || CARD_TEMPLATES[0];
}

export function loadImage(id) {
  if (!id) return Promise.resolve(null);
  if (imageCache.has(id)) return imageCache.get(id);
  const promise = new Promise(resolve => {
    const image = new Image();
    image.decoding = 'async';
    image.onload = () => resolve(image);
    image.onerror = () => resolve(null);
    image.src = assetUrl(id);
  });
  imageCache.set(id, promise);
  return promise;
}

export function clearImageCache() {
  imageCache.clear();
}

function seeded(seedText) {
  let seed = 2166136261;
  for (let i = 0; i < seedText.length; i++) {
    seed ^= seedText.charCodeAt(i);
    seed = Math.imul(seed, 16777619);
  }
  return () => {
    seed += 0x6D2B79F5;
    let value = seed;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

let noiseTile = null;
function noisePattern(ctx) {
  if (!noiseTile) {
    noiseTile = document.createElement('canvas');
    noiseTile.width = 120;
    noiseTile.height = 120;
    const nctx = noiseTile.getContext('2d');
    const random = seeded('grain-2026');
    const image = nctx.createImageData(120, 120);
    for (let i = 0; i < image.data.length; i += 4) {
      const value = 110 + Math.floor(random() * 90);
      image.data[i] = image.data[i + 1] = image.data[i + 2] = value;
      image.data[i + 3] = Math.floor(random() * 80);
    }
    nctx.putImageData(image, 0, 0);
  }
  return ctx.createPattern(noiseTile, 'repeat');
}

function hexToRgb(hex) {
  const value = hex.replace('#', '');
  const full = value.length === 3 ? value.split('').map(c => c + c).join('') : value;
  return [parseInt(full.slice(0, 2), 16), parseInt(full.slice(2, 4), 16), parseInt(full.slice(4, 6), 16)];
}

export function rgba(hex, alpha) {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${alpha})`;
}

export function lighten(hex, amount = 0.3) {
  const [r, g, b] = hexToRgb(hex);
  const mix = value => Math.round(value + (255 - value) * amount).toString(16).padStart(2, '0');
  return `#${mix(r)}${mix(g)}${mix(b)}`;
}

function rounded(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
}

function starPath(ctx, cx, cy, outer, inner, points = 5) {
  ctx.beginPath();
  for (let i = 0; i < points * 2; i++) {
    const radius = i % 2 === 0 ? outer : inner;
    const angle = -Math.PI / 2 + (i * Math.PI) / points;
    const x = cx + Math.cos(angle) * radius;
    const y = cy + Math.sin(angle) * radius;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  }
  ctx.closePath();
}

function fitFont(ctx, text, maxWidth, size, weight, family) {
  let current = size;
  do {
    ctx.font = `${weight} ${current}px ${family}`;
    if (ctx.measureText(text).width <= maxWidth) break;
    current -= 1;
  } while (current > 8);
  return current;
}

function drawBackground(ctx, theme, player, backgroundImage) {
  const [top, bottom] = theme.bg;
  const gradient = ctx.createLinearGradient(0, 0, CARD_W * .4, CARD_H);
  gradient.addColorStop(0, top);
  gradient.addColorStop(1, bottom);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, CARD_W, CARD_H);

  const custom = Boolean(backgroundImage);

  if (custom) {
    const zoom = clamp(Number(player.card.background_zoom) || 1, .5, 3);
    const scale = Math.max(CARD_W / backgroundImage.width, CARD_H / backgroundImage.height) * zoom;
    const w = backgroundImage.width * scale;
    const h = backgroundImage.height * scale;
    const x = (CARD_W - w) / 2 + (Number(player.card.background_x) || 0);
    const y = (CARD_H - h) / 2 + (Number(player.card.background_y) || 0);
    ctx.drawImage(backgroundImage, x, y, w, h);
    const dim = clamp(Number(player.card.background_dim ?? .35), 0, .85);
    if (dim > 0) {
      ctx.fillStyle = `rgba(3,7,11,${dim})`;
      ctx.fillRect(0, 0, CARD_W, CARD_H);
    }
    const topScrim = ctx.createLinearGradient(0, 0, 0, 230);
    topScrim.addColorStop(0, 'rgba(3,7,11,.62)');
    topScrim.addColorStop(1, 'rgba(3,7,11,0)');
    ctx.fillStyle = topScrim;
    ctx.fillRect(0, 0, CARD_W, 230);
  } else {
    const glow = ctx.createRadialGradient(CARD_W * .5, CARD_H * .26, 20, CARD_W * .5, CARD_H * .32, CARD_W * .72);
    glow.addColorStop(0, rgba(theme.accent, theme.id === 'showtime' ? .42 : .34));
    glow.addColorStop(.45, rgba(theme.accent, .09));
    glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, CARD_W, CARD_H);
  }

  if (!custom) {
    ctx.save();
    ctx.globalAlpha = .5;
    if (theme.pattern === 'shards') {
      const random = seeded(theme.id + '-shards');
      for (let i = 0; i < 14; i++) {
        const x = -180 + random() * (CARD_W + 240);
        const w = 36 + random() * 120;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x + w, 0);
        ctx.lineTo(x + w - 260, CARD_H);
        ctx.lineTo(x - 260, CARD_H);
        ctx.closePath();
        ctx.fillStyle = rgba(i % 3 === 0 ? '#ffffff' : theme.accent, .018 + random() * .045);
        ctx.fill();
      }
      for (let i = 0; i < 22; i++) {
        const x = -120 + i * 38;
        ctx.beginPath();
        ctx.moveTo(x, CARD_H);
        ctx.lineTo(x + 300, -40);
        ctx.strokeStyle = rgba(i % 5 === 0 ? '#ffffff' : theme.accent, i % 5 === 0 ? .1 : .035);
        ctx.lineWidth = i % 5 === 0 ? 1.5 : .7;
        ctx.stroke();
      }
      ctx.fillStyle = rgba(theme.accent, .18);
      ctx.beginPath();
      ctx.moveTo(0, 0); ctx.lineTo(170, 0); ctx.lineTo(0, 150); ctx.closePath(); ctx.fill();
      ctx.beginPath();
      ctx.moveTo(CARD_W, CARD_H); ctx.lineTo(CARD_W - 170, CARD_H); ctx.lineTo(CARD_W, CARD_H - 150); ctx.closePath(); ctx.fill();
    } else if (theme.pattern === 'stage') {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const beams = [
        [CARD_W * .5, -40, CARD_W * .18, 640, .22],
        [CARD_W * .18, -30, CARD_W * .08, 700, .14],
        [CARD_W * .82, -30, CARD_W * .92, 700, .14],
        [CARD_W * .34, -20, CARD_W * .1, 680, .08],
        [CARD_W * .66, -20, CARD_W * .9, 680, .08],
      ];
      for (const [x1, y1, x2, y2, alpha] of beams) {
        const beam = ctx.createLinearGradient(x1, y1, x2, y2);
        beam.addColorStop(0, rgba(theme.accent, alpha));
        beam.addColorStop(.6, rgba(theme.accent, alpha * .32));
        beam.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = beam;
        ctx.beginPath();
        ctx.moveTo(x1 - 34, y1);
        ctx.lineTo(x1 + 34, y1);
        ctx.lineTo(x2 + 150, y2);
        ctx.lineTo(x2 - 150, y2);
        ctx.closePath();
        ctx.fill();
      }
      const stage = ctx.createRadialGradient(CARD_W / 2, 700, 20, CARD_W / 2, 720, 280);
      stage.addColorStop(0, rgba(theme.accent, .22));
      stage.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = stage;
      ctx.beginPath();
      ctx.ellipse(CARD_W / 2, 720, 300, 105, 0, 0, Math.PI * 2);
      ctx.fill();
      const random = seeded('showtime-bokeh');
      for (let i = 0; i < 46; i++) {
        const x = random() * CARD_W, y = random() * CARD_H * .7, r = .6 + random() * 2.2;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fillStyle = rgba(i % 3 === 0 ? '#ffffff' : theme.accent, .04 + random() * .2);
        ctx.fill();
      }
      ctx.restore();
    } else if (theme.pattern === 'rays') {
      ctx.translate(CARD_W / 2, -30);
      for (let i = 0; i < 26; i++) {
        const angle = (i / 26) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(Math.cos(angle) * 780, Math.sin(angle) * 780);
        ctx.strokeStyle = rgba(theme.accent, i % 5 === 0 ? .07 : .025);
        ctx.lineWidth = i % 5 === 0 ? 1.6 : .8;
        ctx.stroke();
      }
    } else if (theme.pattern === 'speed') {
      for (let i = 0; i < 34; i++) {
        const x = -160 + i * 24;
        ctx.beginPath();
        ctx.moveTo(x, CARD_H);
        ctx.lineTo(x + 330, -40);
        ctx.strokeStyle = rgba(i % 4 === 0 ? '#ffffff' : theme.accent, i % 4 === 0 ? .05 : .045);
        ctx.lineWidth = i % 6 === 0 ? 2 : .8;
        ctx.stroke();
      }
    } else if (theme.pattern === 'grid') {
      ctx.strokeStyle = rgba(theme.accent, .055);
      ctx.lineWidth = 1;
      for (let x = 0; x < CARD_W; x += 34) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, CARD_H); ctx.stroke();
      }
      for (let y = 0; y < CARD_H; y += 34) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(CARD_W, y); ctx.stroke();
      }
    } else if (theme.pattern !== 'none') {
      ctx.translate(CARD_W / 2, CARD_H * .3);
      for (let i = 0; i < 48; i++) {
        const angle = (i / 48) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(Math.cos(angle) * 720, Math.sin(angle) * 720);
        ctx.strokeStyle = rgba(theme.accent, i % 3 === 0 ? .075 : .022);
        ctx.lineWidth = i % 3 === 0 ? 1.4 : .7;
        ctx.stroke();
      }
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      const random = seeded(theme.id + '-stars');
      for (let i = 0; i < 60; i++) {
        const x = random() * CARD_W, y = random() * CARD_H * .7, r = random() * 1.6 + .3;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fillStyle = rgba('#ffffff', .05 + random() * .16);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  if (theme.id === 'custom' && !backgroundImage) {
    ctx.save();
    ctx.setLineDash([6, 8]);
    ctx.strokeStyle = rgba(theme.accent, .38);
    ctx.lineWidth = 1;
    rounded(ctx, 46, 120, CARD_W - 92, 190, 14);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(225,238,248,.45)';
    ctx.font = `500 12px ${FONT_UI}`;
    ctx.textAlign = 'center';
    ctx.fillText(tr('上传卡面背景'), CARD_W / 2, 205);
    ctx.fillStyle = 'rgba(190,207,220,.3)';
    ctx.font = `400 9px ${FONT_UI}`;
    ctx.fillText('CUSTOM CARD BACKGROUND', CARD_W / 2, 228);
    ctx.restore();
  }
}

function drawFrame(ctx, theme, player) {
  if (player.card.background_frame === false) return;
  const accent = theme.accent;
  ctx.save();
  const frame = ctx.createLinearGradient(0, 0, CARD_W, CARD_H);
  frame.addColorStop(0, rgba(accent, .95));
  frame.addColorStop(.4, rgba(lighten(accent, .55), .75));
  frame.addColorStop(.7, rgba(accent, .5));
  frame.addColorStop(1, rgba(accent, .9));
  ctx.strokeStyle = frame;
  ctx.lineWidth = 2;
  rounded(ctx, 12, 12, CARD_W - 24, CARD_H - 24, 14);
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,.14)';
  ctx.lineWidth = .8;
  rounded(ctx, 19, 19, CARD_W - 38, CARD_H - 38, 10);
  ctx.stroke();

  const corner = (x, y, sx, sy, size) => {
    ctx.beginPath();
    ctx.moveTo(x + sx * size, y);
    ctx.lineTo(x, y);
    ctx.lineTo(x, y + sy * size);
    ctx.strokeStyle = rgba(accent, .9);
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(x + sx * 5, y + sy * 5, 1.7, 0, Math.PI * 2);
    ctx.fillStyle = rgba('#ffffff', .65);
    ctx.fill();
  };
  corner(26, 26, 1, 1, 22);
  corner(CARD_W - 26, 26, -1, 1, 22);
  corner(26, CARD_H - 26, 1, -1, 22);
  corner(CARD_W - 26, CARD_H - 26, -1, -1, 22);

  if (theme.frame === 'ornate') {
    ctx.strokeStyle = rgba(accent, .38);
    ctx.lineWidth = 1;
    rounded(ctx, 28, 28, CARD_W - 56, CARD_H - 56, 8);
    ctx.stroke();
    for (const side of [0, 1]) {
      const y = side ? CARD_H - 44 : 44;
      ctx.beginPath();
      ctx.moveTo(CARD_W / 2 - 60, y);
      ctx.lineTo(CARD_W / 2, y + (side ? -6 : 6));
      ctx.lineTo(CARD_W / 2 + 60, y);
      ctx.strokeStyle = rgba(accent, .55);
      ctx.stroke();
    }
  } else if (theme.frame === 'sport') {
    ctx.fillStyle = rgba(accent, .75);
    ctx.beginPath();
    ctx.moveTo(30, 30); ctx.lineTo(90, 30); ctx.lineTo(30, 90); ctx.closePath(); ctx.fill();
  } else if (theme.frame === 'stage') {
    ctx.strokeStyle = rgba(accent, .4);
    ctx.lineWidth = 1;
    rounded(ctx, 29, 29, CARD_W - 58, CARD_H - 58, 10);
    ctx.stroke();
    for (const y of [34, CARD_H - 24]) {
      for (const offset of [-104, 104]) {
        starPath(ctx, CARD_W / 2 + offset, y, 3.2, 1.3);
        ctx.fillStyle = rgba('#ffffff', .75);
        ctx.fill();
      }
    }
  }
  ctx.restore();
}

function drawSilhouette(ctx, theme, y = 700) {
  ctx.save();
  ctx.fillStyle = rgba(theme.accent, .13);
  ctx.beginPath();
  ctx.arc(CARD_W / 2, 310, 74, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(CARD_W / 2 - 138, y);
  ctx.quadraticCurveTo(CARD_W / 2 - 124, 430, CARD_W / 2 - 62, 392);
  ctx.quadraticCurveTo(CARD_W / 2 - 18, 364, CARD_W / 2, 364);
  ctx.quadraticCurveTo(CARD_W / 2 + 18, 364, CARD_W / 2 + 62, 392);
  ctx.quadraticCurveTo(CARD_W / 2 + 124, 430, CARD_W / 2 + 138, y);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  ctx.save();
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(230,240,248,.4)';
  ctx.font = `500 11px ${FONT_UI}`;
  ctx.fillText(tr('导入球员照片'), CARD_W / 2, 560);
  ctx.fillStyle = 'rgba(190,205,218,.26)';
  ctx.font = `400 8.5px ${FONT_UI}`;
  ctx.fillText(tr('透明 PNG 或纯色背景照片'), CARD_W / 2, 578);
  ctx.restore();
}

function drawPortrait(ctx, theme, image, out, player) {
  if (!image) {
    drawSilhouette(ctx, theme, out.bottom + 20);
    return;
  }
  const photo = player.card.photo || { zoom: 1, x: 0, y: 0, rotate: 0 };
  const zoom = clamp(Number(photo.zoom) || 1, .2, 6);
  const maxH = out.height;
  const maxW = CARD_W + 80;
  let scale = Math.min(maxH / image.height, maxW / image.width) * zoom;
  let w = image.width * scale;
  let h = image.height * scale;
  let x = (CARD_W - w) / 2 + (Number(photo.x) || 0) * 2;
  let y = out.bottom - h + (Number(photo.y) || 0) * 2;

  // 地面阴影，让透明人物看起来站在卡面上。
  const shadow = ctx.createRadialGradient(CARD_W / 2 + (Number(photo.x) || 0) * 1.4, out.bottom + 2, 6, CARD_W / 2, out.bottom + 8, Math.min(230, w * .48));
  shadow.addColorStop(0, 'rgba(0,0,0,.55)');
  shadow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.save();
  ctx.fillStyle = shadow;
  ctx.beginPath();
  ctx.ellipse(CARD_W / 2, out.bottom + 6, Math.min(220, w * .46), 26, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 0, CARD_W, CARD_H);
  ctx.clip();
  if (image.width && image.height) {
    ctx.translate(x + w / 2, y + h / 2);
    ctx.rotate(((Number(photo.rotate) || 0) * Math.PI) / 180);
    ctx.shadowColor = rgba(theme.accent, .32);
    ctx.shadowBlur = 22;
    ctx.drawImage(image, -w / 2, -h / 2, w, h);
    ctx.shadowBlur = 0;
    ctx.drawImage(image, -w / 2, -h / 2, w, h);
  }
  ctx.restore();
}

function drawLeftScrim(ctx) {
  const scrim = ctx.createLinearGradient(0, 0, 330, 0);
  scrim.addColorStop(0, 'rgba(5,9,14,.72)');
  scrim.addColorStop(.55, 'rgba(5,9,14,.3)');
  scrim.addColorStop(1, 'rgba(5,9,14,0)');
  ctx.fillStyle = scrim;
  ctx.fillRect(0, 0, 340, 700);
}

function drawBottomScrim(ctx) {
  const scrim = ctx.createLinearGradient(0, 470, 0, 760);
  scrim.addColorStop(0, 'rgba(5,9,14,0)');
  scrim.addColorStop(.52, 'rgba(5,9,14,.72)');
  scrim.addColorStop(1, 'rgba(5,9,14,.97)');
  ctx.fillStyle = scrim;
  ctx.fillRect(0, 450, CARD_W, 330);
}

function formatCardDate(value) {
  const match = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return '';
  const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const month = months[Number(match[2]) - 1];
  if (!month) return '';
  return `${Number(match[3])} ${month} '${match[1].slice(-2)}`;
}

function drawHeader(ctx, theme, player, sim) {
  ctx.save();
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';

  const typeLabel = cardTypeBadge(player.card.type);
  ctx.font = `600 10px ${FONT_EN}`;
  ctx.letterSpacing = '2px';
  const width = ctx.measureText(typeLabel).width + 26;
  rounded(ctx, 34, 58, width, 24, 5);
  ctx.fillStyle = rgba(theme.accent, .16);
  ctx.fill();
  ctx.strokeStyle = rgba(theme.accent, .6);
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = lighten(theme.accent, .5);
  ctx.fillText(typeLabel, 47, 74);
  ctx.letterSpacing = '0px';

  ctx.textAlign = 'right';
  ctx.font = `500 9px ${FONT_EN}`;
  ctx.fillStyle = 'rgba(230,240,250,.75)';
  ctx.letterSpacing = '1.6px';
  const serial = player.card.show?.serial === false ? '' : 'NO. ' + String(player.card.serial || 1).padStart(4, '0');
  ctx.fillText(serial, CARD_W - 34, 42);
  if (player.card.date) {
    ctx.fillStyle = 'rgba(200,215,228,.55)';
    ctx.font = `400 8.5px ${FONT_EN}`;
    ctx.fillText(formatCardDate(player.card.date) || player.card.date, CARD_W - 34, 56);
  }
  ctx.textAlign = 'center';
  ctx.fillStyle = rgba(theme.accent, .7);
  ctx.font = `500 8.5px ${FONT_EN}`;
  ctx.letterSpacing = '3px';
  ctx.fillText((player.card.title || 'PERSONAL EDITION').toUpperCase().slice(0, 34), CARD_W / 2, 48);
  ctx.letterSpacing = '0px';

  // OVR
  const ovr = String(sim.overall);
  const ovrGradient = ctx.createLinearGradient(34, 100, 34, 210);
  ovrGradient.addColorStop(0, '#ffffff');
  ovrGradient.addColorStop(.55, lighten(theme.accent, .55));
  ovrGradient.addColorStop(1, theme.accent);
  ctx.textAlign = 'left';
  ctx.fillStyle = ovrGradient;
  ctx.font = `700 92px ${FONT_NUM}`;
  ctx.fillText(ovr, 32, 186);
  ctx.font = `600 9px ${FONT_EN}`;
  ctx.letterSpacing = '3px';
  ctx.fillStyle = 'rgba(230,240,250,.55)';
  ctx.fillText('OVERALL', 38, 202);
  ctx.letterSpacing = '0px';

  const posZh = (player.identity.position || 'CF');
  rounded(ctx, 34, 214, 64, 26, 6);
  ctx.fillStyle = rgba(theme.accent, .18);
  ctx.fill();
  ctx.strokeStyle = rgba(theme.accent, .55);
  ctx.stroke();
  ctx.fillStyle = '#f4fbff';
  ctx.font = `600 14px ${FONT_EN}`;
  ctx.textAlign = 'center';
  ctx.fillText(posZh, 66, 232);

  if (player.card.show?.stars !== false) {
    const stars = clamp(Number(player.card.rarity) || 5, 1, 5);
    for (let i = 0; i < 5; i++) {
      starPath(ctx, 40 + i * 15, 258, 5.4, 2.3);
      ctx.fillStyle = i < stars ? rgba(theme.accent, .95) : 'rgba(255,255,255,.16)';
      ctx.fill();
    }
  }
  ctx.restore();
}

function drawName(ctx, theme, player) {
  const identity = player.identity;
  const display = (player.card.display_name || identity.name || tr('未命名球员')).trim() || tr('未命名球员');
  ctx.save();
  ctx.textAlign = 'left';

  if (player.card.show?.number !== false) {
    ctx.save();
    ctx.textAlign = 'right';
    ctx.font = `700 185px ${FONT_NUM}`;
    ctx.fillStyle = rgba(theme.accent, .06);
    ctx.fillText(String(identity.number ?? 10), CARD_W - 26, 700);
    ctx.restore();
  }

  ctx.strokeStyle = rgba(theme.accent, .55);
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(34, 626);
  ctx.lineTo(CARD_W - 34, 626);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(34, 626);
  ctx.lineTo(120, 626);
  ctx.strokeStyle = rgba(theme.accent, .95);
  ctx.lineWidth = 2;
  ctx.stroke();

  const size = fitFont(ctx, display, 420, 40, 700, FONT_UI);
  ctx.font = `700 ${size}px ${FONT_UI}`;
  ctx.fillStyle = '#ffffff';
  ctx.shadowColor = 'rgba(0,0,0,.45)';
  ctx.shadowBlur = 14;
  ctx.fillText(display, 34, 674);
  ctx.shadowBlur = 0;

  const shirt = (identity.shirt_name || '').trim();
  if (shirt && shirt !== display) {
    ctx.font = `500 10px ${FONT_EN}`;
    ctx.letterSpacing = '2px';
    ctx.fillStyle = rgba(theme.accent, .8);
    ctx.fillText(shirt.toUpperCase(), 35, 692);
    ctx.letterSpacing = '0px';
  }
  ctx.restore();
}

function drawPills(ctx, theme, player, catalog) {
  const identity = player.identity;
  const y = 704;
  let x = 34;
  const items = [];
  if (player.card.show?.badges !== false) {
    const nation = nationDisplay(catalog, identity) || identity.nation;
    const team = teamDisplay(catalog, identity) || identity.team;
    if (nation) items.push(String(nation).slice(0, 14));
    if (team) items.push(String(team).slice(0, 18));
    items.push(footLabel(identity.foot || '右脚'));
  }
  ctx.save();
  ctx.font = `400 9px ${FONT_UI}`;
  for (const text of items) {
    const width = ctx.measureText(text).width + 16;
    if (x + width > CARD_W - 34) break;
    rounded(ctx, x, y, width, 19, 9.5);
    ctx.fillStyle = 'rgba(7,12,18,.55)';
    ctx.fill();
    ctx.strokeStyle = rgba(theme.accent, .3);
    ctx.lineWidth = .8;
    ctx.stroke();
    ctx.fillStyle = 'rgba(225,236,245,.78)';
    ctx.fillText(text, x + 8, y + 13);
    x += width + 6;
  }
  ctx.restore();
}

function drawSkills(ctx, theme, player, catalog) {
  if (player.card.show?.skills === false) return;
  const skills = [...(player.skills?.innate || []), ...(player.skills?.additional || [])]
    .map(id => {
      const row = catalog.skills.find(item => item.id === Number(id));
      return row ? skillLabel(row) : '';
    })
    .filter(Boolean)
    .slice(0, 2);
  if (!skills.length) return;
  const y = 664;
  let right = CARD_W - 34;
  ctx.save();
  ctx.textAlign = 'right';
  for (const skill of skills.reverse()) {
    const text = skill.length > 7 ? skill.slice(0, 7) : skill;
    ctx.font = `400 9px ${FONT_UI}`;
    const width = ctx.measureText(text).width + 18;
    rounded(ctx, right - width, y, width, 20, 4);
    ctx.fillStyle = rgba(theme.accent, .14);
    ctx.fill();
    ctx.strokeStyle = rgba(theme.accent, .35);
    ctx.lineWidth = .8;
    ctx.stroke();
    ctx.fillStyle = 'rgba(235,245,252,.86)';
    ctx.fillText(text, right - 9, y + 14);
    right -= width + 5;
  }
  ctx.restore();
}

function drawStats(ctx, theme, player, sim, catalog) {
  if (player.card.show?.stats === false) return;
  const y = 736;
  const h = 58;
  ctx.save();
  const panel = ctx.createLinearGradient(0, y, 0, y + h);
  panel.addColorStop(0, 'rgba(8,13,19,.86)');
  panel.addColorStop(1, 'rgba(8,13,19,.62)');
  ctx.fillStyle = panel;
  ctx.fillRect(28, y, CARD_W - 56, h);
  ctx.strokeStyle = rgba(theme.accent, .22);
  ctx.lineWidth = .8;
  ctx.strokeRect(28, y, CARD_W - 56, h);

  const cell = (CARD_W - 56) / 6;
  catalog.six_stats.forEach((group, i) => {
    const value = sim.six[group.key];
    const cx = 28 + cell * i + cell / 2;
    if (i) {
      ctx.beginPath();
      ctx.moveTo(28 + cell * i, y + 10);
      ctx.lineTo(28 + cell * i, y + h - 10);
      ctx.strokeStyle = 'rgba(255,255,255,.08)';
      ctx.stroke();
    }
    ctx.textAlign = 'center';
    ctx.font = `500 8px ${FONT_UI}`;
    ctx.fillStyle = 'rgba(210,224,235,.6)';
    ctx.fillText(sixLabel(group), cx, y + 18);
    ctx.font = `600 23px ${FONT_NUM}`;
    ctx.fillStyle = ratingColor(value);
    ctx.fillText(String(value), cx, y + 45);
    ctx.font = `400 7px ${FONT_EN}`;
    ctx.fillStyle = 'rgba(170,190,206,.45)';
    ctx.letterSpacing = '1.4px';
    ctx.fillText(group.en, cx, y + 55);
    ctx.letterSpacing = '0px';
  });
  ctx.restore();
}

function drawFooter(ctx, theme, player) {
  const identity = player.identity;
  ctx.save();
  ctx.textAlign = 'left';
  ctx.font = `400 8.5px ${FONT_UI}`;
  ctx.fillStyle = 'rgba(196,212,225,.55)';
  ctx.fillText(`${identity.height_cm || 180} cm   ·   ${identity.weight_kg || 75} kg   ·   ${identity.age || 22} ${tr('岁')}`, 34, 820);
  ctx.textAlign = 'right';
  ctx.fillStyle = rgba(theme.accent, .8);
  ctx.font = `500 8.5px ${FONT_NUM}`;
  ctx.fillText(`Lv.${player.level?.initial || 1} / ${player.level?.max || 35}`, CARD_W - 34, 820);
  ctx.restore();
}

function drawEffects(ctx, theme) {
  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  const foil = ctx.createLinearGradient(0, CARD_H, CARD_W, 0);
  foil.addColorStop(.34, 'rgba(255,255,255,0)');
  foil.addColorStop(.44, rgba(theme.accent, .18));
  foil.addColorStop(.5, 'rgba(255,255,255,.18)');
  foil.addColorStop(.56, rgba(theme.accent, .1));
  foil.addColorStop(.66, 'rgba(255,255,255,0)');
  ctx.fillStyle = foil;
  ctx.fillRect(0, 0, CARD_W, CARD_H);
  ctx.restore();

  const vignette = ctx.createRadialGradient(CARD_W / 2, CARD_H * .42, CARD_W * .3, CARD_W / 2, CARD_H * .5, CARD_W * .78);
  vignette.addColorStop(0, 'rgba(0,0,0,0)');
  vignette.addColorStop(1, 'rgba(0,0,0,.42)');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, CARD_W, CARD_H);

  ctx.save();
  ctx.globalAlpha = .16;
  ctx.fillStyle = noisePattern(ctx);
  ctx.fillRect(0, 0, CARD_W, CARD_H);
  ctx.restore();
}

export function resolvePortrait(player) {
  const card = player.card || {};
  if (card.use_cutout && card.cutout_asset) return card.cutout_asset;
  return card.portrait || null;
}

export async function drawCard(canvas, player, sim, catalog) {
  const theme = { ...templateById(player.card.template), accent: player.card.accent || templateById(player.card.template).accent };
  const backgroundImage = player.card.background_style === 'image' ? await loadImage(player.card.background_image) : null;
  const portrait = await loadImage(resolvePortrait(player));
  const ctx = canvas.getContext('2d');
  const scale = canvas.width / CARD_W;
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  ctx.clearRect(0, 0, CARD_W, CARD_H);
  drawBackground(ctx, theme, player, backgroundImage);
  ctx.save();
  ctx.strokeStyle = rgba(theme.accent, .18);
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(CARD_W / 2, 330, 214, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = rgba(theme.accent, .07);
  ctx.beginPath();
  ctx.arc(CARD_W / 2, 330, 238, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
  drawPortrait(ctx, theme, portrait, { bottom: 654, height: 594 }, player);
  drawLeftScrim(ctx);
  drawBottomScrim(ctx);
  drawFrame(ctx, theme, player);
  drawHeader(ctx, theme, player, sim);
  drawSkills(ctx, theme, player, catalog);
  drawName(ctx, theme, player);
  drawPills(ctx, theme, player, catalog);
  drawStats(ctx, theme, player, sim, catalog);
  drawFooter(ctx, theme, player);
  drawEffects(ctx, theme);
  return { hasPortrait: Boolean(portrait), theme };
}

export function cardCanvas(player, sim, catalog, width = 1200) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = Math.round((width / CARD_W) * CARD_H);
  return drawCard(canvas, player, sim, catalog).then(() => canvas);
}

export async function drawAvatar(canvas, player, sim, catalog) {
  const theme = { ...templateById(player.card.template), accent: player.card.accent || templateById(player.card.template).accent };
  const portrait = await loadImage(resolvePortrait(player));
  const size = 512;
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  const s = size / 512;
  ctx.setTransform(s, 0, 0, s, 0, 0);
  ctx.clearRect(0, 0, 512, 512);

  const gradient = ctx.createRadialGradient(256, 170, 20, 256, 220, 380);
  gradient.addColorStop(0, rgba(theme.accent, .5));
  gradient.addColorStop(.5, theme.bg[0]);
  gradient.addColorStop(1, theme.bg[1]);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 512, 512);

  ctx.save();
  rounded(ctx, 18, 18, 476, 476, 92);
  ctx.clip();
  if (portrait) {
    const tall = portrait.height > portrait.width * 1.15;
    const sourceX = tall ? portrait.width * 0.18 : 0;
    const sourceY = tall ? portrait.height * 0.02 : 0;
    const sourceW = tall ? portrait.width * 0.64 : portrait.width;
    const sourceH = tall ? portrait.height * 0.46 : portrait.height;
    const scale = Math.max(512 / sourceW, 512 / sourceH) * 1.04;
    const w = sourceW * scale;
    const h = sourceH * scale;
    ctx.drawImage(portrait, sourceX, sourceY, sourceW, sourceH, (512 - w) / 2, 512 - h + 16, w, h);
  } else {
    ctx.fillStyle = rgba(theme.accent, .16);
    ctx.beginPath(); ctx.arc(256, 210, 82, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(96, 512); ctx.quadraticCurveTo(120, 320, 256, 312);
    ctx.quadraticCurveTo(392, 320, 416, 512); ctx.closePath(); ctx.fill();
  }
  const shade = ctx.createLinearGradient(0, 250, 0, 512);
  shade.addColorStop(0, 'rgba(5,9,14,0)');
  shade.addColorStop(1, 'rgba(5,9,14,.9)');
  ctx.fillStyle = shade;
  ctx.fillRect(0, 0, 512, 512);
  ctx.restore();

  ctx.strokeStyle = rgba(theme.accent, .9);
  ctx.lineWidth = 5;
  rounded(ctx, 18, 18, 476, 476, 92);
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,.16)';
  ctx.lineWidth = 1.5;
  rounded(ctx, 30, 30, 452, 452, 80);
  ctx.stroke();

  ctx.fillStyle = '#fff';
  ctx.textAlign = 'left';
  const name = (player.identity.name || tr('球员')).slice(0, 10);
  fitFont(ctx, name, 330, 34, 700, FONT_UI);
  ctx.fillText(name, 46, 440);
  ctx.font = `500 13px ${FONT_EN}`;
  ctx.fillStyle = rgba(theme.accent, .9);
  ctx.letterSpacing = '2px';
  ctx.fillText(`${player.identity.position || 'CF'} · ${cardTypeBadge(player.card.type)}`, 47, 463);
  ctx.letterSpacing = '0px';

  rounded(ctx, 360, 372, 108, 60, 14);
  ctx.fillStyle = 'rgba(5,9,14,.72)';
  ctx.fill();
  ctx.strokeStyle = rgba(theme.accent, .55);
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.textAlign = 'center';
  ctx.fillStyle = ratingColor(sim.overall);
  ctx.font = `700 40px ${FONT_NUM}`;
  ctx.fillText(String(sim.overall), 414, 415);
  ctx.font = `500 8px ${FONT_EN}`;
  ctx.fillStyle = 'rgba(220,235,245,.6)';
  ctx.fillText('OVR', 414, 427);
  return { hasPortrait: Boolean(portrait) };
}

export async function avatarCanvas(player, sim, catalog, size = 512) {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  await drawAvatar(canvas, player, sim, catalog);
  return canvas;
}
