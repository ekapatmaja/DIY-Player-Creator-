/* 数据模型、总评回归与培养模拟。与服务器、界面无关，可单独测试。 */

export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
export const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
export const round = value => Math.round(value * 100) / 100;
export const fmt = value => Number(value || 0).toLocaleString('zh-CN');
export const clone = value => structuredClone(value);

export function trainingCost(count) {
  const q = Math.floor(count / 4), r = count % 4;
  return 2 * q * (q + 1) + r * (q + 1);
}

export function ratingColor(value) {
  return value >= 95 ? '#7fe3bf' : value >= 85 ? '#7fd4ff' : value >= 75 ? '#e7c879' : '#9fb2c4';
}

export function newPlayer(catalog, options = {}) {
  const card = catalog.card_types.find(row => row.id === (options.card_type || 'Epic')) || catalog.card_types[0];
  const position = options.position || 'CF';
  const abilities = {};
  for (const row of catalog.abilities) abilities[String(row.index)] = 65;
  const training = {};
  for (const group of catalog.training_groups) training[group.id] = 0;
  const nation = catalog.nations.find(row => row.id === 7) || catalog.nations[0] || { id: null, zh: '' };
  const now = new Date().toISOString();
  return {
    format: 'player-maker/player',
    version: 1,
    id: crypto.randomUUID(),
    created_at: now,
    updated_at: now,
    identity: {
      name: options.name || '新球员', shirt_name: '', age: 22, height_cm: 180, weight_kg: 75,
      foot: '右脚', number: 10, position,
      nation_id: nation.id, nation: nation.zh, team_id: null, team: options.team || 'MY CLUB',
    },
    card: {
      type: card.id, series: card.id === 'BigTime' ? 'BIG TIME' : card.id === 'ShowTime' ? 'SHOW TIME' : card.id === 'Trending' ? 'POTW' : card.en.toUpperCase(),
      title: 'PERSONAL EDITION', serial: 1, rarity: 5, date: '', template: card.theme,
      accent: card.accent, secondary: '#f3e6c4', background_style: 'theme', background_image: null,
      background_dim: .4, background_zoom: 1, background_x: 0, background_y: 0, background_frame: true,
      portrait: null, cutout_asset: null, cutout_tolerance: 34, use_cutout: true,
      photo: { zoom: 1, x: 0, y: 0, rotate: 0 },
      show: { stats: true, skills: true, serial: true, badges: true, stars: true, number: true },
      display_name: '',
    },
    abilities,
    position_aptitudes: Object.fromEntries(catalog.positions.map(row => [row.code, row.code === position ? 2 : 0])),
    play_style: { attack: 1, defense: 0 },
    traits: { weak_foot_usage: '普通', weak_foot_accuracy: '普通', form: '稳定', injury: '普通' },
    condition: 'auto',
    level: { initial: 1, max: 35 },
    training,
    boosters: [0, 0],
    conditional_boosters: false,
    skills: { innate: [], additional: [] },
    ai_styles: [],
    model: { asset: null, name: '', format: '', transform: { scale: 1, rotate: 0, lift: 0 }, capture: null, stats: null },
    notes: '',
  };
}

export function normalizePlayer(raw, catalog) {
  const base = newPlayer(catalog);
  const player = { ...base, ...(raw || {}) };
  player.identity = { ...base.identity, ...(raw?.identity || {}) };
  player.card = { ...base.card, ...(raw?.card || {}) };
  player.card.photo = { ...base.card.photo, ...(raw?.card?.photo || {}) };
  player.card.show = { ...base.card.show, ...(raw?.card?.show || {}) };
  player.level = { ...base.level, ...(raw?.level || {}) };
  player.traits = { ...base.traits, ...(raw?.traits || {}) };
  player.play_style = { ...base.play_style, ...(raw?.play_style || {}) };
  player.skills = { innate: [], additional: [], ...(raw?.skills || {}) };
  player.model = { ...base.model, ...(raw?.model || {}) };
  player.model.transform = { ...base.model.transform, ...(raw?.model?.transform || {}) };
  player.abilities = { ...base.abilities, ...(raw?.abilities || {}) };
  player.training = { ...base.training, ...(raw?.training || {}) };
  player.position_aptitudes = { ...base.position_aptitudes, ...(raw?.position_aptitudes || {}) };
  player.boosters = Array.isArray(raw?.boosters) ? [raw.boosters[0] || 0, raw.boosters[1] || 0] : [0, 0];
  player.ai_styles = Array.isArray(raw?.ai_styles) ? raw.ai_styles : [];
  return player;
}

export function abilityRows(catalog) {
  return [...catalog.abilities].sort((a, b) => a.order - b.order);
}

export function byIndex(catalog) {
  return Object.fromEntries(catalog.abilities.map(row => [row.index, row]));
}

export function positionName(catalog, code) {
  return catalog.positions.find(row => row.code === code)?.zh || code;
}

export function cardType(catalog, id) {
  return catalog.card_types.find(row => row.id === id) || catalog.card_types[0];
}

export function overall(stats, position, catalog) {
  const model = catalog.ovr_weights[position];
  if (!model) return 0;
  let value = model.intercept;
  const rows = abilityRows(catalog);
  rows.forEach((row, i) => {
    value += (model.weights[i] || 0) * Number(stats[String(row.index)] || 0);
  });
  const floor = Math.floor(value);
  const rounded = value - floor === 0.5 ? (floor % 2 === 0 ? floor : floor + 1) : Math.round(value);
  return Math.max(1, Math.min(127, rounded));
}

export function sixStats(stats, catalog) {
  return Object.fromEntries(catalog.six_stats.map(group => {
    const values = group.indices.map(index => Number(stats[String(index)] || 0));
    return [group.key, Math.round(values.reduce((sum, value) => sum + value, 0) / values.length)];
  }));
}

export function simulate(player, catalog) {
  const base = {};
  for (const row of catalog.abilities) base[String(row.index)] = Number(player.abilities[String(row.index)] ?? 65);
  const trained = { ...base };
  const card = cardType(catalog, player.card.type);
  const budget = card.id === 'Trending' ? 0 : 2 * (Math.max(1, Number(player.level.initial || 1)) - 1);
  let spent = 0;
  for (const group of catalog.training_groups) {
    const count = Math.max(0, Math.min(40, Number(player.training[group.id] || 0)));
    spent += trainingCost(count);
    for (const index of group.indices) trained[String(index)] = Math.min(105, trained[String(index)] + count);
  }
  const boosted = { ...trained };
  const boosterDetails = [];
  const boosterMap = new Map(catalog.boosters.map(row => [row.id, row]));
  for (const id of player.boosters || []) {
    const booster = boosterMap.get(id);
    if (!booster) continue;
    if (booster.conditional && !player.conditional_boosters) { boosterDetails.push({ ...booster, skipped: true }); continue; }
    for (const [index, delta] of Object.entries(booster.effects)) {
      boosted[String(index)] = Math.max(1, Math.min(127, boosted[String(index)] + delta));
    }
    boosterDetails.push({ ...booster, skipped: false });
  }
  const final = boosted;
  const position = player.identity.position;
  const byPosition = Object.fromEntries(catalog.positions.map(row => [row.code, overall(final, row.code, catalog)]));
  return {
    base, trained, boosted, final, budget, spent, remaining: budget - spent, valid: spent <= budget,
    overall: overall(final, position, catalog),
    baseOverall: overall(base, position, catalog),
    trainedOverall: overall(trained, position, catalog),
    boostedOverall: overall(boosted, position, catalog),
    byPosition,
    six: sixStats(final, catalog),
    baseSix: sixStats(base, catalog),
    boosters: boosterDetails,
  };
}

export function autoAllocate(player, catalog, target = null) {
  const work = clone(player);
  for (const group of catalog.training_groups) work.training[group.id] = 0;
  const position = target || player.identity.position;
  const weights = catalog.auto_position_weights[position] || catalog.auto_position_weights[player.identity.position] || [];
  let current = simulate(work, catalog);
  let guard = 0;
  while (current.remaining > 0 && guard++ < 600) {
    let best = null;
    catalog.training_groups.forEach((group, index) => {
      const count = work.training[group.id];
      if (count >= 40) return;
      const cost = trainingCost(count + 1) - trainingCost(count);
      if (cost > current.remaining) return;
      const available = group.indices.filter(stat => current.trained[String(stat)] < 105).length / group.indices.length;
      const score = (weights[index] || 0) * available / ((count + 1) * cost);
      if (score > 0 && (!best || score > best.score)) best = { group, score };
    });
    if (!best) break;
    work.training[best.group.id] += 1;
    current = simulate(work, catalog);
  }
  return work.training;
}

/** 在真实培养预算内，用分组背包求该位置总评最高的加点方案。 */
export function optimalTraining(player, catalog, target = null) {
  const position = target || player.identity.position;
  const model = catalog.ovr_weights[position];
  if (!model) return autoAllocate(player, catalog, target);
  const rows = abilityRows(catalog);
  const weights = Object.fromEntries(rows.map((row, i) => [String(row.index), model.weights[i] || 0]));
  const budget = player.card.type === 'Trending' ? 0 : 2 * (Math.max(1, Number(player.level.initial || 1)) - 1);
  const boost = {};
  const map = new Map(catalog.boosters.map(row => [row.id, row]));
  for (const id of player.boosters || []) {
    const booster = map.get(id);
    if (!booster || (booster.conditional && !player.conditional_boosters)) continue;
    for (const [index, delta] of Object.entries(booster.effects)) boost[index] = (boost[index] || 0) + delta;
  }
  let states = new Map([[0, { value: 0, plan: {} }]]);
  for (const group of catalog.training_groups) {
    const choices = [];
    for (let count = 0; count <= 40; count++) {
      const spent = trainingCost(count);
      if (spent > budget) break;
      let gain = 0;
      for (const index of group.indices) {
        const key = String(index);
        const baseValue = Math.max(1, Math.min(127, Number(player.abilities[key] ?? 65) + (boost[key] || 0)));
        const trained = Math.max(1, Math.min(127, Math.min(105, Number(player.abilities[key] ?? 65) + count) + (boost[key] || 0)));
        gain += (weights[key] || 0) * (trained - baseValue);
      }
      choices.push([spent, count, gain]);
    }
    const next = new Map();
    for (const [used, state] of states) {
      for (const [spent, count, gain] of choices) {
        const total = used + spent;
        if (total > budget) continue;
        const candidate = state.value + gain;
        const existing = next.get(total);
        if (!existing || candidate > existing.value + 1e-9) {
          next.set(total, { value: candidate, plan: { ...state.plan, [group.id]: count } });
        }
      }
    }
    states = next;
  }
  let best = null;
  for (const [used, state] of states) {
    if (!best || state.value > best.value + 1e-9 || (Math.abs(state.value - best.value) <= 1e-9 && used < best.used)) {
      best = { ...state, used };
    }
  }
  const plan = Object.fromEntries(catalog.training_groups.map(group => [group.id, best?.plan[group.id] || 0]));
  return plan;
}

export function boosterText(booster, catalog) {
  const rows = byIndex(catalog);
  const entries = Object.entries(booster.effects || {});
  if (!entries.length) return '无常驻效果';
  if (entries.length >= 26) return '全部能力 ' + (entries[0][1] >= 0 ? '+' : '') + entries[0][1];
  return entries.map(([index, delta]) => `${rows[index]?.zh || index}${delta >= 0 ? '+' : ''}${delta}`).join(' · ');
}

export function skillById(catalog, id) {
  return catalog.skills.find(row => row.id === Number(id));
}

export function cardSeriesLabel(player) {
  return (player.card.series || player.card.type || '').toString();
}

export function summarize(player, catalog) {
  const sim = simulate(player, catalog);
  return {
    overall: sim.overall,
    position: player.identity.position,
    name: player.identity.name || '未命名球员',
    card_type: player.card.type,
    level: player.level.initial,
    max: player.level.max,
    six: sim.six,
  };
}

export function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function fileStem(value, fallback = '球员') {
  const text = String(value || '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, ' ').trim();
  return (text || fallback).slice(0, 60);
}
