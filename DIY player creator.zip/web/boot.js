/* 启动守卫：模块加载失败、从文件直接打开或会话缺失时给出可读提示。 */
(function () {
  var params = new URLSearchParams(location.search);
  var token = params.get('token') || '';
  var en = true;
  try { en = (localStorage.getItem('maker.lang') || 'en') !== 'zh'; } catch (e) { /* ignore */ }
  var pick = function (zh, text) { return en ? text : zh; };
  window.__MAKER_TOKEN__ = token;
  window.__makerBooted = false;
  if (location.protocol === 'file:') {
    document.documentElement.innerHTML = '<body style="margin:0;background:#080d13;color:#e9eff7;font-family:Microsoft YaHei,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh"><div style="max-width:560px;padding:32px;border:1px solid #2c3f50;border-radius:14px;background:#0e1721;line-height:2"><h2 style="margin:0 0 10px;font-size:20px">' +
      pick('请从制作器启动', 'Start from the studio') + '</h2><p style="margin:0;color:#91a6b8;font-size:13px">' +
      pick('直接双击网页文件无法加载本地服务。请回到制作器文件夹，双击“启动制作器.cmd”或“球员工坊-制作器.exe”。', 'Opening the HTML file directly cannot load the local service. Go back to the studio folder and double-click “启动制作器.cmd” or “球员工坊-制作器.exe”.') +
      '</p></div></body>';
    return;
  }
  if (!token) {
    document.documentElement.innerHTML = '<body style="margin:0;background:#080d13;color:#e9eff7;font-family:Microsoft YaHei,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh"><div style="max-width:560px;padding:32px;border:1px solid #2c3f50;border-radius:14px;background:#0e1721;line-height:2"><h2 style="margin:0 0 10px;font-size:20px">' +
      pick('本地会话已失效', 'Local session expired') + '</h2><p style="margin:0;color:#91a6b8;font-size:13px">' +
      pick('请关闭这个页面，重新双击制作器启动。制作器会生成新的本地地址。', 'Close this page and start the studio again. A new local address will be created.') +
      '</p></div></body>';
    return;
  }
  setTimeout(function () {
    if (window.__makerBooted) return;
    var content = document.getElementById('editor-content');
    if (!content) return;
    content.innerHTML = '<div class="empty-state"><strong>' + pick('页面没有正常启动', 'The interface did not start') + '</strong>' +
      pick('本地服务仍在运行，但界面脚本未能加载。<br>请确认使用的是 Edge 或 Chrome，然后关闭窗口重新启动制作器。<br><button class="button secondary" onclick="location.reload()">重新加载</button>', 'The local service is running, but the interface script could not load.<br>Use Edge or Chrome, then close and restart the studio.<br><button class="button secondary" onclick="location.reload()">Reload</button>') +
      '</div>';
  }, 6000);
})();
