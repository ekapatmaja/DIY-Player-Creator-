/* 简易抠图：从照片边缘泛洪去掉纯色背景，保留人物边缘的半透明过渡。
   不依赖任何外部服务，结果作为新的 PNG 素材保存。 */

import { loadImage } from './card.js';

function colorDistance(data, offset, color) {
  const dr = data[offset] - color[0];
  const dg = data[offset + 1] - color[1];
  const db = data[offset + 2] - color[2];
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

function dominantBorderColor(data, width, height) {
  const counts = new Map();
  const add = (x, y) => {
    const offset = (y * width + x) * 4;
    if (data[offset + 3] < 24) return;
    const key = `${data[offset] >> 4}-${data[offset + 1] >> 4}-${data[offset + 2] >> 4}`;
    const entry = counts.get(key) || { count: 0, r: 0, g: 0, b: 0 };
    entry.count += 1;
    entry.r += data[offset];
    entry.g += data[offset + 1];
    entry.b += data[offset + 2];
    counts.set(key, entry);
  };
  for (let x = 0; x < width; x++) {
    add(x, 0); add(x, 1); add(x, height - 1); add(x, height - 2);
  }
  for (let y = 0; y < height; y++) {
    add(0, y); add(1, y); add(width - 1, y); add(width - 2, y);
  }
  let best = null;
  for (const entry of counts.values()) if (!best || entry.count > best.count) best = entry;
  if (!best) return [255, 255, 255];
  return [best.r / best.count, best.g / best.count, best.b / best.count];
}

export async function cutout(assetId, options = {}) {
  const tolerance = Math.max(4, Math.min(140, Number(options.tolerance) || 34));
  const image = await loadImage(assetId);
  if (!image) throw new Error('照片读取失败，请重新导入');
  const maxSide = 1400;
  const scale = Math.min(1, maxSide / Math.max(image.width, image.height));
  const width = Math.max(1, Math.round(image.width * scale));
  const height = Math.max(1, Math.round(image.height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(image, 0, 0, width, height);
  const frame = ctx.getImageData(0, 0, width, height);
  const data = frame.data;

  let transparent = 0;
  for (let i = 3; i < data.length; i += 4) if (data[i] < 240) transparent += 1;
  if (transparent > width * height * 0.04) {
    // 已经是透明图，只做轻度收边。
    return toBlob(canvas, options);
  }

  const background = dominantBorderColor(data, width, height);
  const limit = tolerance * tolerance;
  const total = width * height;
  const visited = new Uint8Array(total);
  const stack = new Int32Array(total);
  let top = 0;
  const push = index => {
    if (visited[index]) return;
    visited[index] = 1;
    const offset = index * 4;
    if (data[offset + 3] < 12) {
      data[offset + 3] = 0;
    } else {
      const dr = data[offset] - background[0];
      const dg = data[offset + 1] - background[1];
      const db = data[offset + 2] - background[2];
      const score = dr * dr + dg * dg + db * db;
      if (score > limit) return;
      data[offset + 3] = 0;
    }
    if (top < total) stack[top++] = index;
  };
  for (let x = 0; x < width; x++) { push(x); push((height - 1) * width + x); }
  for (let y = 0; y < height; y++) { push(y * width); push(y * width + width - 1); }

  while (top > 0) {
    const index = stack[--top];
    const x = index % width;
    const y = (index - x) / width;
    if (x > 0) push(index - 1);
    if (x < width - 1) push(index + 1);
    if (y > 0) push(index - width);
    if (y < height - 1) push(index + width);
  }

  // 边缘过渡：把紧邻透明区域的不透明像素做一个半透明羽化。
  for (let pass = 0; pass < 2; pass++) {
    const alpha = pass === 0 ? 118 : 196;
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const index = y * width + x;
        const offset = index * 4;
        if (data[offset + 3] === 0) continue;
        const near =
          data[(index - 1) * 4 + 3] === 0 || data[(index + 1) * 4 + 3] === 0 ||
          data[(index - width) * 4 + 3] === 0 || data[(index + width) * 4 + 3] === 0;
        if (near) data[offset + 3] = Math.min(data[offset + 3], alpha);
      }
    }
  }
  ctx.putImageData(frame, 0, 0);
  return toBlob(canvas, options);
}

function toBlob(canvas, options) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => {
      if (!blob) return reject(new Error('无法生成抠图'));
      resolve({ blob, width: canvas.width, height: canvas.height, url: URL.createObjectURL(blob) });
    }, 'image/png');
  });
}

export function fileToImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => { URL.revokeObjectURL(url); resolve(image); };
    image.onerror = () => { URL.revokeObjectURL(url); reject(new Error('无法读取图片')); };
    image.src = url;
  });
}
