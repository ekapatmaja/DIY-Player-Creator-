/* 界面语言：中文 / English。
   词条以中文原文为键，英文模式查表；未收录的键回退中文。
   数据名称（能力、技能、位置、球队等）由 catalog 的英文名或别名生成。 */

import { esc } from './core.js';

const STORAGE_KEY = 'maker.lang';
let language = 'zh';

export function initLanguage() {
  let stored = '';
  try { stored = localStorage.getItem(STORAGE_KEY) || ''; } catch { /* ignore */ }
  if (stored === 'zh' || stored === 'en') language = stored;
  else language = 'en';
  applyDocumentLanguage();
}

export function getLang() { return language; }
export function isEn() { return language === 'en'; }

export function setLang(value) {
  language = value === 'en' ? 'en' : 'zh';
  try { localStorage.setItem(STORAGE_KEY, language); } catch { /* ignore */ }
  applyDocumentLanguage();
}

function applyDocumentLanguage() {
  document.documentElement.lang = language === 'en' ? 'en' : 'zh-CN';
  document.documentElement.dataset.lang = language;
}

export function tr(text) {
  if (language !== 'en') return text;
  return EN[text] ?? text;
}

export function tf(text, vars = {}) {
  let value = tr(text);
  for (const [key, item] of Object.entries(vars)) value = value.split(`{${key}}`).join(String(item));
  return value;
}

const CJK = /[\u3400-\u9fff]/;
const POSITION_EN = {
  GK: 'Goalkeeper', CB: 'Centre Back', LB: 'Left Back', RB: 'Right Back', DMF: 'Defensive Midfielder',
  CMF: 'Central Midfielder', LMF: 'Left Midfielder', RMF: 'Right Midfielder', AMF: 'Attacking Midfielder',
  LWF: 'Left Wing Forward', RWF: 'Right Wing Forward', SS: 'Second Striker', CF: 'Centre Forward',
};
const POSITION_ZH = {
  GK: '门将', CB: '中后卫', LB: '左后卫', RB: '右后卫', DMF: '后腰', CMF: '中前卫',
  LMF: '左前卫', RMF: '右前卫', AMF: '前腰', LWF: '左边锋', RWF: '右边锋', SS: '影锋', CF: '中锋',
};
const SIX_EN = { speed: 'Pace', shooting: 'Shooting', passing: 'Passing', dribbling: 'Dribbling', defending: 'Defending', physical: 'Physical' };
const SIX_ZH = { speed: '速度', shooting: '射门', passing: '传球', dribbling: '盘带', defending: '防守', physical: '身体' };

export function positionLabel(code) {
  return language === 'en' ? (POSITION_EN[code] || code) : (POSITION_ZH[code] || code);
}

export function positionNameWithCode(code) {
  return `${code} · ${positionLabel(code)}`;
}

export function cardTypeLabel(card) {
  if (!card) return '';
  return language === 'en' ? (card.en || card.id) : (card.zh || card.id);
}

export function cardTypeBadge(type) {
  const value = String(type || '');
  if (value === 'BigTime') return 'BIG TIME';
  if (value === 'ShowTime') return 'SHOW TIME';
  if (value === 'Trending') return 'POTW';
  if (value === 'Standard') return 'STANDARD';
  return value.toUpperCase();
}

export function templateLabel(template) {
  return language === 'en' ? (TEMPLATE_EN[template.id] || template.label) : template.label;
}

export function abilityLabel(row) {
  if (!row) return '';
  return language === 'en' ? (row.en || row.zh) : row.zh;
}

export function abilityLabelByIndex(catalog, index) {
  return abilityLabel((catalog.abilities || []).find(row => row.index === Number(index)));
}

const SKILL_CODE_EN = {
  INDUS: 'Heavy Artillery', MEKONG: 'Long Pass Expert', NILE: 'Fleet Footed', GANGES: 'Power Tackle',
  MALICIA: 'Simulation', THAMES: 'Thames', CONGO: 'Congo',
};

export function skillEnglish(skill) {
  if (SKILL_CODE_EN[skill.code]) return SKILL_CODE_EN[skill.code];
  const aliases = skill.aliases || [];
  const alias = aliases.find(item => item && !CJK.test(item) && /[A-Za-z]/.test(item));
  if (alias) return alias;
  return skill.code
    .replace(/^STUDIO_/, '')
    .replace(/_SKILLS?$/, '')
    .split('_')
    .filter(Boolean)
    .map(word => word.charAt(0) + word.slice(1).toLowerCase())
    .join(' ');
}

export function skillLabel(skill) {
  if (!skill) return '';
  return language === 'en' ? skillEnglish(skill) : (skill.zh || skillEnglish(skill));
}

export function boosterLabel(booster, catalog) {
  if (!booster) return tr('不使用增能');
  if (language !== 'en') return (booster.zh || '') + (booster.conditional ? tr(' · 条件') : '');
  const entries = Object.entries(booster.effects || {});
  let text;
  if (!entries.length) text = tr('无常驻效果');
  else if (entries.length >= 26) {
    const value = entries[0][1];
    text = `${tr('全部能力')} ${value >= 0 ? '+' : ''}${value}`;
  } else {
    text = entries.map(([index, value]) => `${abilityLabelByIndex(catalog, index)} ${value >= 0 ? '+' : ''}${value}`).join(' · ');
  }
  return text + (booster.conditional ? ` · ${tr('条件')}` : '');
}

export function traitLabel(value) { return language === 'en' ? (TRAIT_EN[value] || value) : value; }

export function footLabel(value) {
  if (language !== 'en') return value;
  return value === '左脚' ? 'Left foot' : value === '右脚' ? 'Right foot' : value;
}

export function conditionLabel(value) {
  if (language !== 'en') return value === 'auto' ? '跟随默认规则' : value;
  return value === 'auto' ? 'Follow default' : value;
}

export function groupLabel(name) { return language === 'en' ? (GROUP_EN[name] || name) : name; }

export function trainingLabel(name) { return language === 'en' ? (TRAINING_EN[name] || name) : name; }

export function sixLabel(group, short = false) {
  if (language === 'en') return short ? group.en : (SIX_EN[group.key] || group.en);
  return short ? group.en : (SIX_ZH[group.key] || group.zh);
}

export function nationDisplay(catalog, identity) {
  const row = (catalog?.nations || []).find(item => item.id === identity?.nation_id);
  if (language === 'en') return row?.en || identity?.nation || '';
  return row?.zh || identity?.nation || '';
}

export function teamDisplay(catalog, identity) {
  const row = (catalog?.teams || []).find(item => item.id === identity?.team_id);
  if (language === 'en') return row?.en || identity?.team || '';
  return row?.zh || identity?.team || '';
}

export function nationLabel(row) { return language === 'en' ? (row?.en || '') : (row?.zh || ''); }
export function teamLabel(row) { return language === 'en' ? (row?.en || '') : (row?.zh || ''); }

export function aiStyleLabel(row) { return language === 'en' ? (row?.en || row?.zh || '') : (row?.zh || row?.en || ''); }

export function templateLanguageLabel(template) { return templateLabel(template); }

export function localizeError(message) {
  if (language !== 'en' || !message) return message;
  const text = String(message);
  if (ERROR_EN[text]) return ERROR_EN[text];
  for (const [prefix, replacement] of Object.entries(ERROR_PREFIX_EN)) {
    if (text.startsWith(prefix)) return replacement + text.slice(prefix.length);
  }
  return text;
}

const TEMPLATE_EN = {
  epic: 'Epic · Astral', bigtime: 'Big Time · Shards', showtime: 'Show Time · Spotlight',
  legend: 'Legend · Gilded', featured: 'Featured · Celadon', highlight: 'Highlight · Lava',
  potw: 'POTW · Midnight', standard: 'Standard · Iron', custom: 'Custom background',
};

const GROUP_EN = {
  '进攻与技术': 'Attack & Technique', '速度与身体': 'Speed & Physical', '防守': 'Defending', '守门': 'Goalkeeping',
};

const TRAINING_EN = {
  '射门': 'Shooting', '传球': 'Passing', '盘球': 'Dribbling', '灵巧': 'Agility',
  '下肢力量': 'Lower Body Strength', '空中力量': 'Aerial', '防守': 'Defending',
  '守门员 1': 'Goalkeeper 1', '守门员 2': 'Goalkeeper 2', '守门员 3': 'Goalkeeper 3',
};

const TRAIT_EN = {
  '低': 'Low', '普通': 'Normal', '高': 'High', '极高': 'Very high',
  '稳定': 'Stable', '不稳定': 'Unstable',
};

const ERROR_EN = {
  '本地会话已失效，请重新启动制作器': 'The local session has expired. Please restart the editor.',
  '文件是空的': 'The file is empty.',
  '文件超过 256 MB，请先压缩': 'The file is larger than 256 MB. Please compress it first.',
  '找不到这名球员': 'Player not found.',
  '工程编号无效': 'Invalid project id.',
  '不是制作器的球员资料': 'This is not a Player Studio Maker project.',
  '请选择 .psplayer 工程文件': 'Please choose a .psplayer project file.',
  '导出的临时目录不存在': 'The temporary export folder no longer exists.',
  '请求内容为空': 'The request is empty.',
  '上传内容过大': 'The upload is too large.',
  '请求格式不正确': 'Invalid request format.',
  '页面不存在': 'Page not found.',
  '文件不存在': 'File not found.',
  '球员资料需要是 JSON 对象': 'Player data must be a JSON object.',
  '球员资料格式不正确': 'Invalid player profile.',
  '球员数据格式不正确': 'Invalid player data.',
};

const ERROR_PREFIX_EN = {
  '不支持的文件类型：': 'Unsupported file type: ',
  '操作失败：': 'Operation failed: ',
};

/* 中文原文 → English。新增界面文案时在这里补一条即可。 */
const EN = {
  /* ---------- shell / navigation ---------- */
  '制作器': 'Studio',
  '我的球员': 'My Players',
  '球员资料': 'Player Profile',
  '基础能力': 'Abilities',
  '培养模拟': 'Development',
  '技能与风格': 'Skills & Style',
  '卡面设计': 'Card Design',
  '模型工作区': 'Model Studio',
  '导出与工程': 'Export & Project',
  '使用说明': 'Guide',
  '资料': 'Profile',
  '能力': 'Abilities',
  '培养': 'Development',
  '技能': 'Skills',
  '卡面': 'Card',
  '模型': 'Model',
  '导出': 'Export',
  '说明': 'Guide',
  '工作区': 'Workspace',
  '本地球员工程': 'Local player project',
  '打开数据目录': 'Open data folder',
  '球员编号': 'Player ID',
  '实时预览': 'Live preview',
  '设计工程': 'Design project',
  '导出预览': 'Export preview',
  '球员卡面': 'Card',
  '能力概览': 'Stats',
  '模型取景': 'Model shot',
  '新建球员': 'New player',
  '已保存': 'Saved',
  '已保存到本机': 'Saved locally',
  '正在保存…': 'Saving…',
  '保存失败，按 Ctrl+S 重试': 'Save failed. Press Ctrl+S to retry.',
  '撤销': 'Undo',
  '重做': 'Redo',
  '撤销 (Ctrl+Z)': 'Undo (Ctrl+Z)',
  '重做 (Ctrl+Shift+Z)': 'Redo (Ctrl+Shift+Z)',
  '切换工作区': 'Switch workspace',
  '语言': 'Language',
  '中': '中',
  'EN': 'EN',
  '姓名': 'Name',
  '位置': 'Position',
  '卡种': 'Card type',
  '总评': 'Overall',
  '{n} 名球员': '{n} player(s)',
  '已导出 {n} 个文件到本机': 'Exported {n} file(s) to this PC',
  '{n} 个文件': '{n} file(s)',
  '打开模型工作区': 'Open Model Studio',
  '六维能力雷达图': 'Six-attribute radar chart',
  '天生 {n} · 追加 {m}': 'Innate {n} · Additional {m}',
  '已用 ': 'Used ',
  '例如：凌 风': 'e.g. Alex Morgan',

  /* ---------- page descriptions ---------- */
  '管理本机的球员工程，随时打开、复制或导出。': 'Manage local player projects. Open, duplicate or export them any time.',
  '名字、位置、身材与卡种，先确定这名球员是谁。': 'Start with the name, position, build and card type.',
  '设定 1 级基础值；右侧总评会随培养与增能实时变化。': 'Set base values at level 1. The overall rating updates with development and boosters.',
  '按等级预算分配培养点，比较不同方案的最终能力与总评。': 'Spend development points within the level budget and compare final ratings.',
  '搭配天生与额外习得技能，再选比赛风格。': 'Combine innate and additional skills, then choose play styles.',
  '导入照片、选模板、调构图，导出一张 1200 × 1720 的卡面。': 'Import a photo, choose a template, adjust the framing and export a 1200 × 1720 card.',
  '导入 GLB / OBJ，预览、取景成卡面照片，或重新导出模型。': 'Import GLB / OBJ, preview it, turn it into card art, or export the model again.',
  '把卡面、数据和模型打包；也可以备份或导入工程。': 'Pack the card, data and model together, or back up / import a project.',
  '三分钟了解制作器的工作方式。': 'Learn how the studio works in three minutes.',
  '创建球员、打磨卡面、导出属于你的作品。': 'Create a player, polish the card and export your work.',
  '管理本机的球员工程，随时打开、复制或导出。': 'Manage local player projects. Open, duplicate or export them at any time.',

  /* ---------- players page ---------- */
  '共 {n} 名球员 · 当前编辑：{name}': '{n} player(s) · Editing: {name}',
  '还没有保存的球员': 'No saved players yet',
  '导入工程': 'Import project',
  '打开': 'Open',
  '复制': 'Duplicate',
  '删除': 'Delete',
  '复制这名球员': 'Duplicate this player',
  '从第一名球员开始': 'Start with your first player',
  '填写资料、调整能力、设计卡面，所有内容都会自动保存在本机。<br>不需要 APK，也不会改动游戏文件。': 'Fill in the profile, tune the abilities and design the card. Everything saves locally.<br>No APK is read and no game file is modified.',
  '提示：双击球员卡也可以打开。右键浏览器窗口可刷新；数据保存在程序目录的 <code>data/players</code>。': 'Tip: double-click a player card to open it. Use the browser refresh if needed; data lives in <code>data/players</code>.',
  '{n} 名球员': '{n} player(s)',

  /* ---------- profile ---------- */
  '基本信息': 'Basic information',
  '球员姓名': 'Player name',
  '例如：凌 风': 'e.g. Alex Morgan',
  '当前环境不支持 3D 预览': 'This environment does not support 3D preview.',
  '模型无法解析：{msg}。Draco / Meshopt 压缩的模型需要先解压。': 'Could not parse the model: {msg}. Draco / Meshopt compressed models must be decompressed first.',
  '未命名动画': 'Unnamed animation',
  '已导入模型': 'Imported model',
  '服务器返回了无法识别的内容': 'The server returned an unreadable response.',
  '操作失败（{status}）': 'Operation failed ({status}).',
  '卡面显示名可以单独设置': 'The card display name can be different.',
  '球衣背后名字': 'Shirt name',
  '留空则使用姓名': 'Leave empty to use the player name.',
  '卡面显示名': 'Card display name',
  '国籍 / 地区': 'Nationality / Region',
  '输入中文或英文名称搜索': 'Search by Chinese or English name.',
  '俱乐部 / 球队': 'Club / Team',
  '可以填写任意名称': 'You can enter any name.',
  '主要位置': 'Main position',
  '惯用脚': 'Preferred foot',
  '右脚': 'Right foot',
  '左脚': 'Left foot',
  '身高': 'Height',
  '体重': 'Weight',
  '年龄': 'Age',
  '岁': 'yrs',
  '球衣号码': 'Shirt number',
  '卡种与卡面资料': 'Card type & card details',
  '卡面系列': 'Card series',
  '例如：EPIC / BIG TIME': 'e.g. EPIC / BIG TIME',
  '卡面标题': 'Card title',
  '显示在卡面顶部的小字': 'Small text shown at the top of the card.',
  '卡面编号': 'Card number',
  '显示为 NO.0001': 'Displayed as NO.0001',
  '卡面星级': 'Card rarity',
  '1 星': '1 star', '2 星': '2 stars', '3 星': '3 stars', '4 星': '4 stars', '5 星': '5 stars',
  '纪念日期': 'Memorial date',
  '留空则不显示': 'Leave empty to hide.',
  '实时状态': 'Live condition',
  '跟随默认规则': 'Follow default rules',
  '卡种决定右侧预览的默认配色；卡面模板可以在“卡面设计”里单独更换。': 'Card type sets the default colours; the template can be changed separately in Card Design.',
  '其他特征': 'Other traits',
  '逆足使用频率': 'Weak foot usage',
  '逆足精准度': 'Weak foot accuracy',
  '状态持续性': 'Form',
  '受伤耐性': 'Injury resistance',
  '备注': 'Notes',
  '只保存在本机的备注': 'Notes saved only on this machine',
  '例如：灵感来源、卡面构图想法、下一个能力调整方案…': 'e.g. inspiration, framing ideas, next ability changes…',
  '备注不会出现在导出的卡面里，但会写进资料 JSON 与工程文件。': 'Notes do not appear on the card, but are written into the data JSON and project file.',
  'PROFILE': 'PROFILE', 'CARD': 'CARD', 'TRAITS': 'TRAITS', 'NOTES': 'NOTES',
  '低': 'Low', '普通': 'Normal', '高': 'High', '极高': 'Very high',
  '稳定': 'Stable', '不稳定': 'Unstable',
  '跟随默认规则（BT / 史诗 / 传奇为 B）': 'Follow default rules (B for BT / Epic / Legendary)',

  /* ---------- abilities ---------- */
  '基础能力范围 40–105 · 培养上限 105': 'Base range 40–105 · development cap 105',
  '套用参考': 'Apply reference',
  '重置 65': 'Reset to 65',
  '{pos} · {name}（参考 {n} 名球员）': '{pos} · {name} (from {n} players)',
  '全部 26 项': 'All 26',
  '数值越高越强。守门员能力对非门将位置的总评影响很小，但会保留在资料里。': 'Higher is better. Goalkeeping barely affects outfield ratings but stays in the data.',
  '位置适应度': 'Position aptitude',
  '完全适应代表该位置可以正常发挥；部分适应会降低位置表现。': 'Full aptitude means the player is comfortable there; partial aptitude reduces performance.',
  '比赛风格': 'Play style',
  '进攻比赛风格': 'Attacking play style',
  '防守比赛风格': 'Defensive play style',
  '无球跑动、持球习惯的总体倾向': 'General off-ball movement and on-ball tendencies.',
  '不适应': 'Not suited', '部分适应': 'Partially suited', '完全适应': 'Fully suited',
  'APTITUDE': 'APTITUDE', 'PLAY STYLE': 'PLAY STYLE', '26 STATS': '26 STATS',
  '{name}数值': '{name} value',
  '减少': 'Decrease', '增加': 'Increase',

  /* ---------- training ---------- */
  '不使用增能': 'No booster',
  '条件': 'conditional',
  ' · 条件': ' · conditional',
  '等级设置': 'Level settings',
  '模拟当前等级': 'Current level',
  '等级上限': 'Level cap',
  '级': 'lvl',
  '每提升 1 级获得 2 点培养点；同一个项目每加 4 次，下一次消耗增加 1 点。单次培养上限 +40，能力上限 105。': 'Each level grants 2 development points. Every 4 points in the same group raises the next cost by 1. Max +40 per group, ability cap 105.',
  '等级提供': 'From level', '已分配': 'Spent', '剩余培养点': 'Remaining',
  '点': 'pts',
  '加点目标位置': 'Training target',
  '按位置分配': 'Auto allocate',
  '最优培养': 'Optimal build',
  '重置': 'Reset',
  '趋势 / POTW': 'Trending / POTW',
  'Trending 卡种按常规规则不能培养；如果希望自由加点，请在资料页换用其他卡种。': 'Trending cards cannot be developed under normal rules. Choose another card type in Profile to train freely.',
  '球员增能': 'Player boosters',
  '增能槽 1': 'Booster slot 1',
  '增能槽 2': 'Booster slot 2',
  '把条件增能也计入预览': 'Count conditional boosters in the preview',
  '增能会直接加到指定能力上，再计算总评。选择“不使用增能”即不生效；两个槽位请选择不同项目。': 'Boosters add directly to the listed abilities before the overall rating is calculated. Choose different boosters for the two slots.',
  '全部 26 项明细': 'All 26 abilities',
  '培养后': 'Trained', '增能后': 'Boosted', '最终': 'Final', '变化': 'Change',
  '目标 {pos} · 该位置总评 {ovr}': 'Target {pos} · {ovr} OVR at this position',
  '已用 {used} 点 · 下次 {next} 点': 'Used {used} · next {next}',
  'BOOSTERS': 'BOOSTERS', 'LEVEL': 'LEVEL', 'DETAIL': 'DETAIL',
  '全部能力': 'All abilities', '无常驻效果': 'No permanent effect',

  /* ---------- skills ---------- */
  '天生技能': 'Innate skills',
  '额外习得': 'Additional skills',
  '天生': 'Innate',
  '追加': 'Additional',
  '搜索中文名、英文代号或编号': 'Search name, code or number',
  '只看已选': 'Selected only',
  '点击添加，再次点击取消': 'Click to add, click again to remove',
  '没有匹配的技能': 'No matching skills',
  '天': 'I', '追': 'A',
  '原创效果': 'custom effect',
  'AI 比赛风格': 'AI playing styles',
  '影响电脑控制这名球员时的跑位与处理球倾向，可多选或全部取消。': 'Affects how the AI moves and uses the ball for this player. Select any or none.',
  'AI STYLE': 'AI STYLE',

  /* ---------- card page ---------- */
  '球员照片': 'Player photo',
  '还没有照片<br>透明 PNG 效果最好': 'No photo yet<br>Transparent PNG',
  '导入人物照片后，卡面会自动裁切排版。纯色背景的照片可以直接用内置抠图；已经是透明 PNG 的会原样使用。': 'The card lays out the photo automatically. Solid-background photos can use the built-in cutout; transparent PNGs are used as-is.',
  '替换照片': 'Replace photo',
  '导入照片': 'Import photo',
  '抠图': 'Cut out',
  '移除': 'Remove',
  '使用抠图结果': 'Use cutout result',
  '抠图容差': 'Cutout tolerance',
  '背景越花越要调高；抠完再调一次即可': 'Raise it for busier backgrounds; adjust and cut out again.',
  '透明 PNG 不需要抠图。如果人物穿着接近背景的颜色（例如白袜配白底），可能被一起扣掉，可降低容差或改用透明 PNG。': 'Transparent PNGs need no cutout. If clothing is close to the background colour (white socks on white), lower the tolerance or use a transparent PNG.',
  '卡面模板': 'Card templates',
  '模板只改变卡面风格；照片、姓名、能力与技能都会保留。当前：{name}。': 'Templates only change the style; photo, name, abilities and skills stay. Current: {name}.',
  '颜色与构图': 'Colour & layout',
  '主色': 'Accent colour',
  '快速配色': 'Quick colours',
  '照片缩放': 'Photo scale',
  '水平位置': 'Horizontal',
  '垂直位置': 'Vertical',
  '旋转': 'Rotate',
  '提示：直接拖动右侧卡面也可以移动照片。': 'Tip: drag the card preview to move the photo.',
  '背景': 'Background',
  '背景方式': 'Background mode',
  '使用模板背景': 'Use template background',
  '使用自己的背景图': 'Use my own background',
  '自定义背景': 'Custom background',
  '未选择': 'Not selected',
  '选择图片': 'Choose image',
  '卡面显示项': 'Visible on card',
  '六项能力': 'Six stats',
  '技能标签': 'Skill tags',
  '国家 / 球队': 'Nation / club',
  '星级': 'Stars',
  '背号水印': 'Number watermark',
  '导出卡面': 'Export card',
  '导出为 PNG：卡面 1200 × 1720，小头像 512 × 512。文件名会自动带上球员名字。': 'PNG output: card 1200 × 1720, avatar 512 × 512. The player name is used in the filename.',
  '导出卡面 PNG': 'Export card PNG',
  '导出小头像': 'Export avatar',
  '更多导出选项': 'More export options',
  '当前球员照片': 'Current player photo',
  '卡面背景': 'Card background',
  '自定义卡面背景': 'Custom card background',
  '背景明暗': 'Background dim',
  '背景缩放': 'Background scale',
  '背景水平': 'Background X',
  '背景垂直': 'Background Y',
  '保留默认卡框': 'Keep default frame',
  '上传卡面背景': 'Upload card background',
  '自定义卡面背景会覆盖模板背景；关掉卡框后，整张图就是卡面。': 'A custom card background overrides the template background. Turn off the default frame to use the whole image as the card.',
  '先上传一张卡面背景': 'Upload a card background first',
  '使用自定义背景图': 'Use a custom background image',
  '卡面边框': 'Card frame',
  '选择“自定义卡面”模板可直接把背景图当作卡面底板。': 'Choose the Custom background template to use the image as the full card base.',
  'Show Time': 'Show Time',
  '背景': 'Background',
  'TEMPLATE': 'TEMPLATE', 'LAYOUT': 'LAYOUT', 'BACKGROUND': 'BACKGROUND', 'VISIBLE': 'VISIBLE', 'PORTRAIT': 'PORTRAIT',

  /* ---------- model ---------- */
  '替换模型': 'Replace model',
  '导入模型': 'Import model',
  '导出 GLB': 'Export GLB',
  '导出 OBJ': 'Export OBJ',
  '支持 GLB / GLTF / OBJ，模型只用于预览与投稿，不写入游戏': 'GLB / GLTF / OBJ supported. Models are for preview and presentation only and are never written into the game.',
  '左键旋转 · 滚轮缩放 · 右键平移': 'Drag to rotate · scroll to zoom · right-drag to pan',
  '适应画面': 'Fit view',
  '正面': 'Front',
  '侧面': 'Side',
  '45°': '45°',
  '头部': 'Head',
  '取景为卡面照片': 'Capture as card photo',
  '取景为小头像': 'Capture as avatar',
  '线框': 'Wireframe',
  '显示骨架': 'Show skeleton',
  '自动旋转': 'Auto rotate',
  '模型调整': 'Model transform',
  '显示缩放': 'Display scale',
  '水平旋转': 'Yaw',
  '上下位置': 'Vertical offset',
  '调整只影响预览与取景，不会改变导出的原始模型。': 'These changes affect the preview and capture only; the exported model is unchanged.',
  '模型信息': 'Model information',
  '网格': 'Meshes',
  '三角面': 'Triangles',
  '顶点': 'Vertices',
  '骨骼': 'Bones',
  '材质 / 贴图': 'Materials / textures',
  '动画': 'Animations',
  '导入时已按最长边 1.75 个单位归一化显示。导出的 GLB / OBJ 使用模型原始坐标与材质。': 'The preview is normalised to 1.75 units on the longest side. Exported GLB / OBJ keeps the original transforms and materials.',
  '已保存的取景': 'Saved captures',
  '卡面照片': 'Card photo',
  '小头像': 'Avatar',
  '取景已自动用于卡面；也可以重新取景覆盖。': 'The capture is already used on the card; capture again to replace it.',
  '使用说明': 'Guide',
  '模型可以是自制的头模、全身模型或任何 GLB / OBJ。这个制作器不会把模型打包进游戏，只负责预览、取景和导出文件。如果模型带骨骼或动画，也会一并保留在导出的 GLB 中。': 'The model can be a custom head, a full body or any GLB / OBJ. The studio never packs it into the game; it previews, captures and exports the file. Bones and animations are kept in exported GLB.',
  'TRANSFORM': 'TRANSFORM', 'MESH': 'MESH', 'CAPTURE': 'CAPTURE', 'NOTE': 'NOTE',
  '还没有导入模型': 'No model imported yet',
  '还没有导入 3D 模型': 'No 3D model imported yet',
  '模型已导入<br>到模型页取景即可变成卡面照片': 'Model imported<br>Capture it in Model Studio to use on the card',
  '正在读取模型…': 'Loading model…',
  '模型读取失败': 'Failed to load model',
  '正在准备 3D 工作区…': 'Preparing 3D workspace…',
  '当前浏览器无法创建 3D 画面。请使用 Edge 或 Chrome，并在设置里开启图形加速。': 'This browser cannot create a 3D view. Use Edge or Chrome and enable graphics acceleration.',
  '请先导入模型': 'Import a model first.',
  '模型里没有可显示的网格': 'The model has no visible mesh.',
  '只支持 GLB、GLTF 和 OBJ 模型': 'Only GLB, GLTF and OBJ models are supported.',
  '取景失败，请重试': 'Capture failed. Please try again.',
  '原始模型读取失败': 'Failed to read the original model.',
  '模型尚未准备完成': 'The model is not ready.',

  /* ---------- export ---------- */
  '导出内容': 'Export contents',
  '卡面 PNG': 'Card PNG',
  '1200 × 1720，带全部卡面信息': '1200 × 1720 with all card details',
  '小头像 PNG': 'Avatar PNG',
  '512 × 512，适合列表与头像': '512 × 512 for lists and avatars',
  '球员资料 JSON': 'Player data JSON',
  '完整数据与计算结果，可程序读取': 'Full data and calculated results, machine-readable',
  '球员资料 Markdown': 'Player profile Markdown',
  '人类可读的一页资料': 'A one-page human-readable profile',
  '能力 CSV': 'Abilities CSV',
  '26 项能力一行，适合表格': 'One row with all 26 abilities, for spreadsheets',
  '模型文件': 'Model file',
  '原始 GLB / OBJ 文件': 'Original GLB / OBJ file',
  '尚未导入模型': 'No model imported',
  '模型预览 PNG': 'Model preview PNG',
  '已保存的卡面取景': 'Saved card capture',
  '尚未取景': 'No capture yet',
  '导出到本机': 'Export to this PC',
  '导出并压缩 ZIP': 'Export & zip',
  '打开导出目录': 'Open export folder',
  '导出目录：': 'Export folder: ',
  '。文件保存在本机，不会上传。': '. Files stay on this PC and are never uploaded.',
  '当前球员工程': 'Current player project',
  '导出 <strong>.psplayer</strong> 会把资料、照片、模型和所有设置打包成一个文件，便于备份或交给另一台电脑继续编辑。': 'Export <strong>.psplayer</strong> to pack the profile, photos, model and every setting into one file for backup or editing on another PC.',
  '导出工程 .psplayer': 'Export project .psplayer',
  '导出卡面和数据时会写入程序旁边的 exports 目录；工程文件同样保存在这里。整个 data 目录建议定期备份。': 'Cards and data are written to the exports folder beside the app; project files are saved there too. Back up the whole data folder regularly.',
  '打开 data 目录': 'Open data folder',
  '打开最近一次导出': 'Open latest export',
  '批量导出': 'Batch export',
  '把“我的球员”里的全部球员依次导出为卡面、小头像和资料，最后压缩成一个 ZIP。模型和工程不包含在批量包里。': 'Export every player in My Players as a card, avatar and profile, then zip them together. Models and projects are not included.',
  '导出全部球员': 'Export all players',
  '最近导出': 'Recent exports',
  '正在读取…': 'Loading…',
  '文件说明': 'File formats',
  '卡面 PNG</strong>：1200 × 1720，可直接当作品展示或打印。照片、模板、姓名、总评与技能都按当前设置渲染。': 'Card PNG</strong>: 1200 × 1720, ready to show or print. Photo, template, name, rating and skills follow the current settings.',
  '资料 JSON</strong>：包含基础能力、培养、增能、最终能力、每位置总评、卡面配置和模型信息，字段名固定，便于自己写脚本继续处理。': 'Data JSON</strong>: base, development, boosters, final abilities, ratings by position, card settings and model info with stable field names.',
  '能力 CSV</strong>：UTF-8 BOM 编码，Excel 直接打开不乱码。': 'Abilities CSV</strong>: UTF-8 with BOM, opens cleanly in Excel.',
  '工程 .psplayer</strong>：ZIP 格式，内含 player.json 与 assets。制作器可以直接导入。': 'Project .psplayer</strong>: a ZIP containing player.json and assets. Import it back directly.',
  '正在导出…': 'Exporting…',
  '已导出 {n} 个文件到': 'Exported {n} file(s) to',
  '已打包 {n} 个文件': 'Packed {n} file(s)',
  '压缩包：': 'Archive: ',
  '打开文件夹': 'Open folder',
  '已导出 {n} 名球员、{m} 个文件。': 'Exported {n} player(s) and {m} file(s).',
  '还没有导出记录': 'No exports yet',
  '个文件': 'files',
  '下载': 'Download',
  '请至少选择一项导出内容': 'Select at least one export item.',
  '还没有球员可以导出': 'There are no players to export.',
  '全部球员已打包导出': 'All players have been exported.',
  '工程已导出：{name}': 'Project exported: {name}',
  '工程已导入': 'Project imported.',
  '工程已导入，恢复 {n} 个素材': 'Project imported. Restored {n} asset(s).',
  '已导出 {n} / {total}：{name}': 'Exported {i} / {total}: {name}',

  /* ---------- toasts / dialogs ---------- */
  '已创建 {name}，修改会自动保存': '{name} created. Changes save automatically.',
  '已复制球员，可以独立编辑': 'Player duplicated. You can edit it independently.',
  '球员已删除': 'Player deleted.',
  '照片已导入，可以点“抠图”去掉纯色背景': 'Photo imported. Use Cut out for solid backgrounds.',
  '照片已导入': 'Photo imported.',
  '抠图完成，已用于卡面；容差可以再调': 'Cutout complete and applied to the card. You can refine the tolerance.',
  '正在抠图，请稍候…': 'Cutting out, please wait…',
  '模型已导入，正在读取网格': 'Model imported. Reading the mesh…',
  '模型已导入': 'Model imported.',
  '模型已移除': 'Model removed.',
  '已导出 GLB 模型': 'GLB model exported.',
  '已导出 OBJ 模型': 'OBJ model exported.',
  '正在取景卡面照片…': 'Capturing card photo…',
  '正在取景小头像…': 'Capturing avatar…',
  '取景已用于卡面照片': 'Capture applied to the card photo.',
  '小头像已保存': 'Avatar saved.',
  '卡面已导出：1200 × 1720 PNG': 'Card exported: 1200 × 1720 PNG.',
  '小头像已导出：512 × 512 PNG': 'Avatar exported: 512 × 512 PNG.',
  '已导出 {format} 模型': '{format} model exported.',
  '已保存到本机': 'Saved locally',
  '工程已保存': 'Project saved.',
  '请先导入模型': 'Import a model first.',
  '还没有导入模型': 'No model imported yet.',
  '还没有导出记录': 'No export records yet.',
  '已按目标位置生成参考加点': 'Reference development plan generated for the target position.',
  '已按总评最优重新分配培养点': 'Development points reallocated for the highest overall rating.',
  '已套用 {pos} 参考能力（{n} 名球员平均）': 'Applied the {pos} reference abilities (average of {n} players).',
  '卡种已切换为 {name}': 'Card type changed to {name}.',
  '请选择一名球员': 'Choose a player first.',
  '请至少选择一项导出内容': 'Select at least one export item.',
  '这个工程已绑定另一名球员': 'This project is bound to another player.',
  '确定删除“{name}”吗？工程文件会从 data/players 移除，自动备份也会一起清理。': 'Delete “{name}”? The project file and its automatic backups will be removed from data/players.',
  '删除球员': 'Delete player',
  '取消': 'Cancel',
  '确定': 'OK',
  '创建球员': 'Create player',
  '新建球员': 'New player',
  '建立一个独立球员工程。已保存的球员不会被覆盖，资料会立即写入本机。': 'Create a standalone player project. Saved players are not overwritten and the profile is written to this PC immediately.',
  '参考模板（可选）': 'Reference template (optional)',
  '不使用参考': 'No reference',
  '参考 {n} 名球员': 'from {n} players',
  '开始创作': 'Start creating',
  '下次不再显示': "Don't show again",
  '这是一个只做球员创作的本地工具：<strong>不读取 APK</strong>，也不需要游戏安装包。填写资料与能力，设计卡面，导入自己的模型，然后导出卡面 PNG、数据文件和模型。': 'A local tool for player creation. It <strong>does not read APKs</strong> and needs no game install. Fill in the profile and abilities, design the card, import your model, then export card PNGs, data files and models.',
  '资料、能力、培养、技能，总评按内置公式实时计算。': 'Profile, abilities, development and skills, with live rating calculation.',
  '七套卡面模板 + 自己的照片，拖一拖就能排版。': 'Seven card templates plus your own photo, arranged by dragging.',
  'GLB / OBJ 模型可预览、取景成卡面照片并重新导出。': 'Preview GLB / OBJ models, capture them as card art and export them again.',
  '所有文件只存在本机，不联网、不上传。': 'Everything stays on this PC. No network, no uploads.',
  '切换语言': 'Switch language',
  '界面语言已切换': 'Interface language changed.',

  /* ---------- traits / conditions / badges ---------- */
  '逆足使用频率': 'Weak foot usage',
  '逆足精准度': 'Weak foot accuracy',
  '状态持续性': 'Form',
  '受伤耐性': 'Injury resistance',
  '中国': 'China PR',
  '右脚': 'Right foot',
  '左脚': 'Left foot',
  '右脚': 'Right foot',

  /* ---------- play styles ---------- */
  '无风格': 'No style', '偷猎者': 'Poacher', '虚假跑位': 'Dummy Runner', '禁区之狐': 'Fox in the Box',
  '高产边锋': 'Prolific Winger', '古典十号位': 'Classic No. 10', '前插攻击手': 'Hole Player',
  '全能中场': 'Box-to-Box', '靠山': 'Anchor Man', '额外前锋': 'Extra Frontman',
  '进攻型后卫': 'Offensive Full-back', '防守型后卫': 'Defensive Full-back', '拖后中锋': 'Target Man',
  '创意指挥官': 'Creative Playmaker', '建立': 'Build Up', '自由边翼': 'Roaming Flank',
  '传中专家': 'Cross Specialist', '指挥官': 'Orchestrator', '迭瓦式终结者': 'Full-back Finisher',
  '组织型门将': 'Ball-Playing Goalkeeper',
  '破坏者': 'Destroyer', '进攻型门将': 'Offensive Goalkeeper', '防守型门将': 'Defensive Goalkeeper',
  '回撤压迫': 'Deep Pressing', '前线压迫': 'Front-line Pressing', '前线抢点': 'Front-line Runner',
  '进攻接应': 'Attacking Link', '全能防守者': 'Versatile Defender', '传球干扰者': 'Pass Disruptor',
  '补位': 'Cover', '高位防线大师': 'High Line Master', '贴身盯人': 'Man Marking',
  '深位防守者': 'Deep Defender', '清道夫门将': 'Sweeper Keeper',

  /* ---------- card types ---------- */
  '史诗': 'Epic', '传奇': 'Legendary', '精选': 'Featured', '高光': 'Highlight',
  '趋势 / POTW': 'Trending / POTW', '标准': 'Standard', 'Big Time': 'Big Time',

  /* ---------- card renderer ---------- */
  '导入球员照片': 'Import player photo',
  '透明 PNG 或纯色背景照片': 'Transparent PNG or solid background',
  '岁': 'yrs',
};

/* Additional interface strings. */
Object.assign(EN, {
  '创作': 'Create',
  '球员工坊 · 制作器': 'Player Studio · Maker',
  '球员工坊': 'Player Studio',
  'MAKER · 制作器': 'MAKER · STUDIO',
  '未创建': 'Not created',
  '基础': 'Base',
  '计算总评': 'Calculated overall',
  '模拟等级': 'Simulated level',
  '技能数量': 'Skills',
  '各位置计算总评': 'Ratings by position',
  '实线：培养与增能后 · 虚线：1 级基础': 'Solid: trained + boosters · Dashed: level 1',
  '内置位置回归公式 · 不含教练与状态箭头': 'Built-in position regression · no coach or condition arrows',
  '总评使用内置位置回归公式，包含培养与增能，不包含教练和状态箭头。卡面与模型都是本机设计稿，不会写入游戏。':
    'Overall uses the built-in position regression with development and boosters, excluding coaches and condition arrows. Cards and models are local designs and are never written into the game.',
  '导入 GLB / OBJ 后，可在模型页取景并直接变成卡面照片。':
    'Import GLB / OBJ, then capture it in Model Studio to use as card art.',
  '资料 JSON': 'Data JSON',
  '能力 CSV': 'Abilities CSV',
  '工程 .psplayer': 'Project .psplayer',
  '1200 × 1720，可直接当作品展示或打印。照片、模板、姓名、总评与技能都按当前设置渲染。':
    '1200 × 1720, ready to show or print. Photo, template, name, rating and skills follow the current settings.',
  '包含基础能力、培养、增能、最终能力、每位置总评、卡面配置和模型信息，字段名固定，便于自己写脚本继续处理。':
    'Includes base, development, boosters, final abilities, ratings by position, card settings and model info with stable field names.',
  'UTF-8 BOM 编码，Excel 直接打开不乱码。': 'UTF-8 with BOM; opens cleanly in Excel.',
  'ZIP 格式，内含 player.json 与 assets。制作器可以直接导入。': 'A ZIP containing player.json and assets. Import it back directly.',
  '导出目录：': 'Export folder: ',
  '。文件保存在本机，不会上传。': '. Files stay on this PC and are never uploaded.',
  '全部球员': 'All players',
  '新球员': 'New Player',
  '副本': 'Copy',
  '球员': 'Player',
  '未命名球员': 'Unnamed player',
  '画布导出失败': 'Canvas export failed.',
  '额外习得技能最多 10 项，请先取消其中一项': 'Additional skills are limited to 10. Remove one first.',
  '找不到这名球员': 'Player not found.',
  '请关闭窗口后重新启动；如果问题持续，查看 data/studio.log。': 'Please close and restart. If the problem persists, check data/studio.log.',
  '制作器没有启动成功': 'The studio failed to start.',
  '切换语言': 'Switch language',
  '基础 ': 'Base ',
  '上限 ': 'Cap ',
  '已用 ': 'Used ',
  '个素材': 'asset(s)',
  '名球员': 'player(s)',
  '星': 'star',
  '{n} 星': '{n} star(s)',
  '参考 {n} 名球员': 'from {n} players',
  '计算总评 · {pos}': 'Overall · {pos}',
  '基础 {base} → 培养 {trained}': 'Base {base} → Trained {trained}',
  '增能 {boosted}': 'Boosted {boosted}',
  '天生 {n} · 追加 {m}': 'Innate {n} · Additional {m}',
  '目标 {pos} · 该位置总评 {ovr}': 'Target {pos} · {ovr} OVR at this position',
  '已用 {used} 点 · 下次 {next} 点': 'Used {used} · next {next}',
  '等级提供': 'From level',
  '已分配': 'Spent',
  '剩余培养点': 'Remaining',
  '点': 'pts',
  '级': 'lvl',
  '岁': 'yrs',
  '已导出 {n} / {total}：{name}': 'Exported {i} / {total}: {name}',
  '已导出 {n} 名球员、{m} 个文件。': 'Exported {n} player(s) and {m} file(s).',
  '还没有保存的球员': 'No saved players yet',
  '正在导出…': 'Exporting…',
  '正在导入…': 'Importing…',
  '正在保存…': 'Saving…',
  '已保存到本机': 'Saved locally',
  '保存失败，按 Ctrl+S 重试': 'Save failed. Press Ctrl+S to retry.',
  '界面语言已切换': 'Interface language changed.',
  '天生技能': 'Innate skills',
  '额外习得': 'Additional skills',
  '只看已选': 'Selected only',
  '点击添加，再次点击取消': 'Click to add, click again to remove',
  '没有匹配的技能': 'No matching skills',
  '原创效果': 'custom effect',
  'AI 比赛风格': 'AI playing styles',
  '影响电脑控制这名球员时的跑位与处理球倾向，可多选或全部取消。': 'Affects how the AI moves and uses the ball for this player. Select any or none.',
  '天': 'I',
  '追': 'A',
  '球员照片': 'Player photo',
  '还没有照片<br>透明 PNG 效果最好': 'No photo yet<br>Transparent PNG',
  '导入人物照片后，卡面会自动裁切排版。纯色背景的照片可以直接用内置抠图；已经是透明 PNG 的会原样使用。':
    'The card lays out the photo automatically. Solid-background photos can use the built-in cutout; transparent PNGs are used as-is.',
  '替换照片': 'Replace photo',
  '导入照片': 'Import photo',
  '抠图': 'Cut out',
  '移除': 'Remove',
  '使用抠图结果': 'Use cutout result',
  '抠图容差': 'Cutout tolerance',
  '背景越花越要调高；抠完再调一次即可': 'Raise it for busier backgrounds; adjust and cut out again.',
  '透明 PNG 不需要抠图。如果人物穿着接近背景的颜色（例如白袜配白底），可能被一起扣掉，可降低容差或改用透明 PNG。':
    'Transparent PNGs need no cutout. If clothing is close to the background colour (white socks on white), lower the tolerance or use a transparent PNG.',
  '卡面模板': 'Card templates',
  '模板只改变卡面风格；照片、姓名、能力与技能都会保留。当前：{name}。': 'Templates only change the style; photo, name, abilities and skills stay. Current: {name}.',
  '颜色与构图': 'Colour & layout',
  '主色': 'Accent colour',
  '快速配色': 'Quick colours',
  '照片缩放': 'Photo scale',
  '水平位置': 'Horizontal',
  '垂直位置': 'Vertical',
  '旋转': 'Rotate',
  '提示：直接拖动右侧卡面也可以移动照片。': 'Tip: drag the card preview to move the photo.',
  '背景': 'Background',
  '背景方式': 'Background mode',
  '使用模板背景': 'Use template background',
  '使用自己的背景图': 'Use my own background',
  '自定义背景': 'Custom background',
  '未选择': 'Not selected',
  '选择图片': 'Choose image',
  '卡面显示项': 'Visible on card',
  '六项能力': 'Six stats',
  '技能标签': 'Skill tags',
  '国家 / 球队': 'Nation / club',
  '星级': 'Stars',
  '背号水印': 'Number watermark',
  '导出卡面': 'Export card',
  '导出为 PNG：卡面 1200 × 1720，小头像 512 × 512。文件名会自动带上球员名字。':
    'PNG output: card 1200 × 1720, avatar 512 × 512. The player name is used in the filename.',
  '导出卡面 PNG': 'Export card PNG',
  '导出小头像': 'Export avatar',
  '更多导出选项': 'More export options',
  '当前球员照片': 'Current player photo',
  '基础能力': 'Abilities',
  '球员资料': 'Player Profile',
  '导出与工程': 'Export & Project',
  '找到这名球员': 'Find this player',
  '正在取景卡面照片…': 'Capturing card photo…',
  '正在取景小头像…': 'Capturing avatar…',
  '取景已用于卡面照片': 'Capture applied to the card photo.',
  '小头像已保存': 'Avatar saved.',
  '卡面已导出：1200 × 1720 PNG': 'Card exported: 1200 × 1720 PNG.',
  '小头像已导出：512 × 512 PNG': 'Avatar exported: 512 × 512 PNG.',
  '已导出 {format} 模型': '{format} model exported.',
  '请至少选择一项导出内容': 'Select at least one export item.',
  '还没有球员可以导出': 'There are no players to export.',
  '全部球员已打包导出': 'All players have been exported.',
  '工程已导出：{name}': 'Project exported: {name}',
  '工程已导入': 'Project imported.',
  '工程已导入，恢复 {n} 个素材': 'Project imported. Restored {n} asset(s).',
  '已创建 {name}，修改会自动保存': '{name} created. Changes save automatically.',
  '已复制球员，可以独立编辑': 'Player duplicated. You can edit it independently.',
  '球员已删除': 'Player deleted.',
  '照片已导入，可以点“抠图”去掉纯色背景': 'Photo imported. Use Cut out for solid backgrounds.',
  '抠图完成，已用于卡面；容差可以再调': 'Cutout complete and applied to the card. You can refine the tolerance.',
  '正在抠图，请稍候…': 'Cutting out, please wait…',
  '模型已导入，正在读取网格': 'Model imported. Reading the mesh…',
  '模型已导入': 'Model imported.',
  '已导出 GLB 模型': 'GLB model exported.',
  '已导出 OBJ 模型': 'OBJ model exported.',
  '未命名': 'Unnamed',
  '确定删除“{name}”吗？工程文件会从 data/players 移除，自动备份也会一起清理。':
    'Delete “{name}”? The project file and its automatic backups will be removed from data/players.',
  '删除球员': 'Delete player',
  '取消': 'Cancel',
  '确定': 'OK',
  '创建球员': 'Create player',
  '新建球员': 'New player',
  '建立一个独立球员工程。已保存的球员不会被覆盖，资料会立即写入本机。':
    'Create a standalone player project. Saved players are not overwritten and the profile is written to this PC immediately.',
  '参考模板（可选）': 'Reference template (optional)',
  '不使用参考': 'No reference',
  '开始创作': 'Start creating',
  '下次不再显示': "Don't show again",
  '这是一个只做球员创作的本地工具：<strong>不读取 APK</strong>，也不需要游戏安装包。填写资料与能力，设计卡面，导入自己的模型，然后导出卡面 PNG、数据文件和模型。':
    'A local tool for player creation. It <strong>does not read APKs</strong> and needs no game install. Fill in the profile and abilities, design the card, import your model, then export card PNGs, data files and models.',
  '资料、能力、培养、技能，总评按内置公式实时计算。': 'Profile, abilities, development and skills, with live rating calculation.',
  '七套卡面模板 + 自己的照片，拖一拖就能排版。': 'Seven card templates plus your own photo, arranged by dragging.',
  'GLB / OBJ 模型可预览、取景成卡面照片并重新导出。': 'Preview GLB / OBJ models, capture them as card art and export them again.',
  '所有文件只存在本机，不联网、不上传。': 'Everything stays on this PC. No network, no uploads.',
});

/* English-only suffix used by file exports. */
export const FILE_SUFFIX = {
  card: ['-卡面.png', '-card.png'],
  avatar: ['-小头像.png', '-avatar.png'],
  json: ['-资料.json', '-data.json'],
  markdown: ['-资料.md', '-profile.md'],
  csv: ['-能力.csv', '-abilities.csv'],
  model: ['-模型', '-model'],
  modelPreview: ['-模型预览.png', '-model-preview.png'],
};

export function fileSuffix(kind, fallback = '') {
  const pair = FILE_SUFFIX[kind];
  if (!pair) return fallback;
  return language === 'en' ? pair[1] : pair[0];
}
