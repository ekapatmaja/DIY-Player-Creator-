/* 小型界面工具：图标、表单控件和面板，供各页面复用。 */

import { esc } from './core.js';

const ICONS = {
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
  players: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20v-1.8a6.5 6.5 0 0 1 13 0V20M16 4.4a3.5 3.5 0 0 1 0 6.8M18.4 20v-1.6c0-2-.8-3.6-2-4.7"/>',
  chart: '<path d="M4 20V10m8 10V4m8 16v-7"/>',
  grow: '<path d="m3 17 6-6 4 4 8-10m-6 0h6v6"/>',
  spark: '<path d="m12 3 2.7 6.3L21 12l-6.3 2.7L12 21l-2.7-6.3L3 12l6.3-2.7L12 3Z"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1"/><path d="m3 16 5-5 6 6 4-4 3 3"/>',
  cube: '<path d="m12 3 9 5v9l-9 5-9-5V8l9-5Zm0 10 9-5m-9 5L3 8m9 5v9M7.5 5.5l9 5"/>',
  export: '<path d="M12 16V3m-5 5 5-5 5 5M4 14v6h16v-6"/>',
  archive: '<path d="M5 9h14v11H5zM3 3h18v6H3zM9 13h6"/>',
  folder: '<path d="M3 7V5a2 2 0 0 1 2-2h4l3 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
  plus: '<path d="M12 4v16M4 12h16"/>',
  check: '<path d="m4 12 5 5L20 6"/>',
  search: '<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 4 2l-1.5 1v2m0 3h.01"/>',
  undo: '<path d="M8 4 3 9l5 5M4 9h10a6 6 0 0 1 0 12h-3"/>',
  redo: '<path d="m16 4 5 5-5 5m4-5H10a6 6 0 0 0 0 12h3"/>',
  fingerprint: '<path d="M5 11a7 7 0 0 1 14 0v4m-10 6V11a3 3 0 0 1 6 0v7m-3-7v10M5 14v3m14 1v2M2 11a10 10 0 0 1 20 0"/>',
  refresh: '<path d="M20 7v5h-5M4 17v-5h5M5 8a8 8 0 0 1 13-3l2 2M4 17l2 2a8 8 0 0 0 13-3"/>',
  camera: '<path d="m8 5 2-3h4l2 3h4a1 1 0 0 1 1 1v14H3V6a1 1 0 0 1 1-1h4Z"/><circle cx="12" cy="12" r="4"/>',
  download: '<path d="M12 3v13m-5-5 5 5 5-5M4 17v4h16v-4"/>',
  upload: '<path d="M12 16V3m-5 5 5-5 5 5M4 17v4h16v-4"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3m-8 0 1 14h8l1-14M10 11v6m4-6v6"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
  palette: '<path d="M12 3a9 9 0 1 0 0 18h1.5a2.5 2.5 0 0 0 0-5H12a2 2 0 0 1 0-4h5a4 4 0 0 0 4-4 6 6 0 0 0-6-5.5"/><circle cx="7.5" cy="10" r="1"/><circle cx="9.5" cy="6.5" r="1"/><circle cx="14" cy="6" r="1"/>',
  arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><path d="M12 3v3m0 12v3M3 12h3m12 0h3"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5 9-5Zm9 9-9 5-9-5m18 4-9 5-9-5"/>',
  shield: '<path d="M12 3 20 6v6c0 4.5-3.2 7.6-8 9-4.8-1.4-8-4.5-8-9V6l8-3Z"/><path d="m8.5 12 2.5 2.5 4.5-5"/>',
  star: '<path d="m12 3 2.8 5.9 6.2.8-4.6 4.3 1.2 6.2-5.6-3-5.6 3 1.2-6.2L3 10l6.2-.8L12 3Z"/>',
  close: '<path d="M5 5l14 14M19 5 5 19"/>',
};

export function icon(name) {
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.spark}</svg>`;
}

export function hydrateIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach(node => { node.innerHTML = icon(node.dataset.icon); });
}

export function panel(title, body, tag = '', extra = '') {
  return `<section class="panel"><div class="panel-title"><h2>${esc(title)}</h2>${tag ? `<span class="tag">${esc(tag)}</span>` : ''}${extra}</div><div class="panel-body">${body}</div></section>`;
}

export function field(label, path, value, options = {}) {
  const attrs = [
    `data-bind="${esc(path)}"`,
    options.type ? `type="${esc(options.type)}"` : '',
    options.min !== undefined ? `min="${options.min}"` : '',
    options.max !== undefined ? `max="${options.max}"` : '',
    options.step !== undefined ? `step="${options.step}"` : '',
    options.placeholder ? `placeholder="${esc(options.placeholder)}"` : '',
    options.list ? `list="${esc(options.list)}"` : '',
    options.numeric ? 'data-number="1"' : '',
    options.inputmode ? `inputmode="${esc(options.inputmode)}"` : '',
  ].filter(Boolean).join(' ');
  let control;
  if (options.choices) {
    control = `<select ${attrs}>${options.choices.map(([key, text]) => `<option value="${esc(key)}" ${String(key) === String(value) ? 'selected' : ''}>${esc(text)}</option>`).join('')}</select>`;
  } else if (options.type === 'textarea') {
    control = `<textarea class="input ${options.className || ''}" ${attrs} rows="${options.rows || 4}">${esc(value)}</textarea>`;
  } else {
    control = `<input class="input" ${attrs} value="${esc(value ?? '')}">`;
  }
  const wrapped = options.unit ? `<div class="input-with-unit">${control}<span>${esc(options.unit)}</span></div>` : control;
  return `<label class="field ${options.wide ? 'span-two' : ''}"><span>${label}</span>${wrapped}${options.hint ? `<small>${options.hint}</small>` : ''}${options.datalist || ''}</label>`;
}

export function rangeField(path, label, value, min, max, step = 1, unit = '', hint = '') {
  return `<label class="range-field"><div class="row-between"><span>${esc(label)}</span><output data-value="${esc(path)}" data-unit="${esc(unit)}">${esc(value)}${esc(unit)}</output></div><input type="range" data-bind="${esc(path)}" min="${min}" max="${max}" step="${step}" value="${esc(value)}">${hint ? `<small style="color:#62778a;font-size:9px">${esc(hint)}</small>` : ''}</label>`;
}

export function toggle(path, label, checked) {
  return `<label class="switch-label"><input type="checkbox" data-bind="${esc(path)}" ${checked ? 'checked' : ''}>${esc(label)}</label>`;
}

export function emptyState(title, text, action = '') {
  return `<div class="empty-state"><strong>${esc(title)}</strong>${text}${action}</div>`;
}

export function getPath(object, path) {
  return path.split('.').reduce((value, key) => (value == null ? undefined : value[key]), object);
}

export function setPath(object, path, value) {
  const keys = path.split('.');
  let target = object;
  for (const key of keys.slice(0, -1)) {
    if (target[key] == null || typeof target[key] !== 'object') target[key] = {};
    target = target[key];
  }
  target[keys.at(-1)] = value;
}

export function formatBytes(size) {
  if (!size) return '0 B';
  if (size < 1024) return size + ' B';
  if (size < 1024 * 1024) return (size / 1024).toFixed(1) + ' KB';
  return (size / 1024 / 1024).toFixed(1) + ' MB';
}

export function formatTime(value) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const pad = number => String(number).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
